
scoreboard players set @s pps43ammo 5 
scoreboard players set @s ppd40ammo 5 
scoreboard players set @s mp28ammo 5 
scoreboard players set @s ppsh41bammo 5 
scoreboard players set @s mab38ammo 5 
scoreboard players set @s ppsh41dammo 5 
scoreboard players set @s mp40ammo 5 
scoreboard players set @s m3a1ammo 5 
scoreboard players set @s m1928a1ammo 5 
scoreboard players set @s thompsonammo 5 
scoreboard players set @s type100ammo 5 
scoreboard players set @s type2aammo 5 