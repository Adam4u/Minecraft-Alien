
scoreboard players set @s type99ammo 15 
scoreboard players set @s m1903ammo 15
scoreboard players set @s pzb39ammo 6
scoreboard players set @s kar98ammo 15
scoreboard players set @s mosinammo 15
scoreboard players set @s g43ammo 5 
scoreboard players set @s svt38ammo 5
scoreboard players set @s garandammo 5 