execute as @s[scores={voice=1}] run playsound arthur_alert_a @a[r=20]
execute as @s[scores={voice=2}] run playsound klaus_alert_a @a[r=20]
execute as @s[scores={voice=3}] run playsound richard_alert_a @a[r=20]