execute as @s[scores={voice=1}] run playsound artillery_uk_reply @a[rm=1,r=20]
execute as @s[scores={voice=2}] run playsound artillery_german_reply @a[rm=1,r=20]
execute as @s[scores={voice=3}] run playsound artillery_us_reply @a[rm=1,r=20]

execute as @s[scores={voice=1}] run playsound artillery_uk_replyf @s
execute as @s[scores={voice=2}] run playsound artillery_german_replyf @s
execute as @s[scores={voice=3}] run playsound artillery_us_replyf @s