event entity @s[hasitem={item=ww:mp28,location=slot.weapon.mainhand},scores={mp28mag=0}]  mag0
event entity @s[hasitem={item=ww:mp28,location=slot.weapon.mainhand},scores={mp28mag=1}]  mag1