

event entity @s[hasitem={item=ww:m1903,location=slot.weapon.mainhand},scores={m1903muzzle=0}]  muzzle0
event entity @s[hasitem={item=ww:m1903,location=slot.weapon.mainhand},scores={m1903muzzle=1}]  muzzle1
event entity @s[hasitem={item=ww:m1903,location=slot.weapon.mainhand},scores={m1903scope=0}]  scope0
event entity @s[hasitem={item=ww:m1903,location=slot.weapon.mainhand},scores={m1903scope=4}]  scope4