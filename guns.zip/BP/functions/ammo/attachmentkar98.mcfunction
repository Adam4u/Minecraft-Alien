
event entity @s[hasitem={item=ww:kar98,location=slot.weapon.mainhand},scores={kar98muzzle=0}]  muzzle0
event entity @s[hasitem={item=ww:kar98,location=slot.weapon.mainhand},scores={kar98muzzle=1}]  muzzle1
event entity @s[hasitem={item=ww:kar98,location=slot.weapon.mainhand},scores={kar98muzzle=2}]  muzzle2
event entity @s[hasitem={item=ww:kar98,location=slot.weapon.mainhand},scores={kar98muzzle=2}]  muzzle3
event entity @s[hasitem={item=ww:kar98,location=slot.weapon.mainhand},scores={kar98scope=0}]  scope0
event entity @s[hasitem={item=ww:kar98,location=slot.weapon.mainhand},scores={kar98scope=3}]  scope3
event entity @s[hasitem={item=ww:kar98,location=slot.weapon.mainhand},scores={kar98scope=4}]  scope4