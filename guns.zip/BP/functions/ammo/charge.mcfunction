execute as @a[scores={charge=1}] at @s positioned ^^^1 if entity @e[r=0.99] run tag @s add meleeAttack
execute as @a[scores={charge=1}] at @s positioned ^^^1 run damage @e[r=0.99,c=1] 35 entity_attack entity @s
execute as @a[scores={charge=1}] at @s positioned ^^^1 at @e[r=0.99,c=1] if entity @e[tag=npcs,c=1] run event entity @s tww:npcEvent
execute as @a[scores={charge=1}] at @s positioned ^^^1 at @e[r=0.99,c=1] if entity @e[tag=npcs,c=1] facing entity @s feet run tp ~~~ ~ ~
execute as @a[tag=meleeAttack] at @s run scoreboard players set @s charge 0
execute as @a[tag=meleeAttack] at @s run event entity @s tww:melee