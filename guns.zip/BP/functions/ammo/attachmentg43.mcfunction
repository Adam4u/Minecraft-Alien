
event entity @s[hasitem={item=ww:g43,location=slot.weapon.mainhand},scores={g43scope=0}]  scope0
event entity @s[hasitem={item=ww:g43,location=slot.weapon.mainhand},scores={g43scope=3}]  scope3