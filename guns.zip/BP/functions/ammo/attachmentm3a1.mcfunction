event entity @s[hasitem={item=ww:m3a1,location=slot.weapon.mainhand},scores={m3a1stock=0}]  stock0
event entity @s[hasitem={item=ww:m3a1,location=slot.weapon.mainhand},scores={m3a1stock=1}]  stock1
event entity @s[hasitem={item=ww:m3a1,location=slot.weapon.mainhand},scores={m3a1muzzle=0}]  muzzle0
event entity @s[hasitem={item=ww:m3a1,location=slot.weapon.mainhand},scores={m3a1muzzle=1}]  muzzle1
event entity @s[hasitem={item=ww:m3a1,location=slot.weapon.mainhand},scores={m3a1muzzle=2}]  muzzle2
event entity @s[hasitem={item=ww:m3a1,location=slot.weapon.mainhand},scores={m3a1mag=0}]  mag0
event entity @s[hasitem={item=ww:m3a1,location=slot.weapon.mainhand},scores={m3a1mag=1}]  mag1