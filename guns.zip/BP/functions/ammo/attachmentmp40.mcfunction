event entity @s[hasitem={item=ww:mp40,location=slot.weapon.mainhand},scores={mp40stock=0}]  stock0
event entity @s[hasitem={item=ww:mp40,location=slot.weapon.mainhand},scores={mp40stock=1}]  stock1
event entity @s[hasitem={item=ww:mp40,location=slot.weapon.mainhand},scores={mp40muzzle=0}]  muzzle0
event entity @s[hasitem={item=ww:mp40,location=slot.weapon.mainhand},scores={mp40muzzle=1}]  muzzle1