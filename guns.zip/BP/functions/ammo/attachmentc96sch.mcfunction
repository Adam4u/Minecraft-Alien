event entity @s[hasitem={item=ww:c96sch,location=slot.weapon.mainhand},scores={c96schstock=0}]  stock0
event entity @s[hasitem={item=ww:c96sch,location=slot.weapon.mainhand},scores={c96schstock=1}]  stock1
event entity @s[hasitem={item=ww:c96sch,location=slot.weapon.mainhand},scores={c96schmuzzle=0}]  muzzle0
event entity @s[hasitem={item=ww:c96sch,location=slot.weapon.mainhand},scores={c96schmuzzle=1}]  muzzle1
event entity @s[hasitem={item=ww:c96sch,location=slot.weapon.mainhand},scores={c96schmag=0}]  mag0
event entity @s[hasitem={item=ww:c96sch,location=slot.weapon.mainhand},scores={c96schmag=1}]  mag1
event entity @s[hasitem={item=ww:c96sch,location=slot.weapon.mainhand},scores={c96schscope=0}]  scope0
event entity @s[hasitem={item=ww:c96sch,location=slot.weapon.mainhand},scores={c96schscope=2}]  scope2