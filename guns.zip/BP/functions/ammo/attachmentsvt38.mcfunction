

event entity @s[hasitem={item=ww:svt38,location=slot.weapon.mainhand},scores={svt38muzzle=0}]  muzzle0
event entity @s[hasitem={item=ww:svt38,location=slot.weapon.mainhand},scores={svt38muzzle=1}]  muzzle1
event entity @s[hasitem={item=ww:svt38,location=slot.weapon.mainhand},scores={svt38scope=0}]  scope0
event entity @s[hasitem={item=ww:svt38,location=slot.weapon.mainhand},scores={svt38scope=3}]  scope3