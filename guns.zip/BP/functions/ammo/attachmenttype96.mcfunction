

event entity @s[hasitem={item=ww:type96,location=slot.weapon.mainhand},scores={type96muzzle=0}]  muzzle0
event entity @s[hasitem={item=ww:type96,location=slot.weapon.mainhand},scores={type96muzzle=1}]  muzzle1
event entity @s[hasitem={item=ww:type96,location=slot.weapon.mainhand},scores={type96scope=0}]  scope0
event entity @s[hasitem={item=ww:type96,location=slot.weapon.mainhand},scores={type96scope=3}]  scope3
event entity @s[hasitem={item=ww:type96,location=slot.weapon.mainhand},scores={type96bipod=0}]  bipod0
event entity @s[hasitem={item=ww:type96,location=slot.weapon.mainhand},scores={type96bipod=1}]  bipod1