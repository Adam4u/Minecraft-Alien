

event entity @s[hasitem={item=ww:mosin,location=slot.weapon.mainhand},scores={mosinmuzzle=0}]  muzzle0
event entity @s[hasitem={item=ww:mosin,location=slot.weapon.mainhand},scores={mosinmuzzle=1}]  muzzle1
event entity @s[hasitem={item=ww:mosin,location=slot.weapon.mainhand},scores={mosinscope=0}]  scope0
event entity @s[hasitem={item=ww:mosin,location=slot.weapon.mainhand},scores={mosinscope=4}]  scope4