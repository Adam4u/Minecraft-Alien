

event entity @s[hasitem={item=ww:type99,location=slot.weapon.mainhand},scores={type99muzzle=0}]  muzzle0
event entity @s[hasitem={item=ww:type99,location=slot.weapon.mainhand},scores={type99muzzle=1}]  muzzle1
event entity @s[hasitem={item=ww:type99,location=slot.weapon.mainhand},scores={type99scope=0}]  scope0
event entity @s[hasitem={item=ww:type99,location=slot.weapon.mainhand},scores={type99scope=2}]  scope2
event entity @s[hasitem={item=ww:type99,location=slot.weapon.mainhand},scores={type99scope=3}]  scope3
event entity @s[hasitem={item=ww:type99,location=slot.weapon.mainhand},scores={type99scope=4}]  scope4
event entity @s[hasitem={item=ww:type99,location=slot.weapon.mainhand},scores={type99bipod=0}]  bipod0
event entity @s[hasitem={item=ww:type99,location=slot.weapon.mainhand},scores={type99bipod=1}]  bipod1
event entity @s[hasitem={item=ww:type99,location=slot.weapon.mainhand},scores={type99bipod=2}]  bipod2