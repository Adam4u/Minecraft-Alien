title @a[hasitem={item=ww:lungemine,location=slot.weapon.mainhand},scores={charge=5}] actionbar §4•|[FULL]|•
title @a[hasitem={item=ww:lungemine,location=slot.weapon.mainhand},scores={charge=0}] actionbar •|[ §25/5 §f]|• 
title @a[hasitem={item=ww:lungemine,location=slot.weapon.mainhand},scores={charge=1}] actionbar •|[ §24/5 §f]|• 
title @a[hasitem={item=ww:lungemine,location=slot.weapon.mainhand},scores={charge=2}] actionbar •|[ §23/5 §f]|• 
title @a[hasitem={item=ww:lungemine,location=slot.weapon.mainhand},scores={charge=3}] actionbar •|[ §62/5 §f]|• 
title @a[hasitem={item=ww:lungemine,location=slot.weapon.mainhand},scores={charge=4}] actionbar •|[ §61/5 §f]|• 