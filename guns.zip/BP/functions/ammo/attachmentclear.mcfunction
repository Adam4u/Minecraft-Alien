event entity @s stock0
event entity @s scope0
event entity @s mag0
event entity @s bipod0
event entity @s muzzle0