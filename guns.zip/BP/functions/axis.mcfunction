tag @s remove axis
tag @s remove allies
tag @s add axis
playsound drum @s
title @s title §f§lYou Joined The Axis!
tellraw @a {"rawtext":[{"text":"§e"},{"selector":"@s"},{"text":" §bJoined The Axis!"}]}