
scoreboard players set @s type11ammo 5 
scoreboard players set @s mg34bammo 5 
scoreboard players set @s mg42bammo 5 
scoreboard players set @s mg42ammo 5 
scoreboard players set @s type96ammo 5 
scoreboard players set @s  barammo 5 
scoreboard players set @s  fg42ammo 5 
scoreboard players set @s  lewisammo 5 
scoreboard players set @s dp28ammo 5 
scoreboard players set @s stingerammo 5