playsound tankhitmid @a[rm=21,r=80]
playsound tankhitnear @a[rm=0,r=20]