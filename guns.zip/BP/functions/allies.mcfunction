tag @s remove allies
tag @s remove axis
tag @s add allies
playsound drum @s
title @s title §f§lYou Joined The Allies!
tellraw @a {"rawtext":[{"text":"§e"},{"selector":"@s"},{"text":" §bJoined The Allies!"}]}