event entity @e[type=ww:g43m] speech
playsound ger_speech_1 @a[rm=0,r=30]