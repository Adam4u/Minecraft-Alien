scoreboard players set @s voice 7
replaceitem entity @p slot.armor.head 0 sv:soviethelmet
replaceitem entity @p slot.armor.chest 0 sv:telogreikageared