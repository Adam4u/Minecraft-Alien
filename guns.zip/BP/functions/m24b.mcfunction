event entity @s ww:m24b_fire
execute as @s[scores={voice=1}] run playsound arthur_request_c @a[r=20]
execute as @s[scores={voice=2}] run playsound klaus_request_c @a[r=20]
execute as @s[scores={voice=3}] run playsound richard_request_c @a[r=20]