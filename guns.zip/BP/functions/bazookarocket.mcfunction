
scoreboard players set @s bazookaammo 2