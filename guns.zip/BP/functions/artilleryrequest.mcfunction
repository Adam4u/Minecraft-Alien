execute as @s[scores={voice=1}] run playsound arthur_request_a @a[rm=1,r=20]
execute as @s[scores={voice=2}] run playsound klaus_request_a @a[rm=1,r=20]
execute as @s[scores={voice=3}] run playsound richard_request_a @a[rm=1,r=20]

execute as @s[scores={voice=1}] run playsound arthur_request_af @s
execute as @s[scores={voice=2}] run playsound klaus_request_af @s
execute as @s[scores={voice=3}] run playsound richard_request_af @s