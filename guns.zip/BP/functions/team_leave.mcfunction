tag @s remove axis
tag @s remove allies
