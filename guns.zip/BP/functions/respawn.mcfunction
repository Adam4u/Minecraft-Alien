playsound player.respawn @s
effect @s night_vision