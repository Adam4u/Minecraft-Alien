camerashake add @s 0.035 0.023 rotational
camerashake add @s 0.021 0.26 rotational
camerashake add @s 0.009 0.36 rotational
