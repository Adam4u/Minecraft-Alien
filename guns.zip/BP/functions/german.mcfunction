scoreboard players set @s voice 2
replaceitem entity @p slot.armor.head 0 gr:stahlhelm
replaceitem entity @p slot.armor.chest 0 gr:germangreatcoat