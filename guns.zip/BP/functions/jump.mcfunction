camerashake add @s 0.07 0.085 rotational
camerashake add @s 0.03 0.17 rotational
camerashake add @s 0.03 0.7 rotational
