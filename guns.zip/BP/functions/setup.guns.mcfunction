
#adding_of_gun_ammo_objectives


scoreboard objectives add tankrandom dummy


scoreboard objectives add mp40stock dummy
scoreboard players set @s[tag=!setup]  mp40stock 0
scoreboard objectives add mp40muzzle dummy
scoreboard players set @s[tag=!setup]  mp40muzzle 0
scoreboard objectives add type96scope dummy
scoreboard players set @s[tag=!setup]  type96scope 0
scoreboard objectives add type96bipod dummy
scoreboard players set @s[tag=!setup]  type96bipod 0
scoreboard objectives add type96muzzle dummy
scoreboard players set @s[tag=!setup]  type96muzzle 0
scoreboard objectives add type99scope dummy
scoreboard players set @s[tag=!setup]  type99scope 0
scoreboard objectives add type99bipod dummy
scoreboard players set @s[tag=!setup]  type99bipod 0
scoreboard objectives add type99muzzle dummy
scoreboard players set @s[tag=!setup]  type99muzzle 0
scoreboard objectives add c96schmag dummy
scoreboard players set @s[tag=!setup]  c96schmag 0
scoreboard objectives add c96schscope dummy
scoreboard players set @s[tag=!setup]  c96schscope 0
scoreboard objectives add c96schstock dummy
scoreboard players set @s[tag=!setup]  c96schstock 0
scoreboard objectives add c96schmuzzle dummy
scoreboard players set @s[tag=!setup]  c96schmuzzle 0
scoreboard objectives add mp28mag dummy
scoreboard players set @s[tag=!setup]  mp28mag 0
scoreboard objectives add svt38scope dummy
scoreboard players set @s[tag=!setup]  svt38scope 0
scoreboard objectives add svt38muzzle dummy
scoreboard players set @s[tag=!setup]  svt38muzzle 0
scoreboard objectives add g43scope dummy
scoreboard players set @s[tag=!setup]  g43scope 0
scoreboard objectives add mosinscope dummy
scoreboard players set @s[tag=!setup]  mosinscope 0
scoreboard objectives add mosinmuzzle dummy
scoreboard players set @s[tag=!setup]  mosinmuzzle 0
scoreboard objectives add kar98scope dummy
scoreboard players set @s[tag=!setup]  kar98scope 0
scoreboard objectives add kar98muzzle dummy
scoreboard players set @s[tag=!setup]  kar98muzzle 0
scoreboard objectives add m1903scope dummy
scoreboard players set @s[tag=!setup]  m1903scope 0
scoreboard objectives add m1903muzzle dummy
scoreboard players set @s[tag=!setup]  m1903muzzle 0
scoreboard objectives add m3a1stock dummy
scoreboard players set @s[tag=!setup]  m3a1stock 0
scoreboard objectives add m3a1muzzle dummy
scoreboard players set @s[tag=!setup]  m3a1muzzle 0
scoreboard objectives add m3a1mag dummy
scoreboard players set @s[tag=!setup]  m3a1mag 0
scoreboard objectives add mg42b dummy
scoreboard players set @s[tag=!setup]  mg42b 0
scoreboard objectives add mg42bhot dummy
scoreboard players set @s[tag=!setup]  mg42bhot 0
scoreboard objectives add mg42bammo dummy
scoreboard players set @s[tag=!setup]  mg42bammo 0
scoreboard objectives add mg34bhot dummy
scoreboard players set @s[tag=!setup]  mg34bhot 0
scoreboard objectives add mg34bammo dummy
scoreboard players set @s[tag=!setup]  mg34bammo 0
scoreboard objectives add mg42ammo dummy
scoreboard players set @s[tag=!setup]  mg42ammo 0
scoreboard objectives add pps43ammo dummy
scoreboard players set @s[tag=!setup] pps43ammo 0
scoreboard objectives add mab38ammo dummy
scoreboard players set @s[tag=!setup] mab38ammo 0
scoreboard objectives add ppsh41bammo dummy
scoreboard players set @s[tag=!setup] ppsh41bammo 0
scoreboard objectives add ppsh41dammo dummy
scoreboard players set @s[tag=!setup] ppsh41dammo 0
scoreboard objectives add ppd40ammo dummy
scoreboard players set @s[tag=!setup] ppd40ammo 0
scoreboard objectives add mp28ammo dummy
scoreboard players set @s[tag=!setup] mp28ammo 0
scoreboard objectives add mp40ammo dummy
scoreboard players set @s[tag=!setup] mp40ammo 0
scoreboard objectives add m3a1ammo dummy
scoreboard players set @s[tag=!setup] m3a1ammo 0
scoreboard objectives add thompsonammo dummy
scoreboard players set @s[tag=!setup] thompsonammo 0
scoreboard objectives add m1928a1ammo dummy
scoreboard players set @s[tag=!setup] m1928a1ammo 0
scoreboard objectives add type100ammo dummy
scoreboard players set @s[tag=!setup] type100ammo 0
scoreboard objectives add m2flameammo dummy
scoreboard players set @s[tag=!setup] m2flameammo 0
scoreboard objectives add p08ammo dummy
scoreboard players set @s[tag=!setup] p08ammo 0
scoreboard objectives add type2aammo dummy
scoreboard players set @s[tag=!setup] type2aammo 0
scoreboard objectives add type11ammo dummy
scoreboard players set @s[tag=!setup] type11ammo 0
scoreboard objectives add type96ammo dummy
scoreboard players set @s[tag=!setup] type96ammo 0
scoreboard objectives add barammo dummy
scoreboard players set @s[tag=!setup] barammo 0
scoreboard objectives add lewisammo dummy
scoreboard players set @s[tag=!setup] lewisammo 0
scoreboard objectives add dp28ammo dummy
scoreboard players set @s[tag=!setup] dp28ammo 0
scoreboard objectives add svt38ammo dummy
scoreboard players set @s[tag=!setup] svt38ammo 0
scoreboard objectives add garandammo dummy
scoreboard players set @s[tag=!setup] garandammo 0
scoreboard objectives add g43ammo dummy
scoreboard players set @s[tag=!setup] g43ammo 0
scoreboard objectives add mas35ammo dummy
scoreboard players set @s[tag=!setup] mas35ammo 0
scoreboard objectives add bazookaammo dummy
scoreboard players set @s[tag=!setup] bazookaammo 0
scoreboard objectives add panzershreckammo dummy
scoreboard players set @s[tag=!setup] panzershreckammo 0
scoreboard objectives add pzb39ammo dummy
scoreboard players set @s[tag=!setup] pzb39ammo 0
scoreboard objectives add p38ammo dummy
scoreboard players set @s[tag=!setup] p38ammo 0
scoreboard objectives add tt33ammo dummy
scoreboard players set @s[tag=!setup] tt33ammo 0
scoreboard objectives add m1911ammo dummy
scoreboard players set @s[tag=!setup] m1911ammo 0
scoreboard objectives add c96schammo dummy
scoreboard players set @s[tag=!setup] c96schammo 0
scoreboard objectives add fg42ammo dummy
scoreboard players set @s[tag=!setup] fg42ammo 0
scoreboard objectives add type99ammo dummy
scoreboard players set @s[tag=!setup] type99ammo 0
scoreboard objectives add m1903ammo dummy
scoreboard players set @s[tag=!setup] m1903ammo 0
scoreboard objectives add kar98ammo dummy
scoreboard players set @s[tag=!setup] kar98ammo 0
scoreboard objectives add mosinammo dummy
scoreboard players set @s[tag=!setup] mosinammo 0
scoreboard objectives add model1912ammo dummy
scoreboard players set @s[tag=!setup] model1912ammo 0
scoreboard objectives add nagantammo dummy
scoreboard players set @s[tag=!setup] nagantammo 0
scoreboard objectives add stingerammo dummy
scoreboard players set @s[tag=!setup] stingerammo 0
scoreboard objectives add stg44ammo dummy
scoreboard players set @s[tag=!setup] stg44ammo 0

scoreboard objectives add bullet dummy
scoreboard players set @s[tag=!setup] bullet 0

scoreboard objectives add bipod dummy
scoreboard players set @s[tag=!setup] bipod 0

#adding_of_gun_cooldown_objectives
scoreboard objectives add voice dummy
scoreboard objectives add thumb dummy
scoreboard objectives add m1911 dummy
scoreboard objectives add m1919 dummy
scoreboard objectives add fm24 dummy
scoreboard objectives add ppsh41b dummy
scoreboard objectives add ppsh41bbolt dummy
scoreboard objectives add mp28 dummy
scoreboard objectives add mp28bolt dummy
scoreboard objectives add ppd40 dummy
scoreboard objectives add ppd40bolt dummy
scoreboard objectives add ppsh41d dummy
scoreboard objectives add ppsh41dbolt dummy
scoreboard objectives add m1903 dummy
scoreboard objectives add m1903cycle dummy
scoreboard objectives add charge dummy
scoreboard objectives add chargelock dummy
scoreboard objectives add mas36 dummy
scoreboard objectives add bazooka dummy
scoreboard objectives add bazookabolt dummy
scoreboard objectives add panzershreck dummy
scoreboard objectives add panzershreckbolt dummy
scoreboard objectives add pzb39 dummy
scoreboard objectives add pzb39bolt dummy
scoreboard objectives add enfieldmk1s dummy
scoreboard objectives add m3a1 dummy
scoreboard objectives add m3a1bolt dummy
scoreboard objectives add c96sch dummy
scoreboard objectives add c96schbolt dummy
scoreboard objectives add enfieldmk1sbolt dummy
scoreboard objectives add mas38 dummy
scoreboard objectives add sten dummy
scoreboard objectives add m1903bolt dummy
scoreboard objectives add m1903sbolt dummy
scoreboard objectives add m1903s dummy
scoreboard objectives add mas36bolt dummy
scoreboard objectives add bren dummy
scoreboard objectives add thompson dummy
scoreboard objectives add thompsonbolt dummy
scoreboard objectives add m1928a1 dummy
scoreboard objectives add m1928a1bolt dummy
scoreboard objectives add type96 dummy
scoreboard objectives add type96bolt dummy
scoreboard objectives add g43 dummy
scoreboard objectives add g43bolt dummy
scoreboard objectives add mg42 dummy
scoreboard objectives add mg42hot dummy
scoreboard objectives add mg42bolt dummy
scoreboard objectives add garand dummy
scoreboard objectives add garandbolt dummy
scoreboard objectives add lugera dummy
scoreboard objectives add flammenwherfer35 dummy
scoreboard objectives add mp40 dummy
scoreboard objectives add mp40bolt dummy
scoreboard objectives add m1c dummy
scoreboard objectives add mod30 dummy
scoreboard objectives add mosin dummy
scoreboard objectives add mosinbolt dummy
scoreboard objectives add mosincycle dummy
scoreboard objectives add type99 dummy
scoreboard objectives add type99bolt dummy
scoreboard objectives add type99cycle dummy
scoreboard objectives add bar dummy
scoreboard objectives add kar98 dummy
scoreboard objectives add kar98cycle dummy
scoreboard objectives add kar98s dummy
scoreboard objectives add model1912bolt dummy
scoreboard objectives add nagantbolt dummy
scoreboard objectives add p38 dummy
scoreboard objectives add p38bolt dummy
scoreboard objectives add tt33 dummy
scoreboard objectives add tt33bolt dummy
scoreboard objectives add m1911 dummy
scoreboard objectives add m1911bolt dummy
scoreboard objectives add mas35 dummy
scoreboard objectives add mas35bolt dummy
scoreboard objectives add type11 dummy
scoreboard objectives add type11bolt dummy
scoreboard objectives add type2a dummy
scoreboard objectives add type100bolt dummy
scoreboard objectives add type100 dummy
scoreboard objectives add m2flamebolt dummy
scoreboard objectives add m2flame dummy
scoreboard objectives add stingerbolt dummy
scoreboard objectives add stinger dummy
scoreboard objectives add stg44bolt dummy
scoreboard objectives add stg44 dummy
scoreboard objectives add type2abolt dummy
scoreboard objectives add kar98bolt dummy
scoreboard objectives add kar98sbolt dummy
scoreboard objectives add fg42e dummy
scoreboard objectives add pps43 dummy
scoreboard objectives add pps43bolt dummy
scoreboard objectives add mab38 dummy
scoreboard objectives add mab38bolt dummy
scoreboard objectives add svt38 dummy
scoreboard objectives add svt38bolt dummy
scoreboard objectives add model1912 dummy
scoreboard objectives add model1912bolt dummy
scoreboard objectives add model1912cycle dummy
scoreboard objectives add nagant dummy
scoreboard objectives add nagantbolt dummy
scoreboard objectives add nagantcycle dummy
scoreboard objectives add mg34b dummy
scoreboard objectives add mg34bbolt dummy
scoreboard objectives add p08 dummy
scoreboard objectives add p08bolt dummy
scoreboard objectives add hipower dummy
scoreboard objectives add dp28 dummy
scoreboard objectives add dp28bolt dummy
scoreboard objectives add lewis dummy
scoreboard objectives add lewisbolt dummy
scoreboard objectives add fg42 dummy
scoreboard objectives add fg42bolt dummy
scoreboard objectives add enfieldmk1 dummy
scoreboard objectives add enfieldmk1bolt dummy
scoreboard objectives add gatling dummy
scoreboard objectives add mk6 dummy
scoreboard objectives add mk6bolt dummy





#seting_cooldown_to_0
scoreboard players set @s[tag=!setup] voice 0
scoreboard players set @s[tag=!setup] thumb 0
scoreboard players set @s[tag=!setup] mg42 0
scoreboard players set @s[tag=!setup] m1911 0
scoreboard players set @s[tag=!setup] thompson 0
scoreboard players set @s[tag=!setup] thompsonbolt 0
scoreboard players set @s[tag=!setup] m1928a1 0
scoreboard players set @s[tag=!setup] m1928a1bolt 0
scoreboard players set @s[tag=!setup] type96 0
scoreboard players set @s[tag=!setup] type96bolt 0
scoreboard players set @s[tag=!setup] m1903 0
scoreboard players set @s[tag=!setup] ppsh41b 0
scoreboard players set @s[tag=!setup] ppsh41bbolt 0
scoreboard players set @s[tag=!setup] ppsh41dbolt 0
scoreboard players set @s[tag=!setup] ppsh41d 0
scoreboard players set @s[tag=!setup] ppd40bolt 0
scoreboard players set @s[tag=!setup] ppd40 0
scoreboard players set @s[tag=!setup] mp28bolt 0
scoreboard players set @s[tag=!setup] mp28 0
scoreboard players set @s[tag=!setup] fm24 0
scoreboard players set @s[tag=!setup] m1903bolt 0
scoreboard players set @s[tag=!setup] m1903cycle 0
scoreboard players set @s[tag=!setup] charge 0
scoreboard players set @s[tag=!setup] chargelock 0
scoreboard players set @s[tag=!setup] m1903sbolt 0
scoreboard players set @s[tag=!setup] m1903s 0
scoreboard players set @s[tag=!setup] mas36 0
scoreboard players set @s[tag=!setup] bazooka 0
scoreboard players set @s[tag=!setup] bazookabolt 0
scoreboard players set @s[tag=!setup] panzershreck 0
scoreboard players set @s[tag=!setup] panzershreckbolt 0
scoreboard players set @s[tag=!setup] mas36bolt 0
scoreboard players set @s[tag=!setup] bren 0
scoreboard players set @s[tag=!setup] m1919 0
scoreboard players set @s[tag=!setup] mg42hot 0
scoreboard players set @s[tag=!setup] mg42bolt 0
scoreboard players set @s[tag=!setup] garand 0
scoreboard players set @s[tag=!setup] garandbolt 0
scoreboard players set @s[tag=!setup] lugera 0
scoreboard players set @s[tag=!setup] flammenwherfer35 1
scoreboard players set @s[tag=!setup] bar 0
scoreboard players set @s[tag=!setup] mp40 0
scoreboard players set @s[tag=!setup] mp40bolt 0
scoreboard players set @s[tag=!setup] mosin 0
scoreboard players set @s[tag=!setup] mosinbolt 0
scoreboard players set @s[tag=!setup] mosincycle 0
scoreboard players set @s[tag=!setup] type99 0
scoreboard players set @s[tag=!setup] type99bolt 0
scoreboard players set @s[tag=!setup] type99cycle 0
scoreboard players set @s[tag=!setup] p38 0
scoreboard players set @s[tag=!setup] p38bolt 0
scoreboard players set @s[tag=!setup] tt33 0
scoreboard players set @s[tag=!setup] tt33bolt 0
scoreboard players set @s[tag=!setup] m1911 0
scoreboard players set @s[tag=!setup] m1911bolt 0
scoreboard players set @s[tag=!setup] mas35 0
scoreboard players set @s[tag=!setup] mas35bolt 0
scoreboard players set @s[tag=!setup] type2a 0
scoreboard players set @s[tag=!setup] type2abolt 0
scoreboard players set @s[tag=!setup] type100 0
scoreboard players set @s[tag=!setup] type100bolt 0
scoreboard players set @s[tag=!setup] m2flame 0
scoreboard players set @s[tag=!setup] m2flamebolt 0
scoreboard players set @s[tag=!setup] stinger 0
scoreboard players set @s[tag=!setup] stingerbolt 0
scoreboard players set @s[tag=!setup] stg44 0
scoreboard players set @s[tag=!setup] stg44bolt 0
scoreboard players set @s[tag=!setup] type11 0
scoreboard players set @s[tag=!setup] type11bolt 0
scoreboard players set @s[tag=!setup] pps43 0
scoreboard players set @s[tag=!setup] pps43bolt 0
scoreboard players set @s[tag=!setup] mab38 0
scoreboard players set @s[tag=!setup] mab38bolt 0
scoreboard players set @s[tag=!setup] svt38 0
scoreboard players set @s[tag=!setup] svt38bolt 0
scoreboard players set @s[tag=!setup] m1c 0
scoreboard players set @s[tag=!setup] dp28 0
scoreboard players set @s[tag=!setup] dp28bolt 0
scoreboard players set @s[tag=!setup] lewis 0
scoreboard players set @s[tag=!setup] lewisbolt 0
scoreboard players set @s[tag=!setup] kar98bolt 0
scoreboard players set @s[tag=!setup] kar98 0
scoreboard players set @s[tag=!setup] kar98cycle 0
scoreboard players set @s[tag=!setup] kar98sbolt 0
scoreboard players set @s[tag=!setup] kar98s 0
scoreboard players set @s[tag=!setup] g43 0
scoreboard players set @s[tag=!setup] g43bolt 0
scoreboard players set @s[tag=!setup] c96sch 0
scoreboard players set @s[tag=!setup] c96schbolt 0
scoreboard players set @s[tag=!setup] mod30 0
scoreboard players set @s[tag=!setup] model1912 0
scoreboard players set @s[tag=!setup] model1912bolt 0
scoreboard players set @s[tag=!setup] model1912cycle 0
scoreboard players set @s[tag=!setup] nagant 0
scoreboard players set @s[tag=!setup] nagantbolt 0
scoreboard players set @s[tag=!setup] nagantcycle 0
scoreboard players set @s[tag=!setup] fg42e 0
scoreboard players set @s[tag=!setup] fg42bolt 0
scoreboard players set @s[tag=!setup] mg34b 0
scoreboard players set @s[tag=!setup] mg34bbolt 0
scoreboard players set @s[tag=!setup] fg42 0
scoreboard players set @s[tag=!setup] p08 0
scoreboard players set @s[tag=!setup] p08bolt 0
scoreboard players set @s[tag=!setup] m3a1 0
scoreboard players set @s[tag=!setup] m3a1bolt 0
scoreboard players set @s[tag=!setup] enfieldmk1 0
scoreboard players set @s[tag=!setup] hipower 0
scoreboard players set @s[tag=!setup] mk6 0
scoreboard players set @s[tag=!setup] mk6bolt 0
scoreboard players set @s[tag=!setup] enfieldmk1bolt 0
scoreboard players set @s[tag=!setup] enfieldmk1sbolt 0
scoreboard players set @s[tag=!setup] enfieldmk1s 0
scoreboard players set @s[tag=!setup] mas38 0
scoreboard players set @s[tag=!setup] sten 0
scoreboard players set @s[tag=!setup] pzb39 0
scoreboard players set @s[tag=!setup] pzb39bolt 0


#credit
#*******★*****************★****************★*********
event entity @s[tag=!setup] gun:seting_up
tag @s[tag=!setup] add setup
#*******★*****************★****************★*********