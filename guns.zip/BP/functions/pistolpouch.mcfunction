
scoreboard players set @s mas35ammo 5 
scoreboard players set @s p38ammo 5 
scoreboard players set @s p08ammo 5 
scoreboard players set @s m1911ammo 5 
scoreboard players set @s tt33ammo 5 
scoreboard players set @s c96schammo 5 