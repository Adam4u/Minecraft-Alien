
scoreboard players set @s nagantammo 28