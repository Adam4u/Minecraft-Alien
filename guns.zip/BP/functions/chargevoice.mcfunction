execute as @s[scores={voice=1}] run playsound arthur_charge @a[rm=1,r=40]
execute as @s[scores={voice=2}] run playsound klaus_charge @a[rm=1,r=40]
execute as @s[scores={voice=3}] run playsound richard_charge @a[rm=1,r=40]
execute as @s[scores={voice=4}] run playsound takeshi_charge @a[rm=1,r=40]
execute as @s[scores={voice=5}] run playsound sakai_charge @a[rm=1,r=40]
execute as @s[scores={voice=6}] run playsound natasha_charge @a[rm=1,r=40]
execute as @s[scores={voice=7}] run playsound dimitri_charge @a[rm=1,r=40]
execute as @s[scores={voice=8}] run playsound charlotte_charge @a[rm=1,r=40]

execute as @s[scores={voice=1}] run playsound arthur_chargef @s
execute as @s[scores={voice=2}] run playsound klaus_chargef @s
execute as @s[scores={voice=3}] run playsound richard_chargef @s
execute as @s[scores={voice=4}] run playsound takeshi_chargef @s
execute as @s[scores={voice=5}] run playsound sakai_chargef @s
execute as @s[scores={voice=6}] run playsound natasha_chargef @s
execute as @s[scores={voice=7}] run playsound dimitri_chargef @s
execute as @s[scores={voice=8}] run playsound charlotte_chargef @s