replaceitem entity @e slot.armor.head 0 diamond_helmet
replaceitem entity @e slot.armor.chest 0 minecraft:diamond_chestplate
replaceitem entity @e slot.armor.legs 0 minecraft:diamond_leggings
replaceitem entity @e slot.armor.feet 0 minecraft:diamond_boots

