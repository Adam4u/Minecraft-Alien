
scoreboard players set @s model1912ammo 14