effect @s[has_property={tww:scope="s1"}] slowness infinite 3 true
effect @s[has_property={tww:scope="s2"}] slowness infinite 5 true
effect @s[has_property={tww:scope="s3"}] slowness infinite 6 true
effect @s[has_property={tww:scope="s4"}] slowness infinite 7 true
effect @s[has_property={tww:scope="s5"}] slowness infinite 9 true
effect @s[has_property={tww:scope="s0"}] clear slowness