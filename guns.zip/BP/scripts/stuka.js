import { world, system } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";

const PLANE_ID = "ww:stukam";
const ITEM_ID = "ww:stuka";
const BOMB_ID = "ww:stukabomb";

const BOMB_SOUND = "ww:stukabomb";
const BOMB_RELEASE_SOUND = "ww:bombrelease";

// ==================================================
// CẤU HÌNH
// ==================================================

const FIRST_SOUND_DELAY = 10 * 20;
const FIRST_SPAWN_DELAY = 30 * 20;

// Sau khi lần 1 spawn thất bại đủ 4 lần:
// chờ 20 giây rồi mới bắt đầu retry.
const RETRY_START_DELAY = 20 * 20;

// Tính từ lúc retry bắt đầu:
// +10 giây -> sound
// +30 giây -> spawn
const RETRY_SOUND_DELAY = 10 * 20;
const RETRY_SPAWN_DELAY = 30 * 20;

// Mỗi lần spawn thử tối đa 4 lần
const SPAWN_RETRY_ATTEMPTS = 4;

// Khoảng cách giữa các lần thử
const SPAWN_RETRY_DELAY = 2;

const PLANE_SPEED = 1.5;
const CLIMB_SPEED = 0.2;

const TARGET_MIN = 0;
const TARGET_MAX = 50;

const HEIGHT_MIN = 30;
const HEIGHT_MAX = 100;

const SPAWN_DISTANCE = 60;

const SOUND_RADIUS = 100;
const BOMB_RELEASE_RADIUS = 40;

const DESPAWN_DELAY = 4 * 20;

// Máy bay được coi là đã bay vào/bay qua target
// nếu nằm trong bán kính này.
const TARGET_TOLERANCE = 2.5;


// ==================================================
// DATA RIÊNG CHO TỪNG MÁY BAY
// ==================================================

const planeData = new Map();


// ==================================================
// LOOP TIMER
//
// Bình thường = null -> không có loop quét.
// Chỉ được tạo sau khi Stuka spawn thành công.
// ==================================================

let planeLoopTimer = null;


// ==================================================
// TẠO VỊ TRÍ SPAWN
// RANDOM CÁCH TARGET 60 BLOCK
// ==================================================

function createSpawnLocation(target, targetHeight) {

    const angle =
        Math.random() * Math.PI * 2;

    const spawnX =
        target.x +
        Math.cos(angle) * SPAWN_DISTANCE;

    const spawnZ =
        target.z +
        Math.sin(angle) * SPAWN_DISTANCE;

    const spawnY =
        target.y +
        targetHeight;

    return {
        x: spawnX,
        y: spawnY,
        z: spawnZ
    };
}


// ==================================================
// TÍNH HƯỚNG MÁY BAY VỀ TARGET
// ==================================================

function getYawToTarget(spawnLocation, target) {

    const dx =
        target.x -
        spawnLocation.x;

    const dz =
        target.z -
        spawnLocation.z;

    return (
        Math.atan2(-dx, dz) *
        180 /
        Math.PI
    );
}


// ==================================================
// PHÁT ÂM THANH STUKABOMB
// ==================================================

function playBombSound(dimension, target) {

    try {

        dimension.runCommand(
            `playsound ${BOMB_SOUND} @a[x=${target.x},y=${target.y},z=${target.z},r=${SOUND_RADIUS}] ${target.x} ${target.y} ${target.z} 1 1 1`
        );

    } catch (error) {

        console.warn(
            `[Stuka] Could not play ${BOMB_SOUND}: ${error}`
        );

    }
}


// ==================================================
// SPAWN STUKA
//
// isRetry = false -> lần 1
// isRetry = true  -> lần 2
//
// attempt = số lần đã thử
// ==================================================

function spawnStukaMission(
    mission,
    isRetry = false,
    attempt = 0
) {

    const {
        player,
        dimension,
        target,
        targetHeight
    } = mission;


    // ==================================================
    // RANDOM VỊ TRÍ SPAWN
    // ==================================================

    const spawnLocation =
        createSpawnLocation(
            target,
            targetHeight
        );


    // ==================================================
    // TÍNH HƯỚNG BAY
    // ==================================================

    const yaw =
        getYawToTarget(
            spawnLocation,
            target
        );


    try {

        // ==================================================
        // SPAWN MÁY BAY
        // ==================================================

        const plane =
            dimension.spawnEntity(
                PLANE_ID,
                spawnLocation
            );


        // ==================================================
        // XOAY MÁY BAY VỀ TARGET
        // ==================================================

        plane.setRotation({
            x: 0,
            y: yaw
        });


        // ==================================================
        // DATA RIÊNG CHO MÁY BAY
        // ==================================================

        planeData.set(
            plane.id,
            {
                projectileSpawned: false,

                despawnTimer: 0,

                target: {
                    ...target
                },

                previousLocation: {
                    x: spawnLocation.x,
                    y: spawnLocation.y,
                    z: spawnLocation.z
                }
            }
        );


        // ==================================================
        // STUKA SPAWN THÀNH CÔNG
        // MỚI BẬT LOOP XỬ LÝ MÁY BAY
        // ==================================================

        startPlaneLoop();


        console.warn(
            `[Stuka] Aircraft spawned successfully. Retry: ${isRetry}`
        );


        return true;


    } catch (error) {

        console.warn(
            `[Stuka] Aircraft spawn attempt failed. Retry: ${isRetry}. Attempt: ${attempt + 1}/${SPAWN_RETRY_ATTEMPTS}. Error: ${error}`
        );


        // ==================================================
        // CHƯA ĐỦ 4 LẦN -> THỬ LẠI
        // ==================================================

        if (
            attempt + 1 <
            SPAWN_RETRY_ATTEMPTS
        ) {

            system.runTimeout(() => {

                spawnStukaMission(
                    mission,
                    isRetry,
                    attempt + 1
                );

            }, SPAWN_RETRY_DELAY);


            return false;
        }


        // ==================================================
        // ĐÃ FAIL ĐỦ 4 LẦN
        // ==================================================

        if (!isRetry) {

            player.sendMessage(
                "§cAircraft malfunction detected. The mission will be attempted again."
            );


            // ==================================================
            // CHỜ 20 GIÂY
            // RỒI MỚI BẮT ĐẦU RETRY
            // ==================================================

            system.runTimeout(() => {

                console.warn(
                    "[Stuka] Retry mission started."
                );


                // ==================================================
                // RETRY:
                // +10 GIÂY -> SOUND
                // ==================================================

                system.runTimeout(() => {

                    playBombSound(
                        dimension,
                        target
                    );

                }, RETRY_SOUND_DELAY);


                // ==================================================
                // RETRY:
                // +30 GIÂY -> SPAWN
                // ==================================================

                system.runTimeout(() => {

                    spawnStukaMission(
                        mission,
                        true,
                        0
                    );

                }, RETRY_SPAWN_DELAY);

            }, RETRY_START_DELAY);

        } else {

            // ==================================================
            // LẦN 2 CŨNG FAIL ĐỦ 4 LẦN
            // ==================================================

            player.sendMessage(
                "§cAircraft malfunction detected. Mission aborted."
            );
        }


        return false;
    }
}


// ==================================================
// GỌI STUKA BẰNG ITEM
// ==================================================

world.afterEvents.itemUse.subscribe(async (event) => {

    const player = event.source;
    const item = event.itemStack;

    if (!player) return;
    if (!item) return;

    if (item.typeId !== ITEM_ID) return;


    // ==================================================
    // GUI
    // ==================================================

    const form =
        new ModalFormData()
            .title("Stuka Target")

            .toggle(
                "Use exact target coordinates",
                false
            )

            .textField(
                "Target distance in front of you (0-50 blocks)",
                "Enter a number from 0 to 50",
                "0"
            )

            .textField(
                "Exact Target X",
                "Example: 100",
                "0"
            )

            .textField(
                "Exact Target Y",
                "Example: 64",
                "0"
            )

            .textField(
                "Exact Target Z",
                "Example: -200",
                "0"
            )

            .textField(
                "Aircraft height above target (minimum 30 blocks)",
                "Enter height above the target",
                "30"
            );


    let result;


    try {

        result =
            await form.show(player);

    } catch (error) {

        console.warn(
            `[Stuka] Could not open GUI: ${error}`
        );

        return;
    }


    // ==================================================
    // HỦY GUI
    // ==================================================

    if (result.canceled) {
        return;
    }


    // ==================================================
    // ĐỌC GUI
    // ==================================================

    const useExactCoordinates =
        Boolean(result.formValues?.[0]);

    const targetDistance =
        Number(result.formValues?.[1]);

    const exactX =
        Number(result.formValues?.[2]);

    const exactY =
        Number(result.formValues?.[3]);

    const exactZ =
        Number(result.formValues?.[4]);

    const targetHeight =
        Number(result.formValues?.[5]);


    // ==================================================
    // KIỂM TRA ĐỘ CAO
    // ==================================================

    if (!Number.isFinite(targetHeight)) {

        player.sendMessage(
            "§cInvalid input. Please enter a number for aircraft height."
        );

        return;
    }


    if (targetHeight < HEIGHT_MIN) {

        player.sendMessage(
            "§cInvalid aircraft height. Minimum is 30 blocks."
        );

        return;
    }


    if (targetHeight > HEIGHT_MAX) {

        player.sendMessage(
            "§cInvalid aircraft height. Maximum is 100 blocks."
        );

        return;
    }


    // ==================================================
    // TARGET
    // ==================================================

    let target;


    // ==================================================
    // CHẾ ĐỘ TỌA ĐỘ CHÍNH XÁC
    // ==================================================

    if (useExactCoordinates) {

        if (
            !Number.isFinite(exactX) ||
            !Number.isFinite(exactY) ||
            !Number.isFinite(exactZ)
        ) {

            player.sendMessage(
                "§cInvalid exact coordinates."
            );

            return;
        }


        target = {

            x: exactX,

            y: exactY,

            z: exactZ
        };

    } else {

        // ==================================================
        // CHẾ ĐỘ KHOẢNG CÁCH PHÍA TRƯỚC
        // ==================================================

        if (!Number.isFinite(targetDistance)) {

            player.sendMessage(
                "§cInvalid target distance."
            );

            return;
        }


        if (
            targetDistance < TARGET_MIN ||
            targetDistance > TARGET_MAX
        ) {

            player.sendMessage(
                `§cTarget distance must be between ${TARGET_MIN} and ${TARGET_MAX} blocks.`
            );

            return;
        }


        const viewDirection =
            player.getViewDirection();


        const horizontalLength =
            Math.sqrt(
                viewDirection.x *
                viewDirection.x +

                viewDirection.z *
                viewDirection.z
            );


        if (horizontalLength <= 0.0001) {

            player.sendMessage(
                "§cUnable to determine target direction."
            );

            return;
        }


        const directionX =
            viewDirection.x /
            horizontalLength;

        const directionZ =
            viewDirection.z /
            horizontalLength;


        target = {

            x:
                player.location.x +
                directionX *
                targetDistance,

            y:
                player.location.y,

            z:
                player.location.z +
                directionZ *
                targetDistance
        };
    }


    // ==================================================
    // MISSION DATA
    // ==================================================

    const mission = {

        player:
            player,

        dimension:
            player.dimension,

        target:
            target,

        targetHeight:
            targetHeight
    };


    // ==================================================
    // LẦN 1:
    // SAU 10 GIÂY PHÁT SOUND
    // ==================================================

    system.runTimeout(() => {

        playBombSound(
            player.dimension,
            target
        );

    }, FIRST_SOUND_DELAY);


    // ==================================================
    // LẦN 1:
    // SAU 30 GIÂY SPAWN
    // ==================================================

    system.runTimeout(() => {

        spawnStukaMission(
            mission,
            false,
            0
        );

    }, FIRST_SPAWN_DELAY);

});


// ==================================================
// LOOP XỬ LÝ MÁY BAY
//
// CHỈ ĐƯỢC BẬT SAU KHI STUKA SPAWN THÀNH CÔNG.
// KHÔNG CÓ STUKA -> KHÔNG CÓ LOOP QUÉT.
// ==================================================

function startPlaneLoop() {

    // Nếu loop đã chạy thì không tạo thêm loop.
    if (planeLoopTimer !== null) {
        return;
    }


    planeLoopTimer =
        system.runInterval(() => {

            let foundPlane = false;


            for (const dimensionId of [
                "overworld",
                "nether",
                "the_end"
            ]) {

                const dimension =
                    world.getDimension(
                        dimensionId
                    );


                const planes =
                    dimension.getEntities({
                        type: PLANE_ID
                    });


                // ==================================================
                // KHÔNG CÓ MÁY BAY -> BỎ QUA
                // ==================================================

                if (planes.length === 0) {
                    continue;
                }


                // Có ít nhất một Stuka.
                foundPlane = true;


                // ==================================================
                // XỬ LÝ TỪNG MÁY BAY
                // ==================================================

                for (const plane of planes) {

                    try {

                        let data =
                            planeData.get(
                                plane.id
                            );


                        // ==================================================
                        // ENTITY KHÔNG CÓ DATA
                        // ==================================================

                        if (!data) {

                            data = {

                                projectileSpawned: false,

                                despawnTimer: 0,

                                target: null,

                                previousLocation: {

                                    x:
                                        plane.location.x,

                                    y:
                                        plane.location.y,

                                    z:
                                        plane.location.z

                                }

                            };


                            planeData.set(
                                plane.id,
                                data
                            );
                        }


                        // ==================================================
                        // LƯU VỊ TRÍ TRƯỚC KHI TP
                        // ==================================================

                        const previousLocation = {

                            x:
                                plane.location.x,

                            y:
                                plane.location.y,

                            z:
                                plane.location.z

                        };


                        // ==================================================
                        // CHO MÁY BAY BAY
                        //
                        // +0.2 Y
                        // +1.5 BLOCK PHÍA TRƯỚC
                        // ==================================================

                        plane.runCommand(
                            `tp @s ^ ^+${CLIMB_SPEED} ^${PLANE_SPEED}`
                        );


                        // ==================================================
                        // SAU TP LẤY VỊ TRÍ MỚI
                        // ==================================================

                        const currentLocation = {

                            x:
                                plane.location.x,

                            y:
                                plane.location.y,

                            z:
                                plane.location.z

                        };


                        // ==================================================
                        // KIỂM TRA TARGET
                        // ==================================================

                        if (
                            !data.projectileSpawned &&
                            data.target
                        ) {

                            const target =
                                data.target;


                            const dx =
                                currentLocation.x -
                                previousLocation.x;

                            const dz =
                                currentLocation.z -
                                previousLocation.z;


                            const movementLengthSq =
                                dx * dx +
                                dz * dz;


                            let targetReached = false;


                            // ==================================================
                            // CÁCH 1:
                            // MÁY BAY ĐANG Ở TRONG TARGET TOLERANCE
                            // ==================================================

                            const currentDistance =
                                Math.sqrt(
                                    (
                                        currentLocation.x -
                                        target.x
                                    ) *
                                    (
                                        currentLocation.x -
                                        target.x
                                    ) +

                                    (
                                        currentLocation.z -
                                        target.z
                                    ) *
                                    (
                                        currentLocation.z -
                                        target.z
                                    )
                                );


                            if (
                                currentDistance <=
                                TARGET_TOLERANCE
                            ) {

                                targetReached = true;
                            }


                            // ==================================================
                            // CÁCH 2:
                            // MÁY BAY BAY QUA TARGET TRONG TICK NÀY
                            // ==================================================

                            if (
                                !targetReached &&
                                movementLengthSq > 0
                            ) {

                                const targetVectorX =
                                    target.x -
                                    previousLocation.x;

                                const targetVectorZ =
                                    target.z -
                                    previousLocation.z;


                                const t =
                                    (
                                        targetVectorX * dx +
                                        targetVectorZ * dz
                                    ) /
                                    movementLengthSq;


                                if (
                                    t >= 0 &&
                                    t <= 1
                                ) {

                                    const closestX =
                                        previousLocation.x +
                                        dx * t;

                                    const closestZ =
                                        previousLocation.z +
                                        dz * t;


                                    const distanceToLine =
                                        Math.sqrt(
                                            (
                                                target.x -
                                                closestX
                                            ) *
                                            (
                                                target.x -
                                                closestX
                                            ) +

                                            (
                                                target.z -
                                                closestZ
                                            ) *
                                            (
                                                target.z -
                                                closestZ
                                            )
                                        );


                                    if (
                                        distanceToLine <=
                                        TARGET_TOLERANCE
                                    ) {

                                        targetReached = true;
                                    }
                                }
                            }


                            // ==================================================
                            // LƯU VỊ TRÍ
                            // ==================================================

                            data.previousLocation = {
                                ...currentLocation
                            };


                            // ==================================================
                            // BAY VÀO / BAY QUA TARGET
                            // -> THẢ BOM NGAY
                            // ==================================================

                            if (targetReached) {

                                try {

                                    const bombLocation = {

                                        x:
                                            currentLocation.x,

                                        y:
                                            currentLocation.y - 2,

                                        z:
                                            currentLocation.z
                                    };


                                    // ==================================================
                                    // SPAWN BOMB
                                    // ==================================================

                                    dimension.spawnEntity(
                                        BOMB_ID,
                                        bombLocation
                                    );


                                    // ==================================================
                                    // ÂM THANH BOMBRELEASE
                                    // ==================================================

                                    dimension.runCommand(
                                        `playsound ${BOMB_RELEASE_SOUND} @a[x=${bombLocation.x},y=${bombLocation.y},z=${bombLocation.z},r=${BOMB_RELEASE_RADIUS}] ${bombLocation.x} ${bombLocation.y} ${bombLocation.z} 1 1 1`
                                    );


                                    // ==================================================
                                    // ĐÁNH DẤU ĐÃ THẢ
                                    // ==================================================

                                    data.projectileSpawned = true;


                                    // ==================================================
                                    // 4 GIÂY SAU XÓA MÁY BAY
                                    // ==================================================

                                    data.despawnTimer =
                                        DESPAWN_DELAY;


                                } catch (error) {

                                    console.warn(
                                        `[Stuka] Could not spawn ${BOMB_ID}: ${error}`
                                    );
                                }
                            }
                        }


                        // ==================================================
                        // SAU KHI THẢ BOM -> ĐẾM 4 GIÂY
                        // ==================================================

                        if (
                            data.projectileSpawned &&
                            data.despawnTimer > 0
                        ) {

                            data.despawnTimer--;


                            if (
                                data.despawnTimer <= 0
                            ) {

                                plane.remove();

                                planeData.delete(
                                    plane.id
                                );

                                continue;
                            }
                        }


                    } catch (error) {

                        // Entity không còn tồn tại
                        // -> xóa data khỏi Map

                        planeData.delete(
                            plane.id
                        );
                    }
                }
            }


            // ==================================================
            // KHÔNG CÒN STUKA
            //
            // TẮT HOÀN TOÀN LOOP QUÉT.
            // ==================================================

            if (!foundPlane) {

                system.clearRun(
                    planeLoopTimer
                );

                planeLoopTimer =
                    null;
            }

        }, 1);
}