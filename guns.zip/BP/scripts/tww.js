import * as mc from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

const { world } = mc;


// ============================================================
// VOICE GUI + SCOREBOARD
// ============================================================

world.afterEvents.itemUse.subscribe(ev => {
    if (ev.itemStack?.typeId !== "willy:gui") return;

    const gui = new ActionFormData()
        .title("Voices_list")
        .button("Arthur_voice")
        .button("Klaus_voice")
        .button("Richard_voice")
        .button("Sakai_voice")
        .button("Takeshi_voice")
        .button("Natasha_voice")
        .button("Dimitri_voice")
        .button("Charlotte_voice")
        .button("Voice_reset");

    gui.show(ev.source).then(res => {
        if (res.canceled || res.selection === undefined) {
            return;
        }

        const voice = res.selection === 8
            ? 0
            : res.selection + 1;

        try {
            ev.source.runCommand(
                `scoreboard players set @s voice ${voice}`
            );
        } catch {}
    }).catch(() => {});
});


// ============================================================
// HITMARKER + BLOOD + HURTVOICE
// ============================================================

world.afterEvents.entityHurt.subscribe(ev => {

    const src = ev.damageSource?.damagingEntity;
    const proj = ev.damageSource?.damagingProjectile;


    // --------------------------------------------------------
    // HITMARKER
    // --------------------------------------------------------

    if (
        src?.typeId === "minecraft:player" &&
        proj?.typeId?.startsWith("ww:")
    ) {
        try {
            src.runCommand(
                "title @s title hud@hitmark"
            );
        } catch {}
    }


    // --------------------------------------------------------
    // BLOOD
    // --------------------------------------------------------

    if (ev.hurtEntity?.typeId === "minecraft:player") {

        try {
            ev.hurtEntity.runCommand(
                "title @s title hud@blood"
            );
        } catch {}


        // ----------------------------------------------------
        // HURT VOICE
        // ----------------------------------------------------

        try {
            ev.hurtEntity.runCommand(
                "function hurtvoice"
            );
        } catch {}
    }
});


// ============================================================
// DEADVOICE
// ============================================================
//
// Khi player chết:
// → chạy function deadvoice
// ============================================================

world.afterEvents.entityDie.subscribe(ev => {

    const deadEntity = ev.deadEntity;

    if (deadEntity?.typeId !== "minecraft:player") {
        return;
    }

    try {
        deadEntity.runCommand(
            "function deadvoice"
        );
    } catch {}
});