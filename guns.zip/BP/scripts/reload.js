import { world, system } from "@minecraft/server";

// ===================== CẤU HÌNH =====================
// Danh sách súng theo từng loại pouch.
// pouch/points ở đây là mức MẶC ĐỊNH cho cả loại (dùng khi súng không có trong GUN_RATES).
const POUCHES = {
  "ww:mgpouch": {
    pouch: 1, points: 1,
    guns: ["ww:type11", "ww:mg34b", "ww:mg42b", "ww:mg42", "ww:type96",
           "ww:bar", "ww:fg42", "ww:lewis", "ww:dp28", "ww:stinger"],
  },
  "ww:smgpouch": {
    pouch: 1, points: 1,
    guns: ["ww:pps43", "ww:ppd40", "ww:mp28", "ww:ppsh41b", "ww:mab38", "ww:ppsh41d",
           "ww:mp40", "ww:m3a1", "ww:m1928a1", "ww:thompson", "ww:type100", "ww:type2a"],
  },
  "ww:pistolpouch": {
    pouch: 1, points: 1,
    guns: ["ww:mas35", "ww:p38", "ww:p08", "ww:m1911", "ww:tt33", "ww:c96sch"],
  },
  "ww:revolverpouch": {
    pouch: 1, points: 1,
    guns: ["ww:nagant"],
  },
  "ww:shotgunpouch": {
    pouch: 1, points: 1,
    guns: ["ww:model1912"],
  },
  "ww:riflepouch": {
    pouch: 1, points: 1,
    guns: ["ww:type99", "ww:m1903", "ww:pzb39", "ww:kar98", "ww:mosin", "ww:g43", "ww:svt38", "ww:garand"],
  },
  "ww:asriflepouch": {
    pouch: 1, points: 1,
    guns: ["ww:stg44"],
  },
  "ww:bazookarocket": {
    pouch: 1, points: 1,
    guns: ["ww:bazooka", "ww:panzershreck"],
  },
  "ww:fueltank": {
    pouch: 1, points: 1,
    guns: ["ww:m2flame"],
  },
};

// Mức đổi RIÊNG từng súng.
//   pouch  = số pouch bị trừ mỗi lần đổi
//   points = số điểm cộng vào scoreboard <tên súng>ammo mỗi lần đổi
// Xóa hoặc bỏ trống một dòng thì súng đó dùng mức mặc định của loại pouch ở trên.
const GUN_RATES = {
  // --- mgpouch ---
  "ww:type11":  { pouch: 1, points: 2 },
  "ww:mg34b":   { pouch: 1, points: 1 },
  "ww:mg42b":   { pouch: 1, points: 1 },
  "ww:mg42":    { pouch: 1, points: 1 },
  "ww:type96":  { pouch: 1, points: 1 },
  "ww:bar":     { pouch: 1, points: 1 },
  "ww:fg42":    { pouch: 1, points: 1 },
  "ww:lewis":   { pouch: 1, points: 1 },
  "ww:dp28":    { pouch: 1, points: 1 },
  "ww:stinger": { pouch: 1, points: 1 },

  // --- smgpouch ---
  "ww:pps43":    { pouch: 1, points: 1 },
  "ww:ppd40":    { pouch: 1, points: 1 },
  "ww:mp28":     { pouch: 1, points: 1 },
  "ww:ppsh41b":  { pouch: 1, points: 1 },
  "ww:mab38":    { pouch: 1, points: 1 },
  "ww:ppsh41d":  { pouch: 1, points: 1 },
  "ww:mp40":     { pouch: 1, points: 1 },
  "ww:m3a1":     { pouch: 1, points: 1 },
  "ww:m1928a1":  { pouch: 1, points: 1 },
  "ww:thompson": { pouch: 1, points: 1 },
  "ww:type100":  { pouch: 1, points: 1 },
  "ww:type2a":   { pouch: 1, points: 1 },

  // --- pistolpouch ---
  "ww:mas35":  { pouch: 1, points: 1 },
  "ww:p38":    { pouch: 1, points: 1 },
  "ww:p08":    { pouch: 1, points: 1 },
  "ww:m1911":  { pouch: 1, points: 1 },
  "ww:tt33":   { pouch: 1, points: 1 },
  "ww:c96sch": { pouch: 1, points: 1 },

  // --- revolverpouch ---
  "ww:nagant": { pouch: 1, points: 14 },

  // --- shotgunpouch ---
  "ww:model1912": { pouch: 1, points: 14 },
  "ww:bazooka": { pouch: 1, points: 1 },
  "ww:panzershreck": { pouch: 1, points: 1 },
  "ww:m2flame": { pouch: 1, points: 1 },
  // --- riflepouch ---
  "ww:type99": { pouch: 1, points: 10 },
  "ww:m1903":  { pouch: 1, points: 10 },
  "ww:pzb39":  { pouch: 1, points: 5 },
  "ww:kar98":  { pouch: 1, points: 10 },
  "ww:mosin":  { pouch: 1, points: 10 },

  // --- semipouch ---
  "ww:g43":    { pouch: 1, points: 1 },
  "ww:svt38":  { pouch: 1, points: 1 },
  "ww:garand": { pouch: 1, points: 1 },
};
// =====================================================

// Bảng tra ngược: súng -> loại pouch
export const GUN_TO_POUCH = {};
for (const [pouchId, cfg] of Object.entries(POUCHES)) {
  for (const gun of cfg.guns) GUN_TO_POUCH[gun] = pouchId;
}

function countItem(container, typeId) {
  let total = 0;
  for (let i = 0; i < container.size; i++) {
    const it = container.getItem(i);
    if (it && it.typeId === typeId) total += it.amount;
  }
  return total;
}

// Dùng: /scriptevent ww:pouch ww:bar   (hoặc /scriptevent ww:pouch bar)
system.afterEvents.scriptEventReceive.subscribe((ev) => {
  if (ev.id !== "ww:pouch") return;

  const player = ev.sourceEntity;
  if (!player || player.typeId !== "minecraft:player") return;

  let gun = ev.message.trim();
  if (!gun.includes(":")) gun = `ww:${gun}`;

  const pouchId = GUN_TO_POUCH[gun];
  if (!pouchId) return; // súng không có trong list

  // Mức đổi: mặc định của loại pouch, bị ghi đè bởi mức riêng của súng
  const rate = { ...POUCHES[pouchId], ...(GUN_RATES[gun] ?? {}) };

  const container = player.getComponent("inventory")?.container;
  if (!container) return;

  // Không đủ pouch thì không xảy ra gì cả
  if (countItem(container, pouchId) < rate.pouch) return;

  const res = player.runCommand(`clear @s ${pouchId} 0 ${rate.pouch}`);
  if (res.successCount < 1) return;

  const objName = `${gun.split(":").pop()}ammo`; // ww:bar -> barammo
  const obj =
    world.scoreboard.getObjective(objName) ??
    world.scoreboard.addObjective(objName, objName);

  obj.addScore(player, rate.points);
});