import * as mc from "@minecraft/server";

const { world } = mc;

const FAMILY_TAG_MAP = {
    allies: "allies",
    axis: "axis"
};

world.afterEvents.entitySpawn.subscribe(event => {
    const entity = event.entity;
    if (!entity) return;

    /** @type {mc.EntityTypeFamilyComponent} */
    const familyComp = entity.getComponent("minecraft:type_family");
    if (!familyComp) return;

    const families = familyComp.getTypeFamilies()

    for (const family in FAMILY_TAG_MAP) {
        if (families.includes(family)) {
            const tag = FAMILY_TAG_MAP[family];

            if (!entity.hasTag(tag)) {
                entity.addTag(tag);
            }
        }
    }
});
