import { world } from "@minecraft/server";

/*
============================================================
TANK MG → TANK ANIMATION
============================================================

MG bắn projectile
        ↓
Projectile spawn event
        ↓
Kiểm tra projectile ID
        ↓
Kiểm tra owner có phải MG đã khai báo
        ↓
Tìm entity mà MG đang cưỡi
        ↓
Tank chạy animation:

ww:panthergm
→ animation.panthergm.mg

ww:t3485m
→ animation.t3485m.mg

KHÔNG CÓ TICK LOOP
KHÔNG CÓ runInterval
============================================================
*/


// ============================================================
// MG + PROJECTILE
// ============================================================
//
// Mỗi MG có projectile riêng.
//
// Format:
//
// "entity MG": [
//     "projectile 1",
//     "projectile 2"
// ]
//

const MG_WEAPONS = {

    "ww:mg42tank": [
        "ww:792_projectile"
    ],

    "ww:dp28tank": [
        "ww:792_projectile"
    ],

    "ww:m1919tank": [
        "ww:792_projectile"
    ]

};


// ============================================================
// LẤY OWNER CỦA PROJECTILE
// ============================================================

function getMGProjectileOwner(projectile) {

    let projectileComponent;

    try {
        projectileComponent =
            projectile.getComponent("minecraft:projectile");
    } catch {
        return undefined;
    }

    if (!projectileComponent) {
        return undefined;
    }


    let owner;

    try {
        owner = projectileComponent.owner;
    } catch {
        return undefined;
    }

    if (!owner) {
        return undefined;
    }


    // --------------------------------------------------------
    // Kiểm tra owner có phải MG đã khai báo không
    // --------------------------------------------------------

    const mgType = owner.typeId;

    const projectiles = MG_WEAPONS[mgType];

    if (!projectiles) {
        return undefined;
    }


    // --------------------------------------------------------
    // Kiểm tra projectile có đúng loại đạn của MG không
    // --------------------------------------------------------

    if (!projectiles.includes(projectile.typeId)) {
        return undefined;
    }


    return owner;
}


// ============================================================
// LẤY XE MÀ MG ĐANG CƯỠI
// ============================================================

function getVehicle(entity) {

    try {

        const riding =
            entity.getComponent("minecraft:riding");

        if (!riding) {
            return undefined;
        }


        /*
            QUAN TRỌNG:

            Không dùng:

            riding.entity

            Phải dùng:

            riding.entityRidingOn
        */

        return riding.entityRidingOn;

    } catch {

        return undefined;

    }

}


// ============================================================
// CHẠY ANIMATION TANK
// ============================================================

function playTankMGAnimation(tank) {

    if (!tank) {
        return;
    }


    try {

        const typeId = tank.typeId;


        // Chỉ xử lý entity có namespace ww:
        if (!typeId.startsWith("ww:")) {
            return;
        }


        /*
            ww:panthergm
            ↓
            panthergm

            ww:t3485m
            ↓
            t3485m
        */

        const tankName =
            typeId.substring(3);


        /*
            Tạo tên animation:

            ww:panthergm
            ↓
            animation.panthergm.mg
        */

        const animation =
            `animation.${tankName}.mg`;


        // ----------------------------------------------------
        // Phát animation trực tiếp bằng Script API
        // ----------------------------------------------------

        tank.playAnimation(animation);

    } catch {

        // Entity có thể vừa bị remove/unload.
    }

}


// ============================================================
// PROJECTILE SPAWN EVENT
// ============================================================
//
// Đây KHÔNG phải tick loop.
//
// Chỉ chạy khi entity được spawn.
//

world.afterEvents.entitySpawn.subscribe((event) => {

    const projectile = event.entity;

    if (!projectile) {
        return;
    }


    // ========================================================
    // LẤY ID PROJECTILE
    // ========================================================

    let projectileType;

    try {

        projectileType =
            projectile.typeId;

    } catch {

        return;

    }


    // ========================================================
    // LỌC PROJECTILE
    // ========================================================
    //
    // Chỉ xử lý projectile nằm trong danh sách MG.
    //

    let possibleMG = false;


    for (const projectiles of Object.values(MG_WEAPONS)) {

        if (projectiles.includes(projectileType)) {

            possibleMG = true;

            break;
        }

    }


    // Không phải đạn MG → bỏ qua ngay
    if (!possibleMG) {
        return;
    }


    // ========================================================
    // KIỂM TRA OWNER + MG
    // ========================================================

    const mg =
        getMGProjectileOwner(projectile);

    if (!mg) {
        return;
    }


    // ========================================================
    // TÌM TANK
    // ========================================================

    const tank =
        getVehicle(mg);

    if (!tank) {
        return;
    }


    // ========================================================
    // CHẠY ANIMATION TANK
    // ========================================================

    playTankMGAnimation(tank);

});