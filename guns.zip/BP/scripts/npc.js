import { world } from "@minecraft/server";

// ============================================================
// CONFIG
// ============================================================

const validTypes = [
    "ww:g43m",
    "ww:garandm",
    "ww:mg42m",
    "ww:mg42bm",
    "ww:mg42tank",
    "ww:m1919tank",
    "ww:dp28tank",
    "ww:mp40m",
    "ww:m1903m",
    "ww:bazookamm",
    "ww:model1912m",
    "ww:ppsh41dm",
    "ww:pps43m",
    "ww:m3a1m",
    "ww:barm",
    "ww:stg44m",
    "ww:svt38m",
    "ww:dp28m",
    "ww:mosinm",
    "ww:kar98m",
    "ww:panthergm",
    "ww:kv2m",
    "ww:fireflym",
    "ww:t3485m",
    "ww:tigerh1m",
    "ww:calliopem"
];

// ============================================================
// TANK CAMERA SHAKE
// ============================================================

const tankTypes = [
    "ww:kv2m",
    "ww:fireflym",
    "ww:panthergm",
    "ww:tigerh1m",
    "ww:t3485m",
    "ww:calliopem"
];

const tankShake = [
    {
        min: 0,
        max: 5,
        intensity: 0.8,
        duration: 0.05
    },
    {
        min: 5,
        max: 18,
        intensity: 0.2,
        duration: 0.05
    },
    {
        min: 18,
        max: 40,
        intensity: 0.06,
        duration: 0.05
    }
];

// ============================================================
// SPECIAL ANIMATION LIST
//
// Chỉ cần điền TÊN ANIMATION vào đây.
//
// Nếu animation được gọi và nằm trong list:
//     playanimation @s <animation> none 0 "0" tankac
//
// Nếu không nằm trong list:
//     giữ nguyên lệnh playanimation gốc.
//
// Nếu một animation đồng thời được dùng ở logic bình thường
// và có mặt trong list này thì SPECIAL sẽ được ưu tiên.
// ============================================================

const SPECIAL_ANIMATIONS = [
    "animation.calliopem.shoot",
    "animation.calliopem.shoot_rocket",
    "animation.tigerh1m.shoot",
    "animation.panthergm.shoot",
    "animation.fireflym.shoot",
    "animation.kv2m.shoot",
    "animation.t3485m.shoot"


];

// ============================================================
// NPC / SHOOTER LIST
//
// projectile     = một loại đạn
// projectiles    = nhiều loại đạn
// projectileData = dữ liệu riêng theo từng loại đạn
// mid            = âm thanh gần
// medium         = âm thanh trung
// far            = âm thanh xa
// hit            = function khi NPC bị hit
// animation      = animation riêng
// ============================================================

const shooters = {

    "ww:barm": {
        projectile: "ww:nlmg_projectile",
        mid: "bar_shot_mid",
        far: "bar_shot_far",
        hit: "ushit"
    },

    "ww:m1903m": {
        projectile: "ww:nrifle_projectile",
        mid: "m1903_shot_mid",
        far: "m1903_shot_far",
        hit: "ushit"
    },

    "ww:bazookamm": {
        projectile: "ww:nbazooka_projectile",
        mid: "bazooka_shot_mid",
        far: "bazooka_shot_far",
        hit: "ushit"
    },

    "ww:panthergm": {
        projectile: "ww:75mm_projectile",
        mid: "75mm_shot",
        medium: "75mm_shot_mid",
        far: "75mm_shot_far",
        hit: "tankhit"
    },

    "ww:fireflym": {
        projectile: "ww:75mm_projectile",
        mid: "75mm_shot",
        medium: "75mm_shot_mid",
        far: "75mm_shot_far",
        hit: "tankhit"
    },

    "ww:kv2m": {
        projectile: "ww:152mm_projectile",
        mid: "152mm_shot",
        medium: "152mm_shot_mid",
        far: "152mm_shot_far",
        hit: "tankhit"
    },

    "ww:t3485m": {
        projectile: "ww:75mm_projectile",
        mid: "75mm_shot",
        medium: "75mm_shot_mid",
        far: "75mm_shot_far",
        hit: "tankhit"
    },

    // ========================================================
    // CALLIOPE
    //
    // 75mm projectile:
    // animation.calliopem.shoot
    //
    // 114mm projectile:
    // animation.calliopem.shoot_rocket
    // ========================================================

    "ww:calliopem": {
        projectiles: [
            "ww:50mm_projectile",
            "ww:114mm_projectile"
        ],

        projectileData: {

            "ww:50mm_projectile": {
                mid: "50mm_shot",
                medium: "50mm_shot_mid",
                far: "50mm_shot_far",
                animation: "animation.calliopem.shoot"
            },

            "ww:114mm_projectile": {
                mid: "114mm_shot",
                medium: "114mm_shot_mid",
                far: "114mm_shot_far",
                animation: "animation.calliopem.shoot_rocket"
            }
        },

        hit: "tankhit"
    },

    "ww:tigerh1m": {
        projectile: "ww:88mm_projectile",
        mid: "88mm_shot",
        medium: "88mm_shot_mid",
        far: "88mm_shot_far",
        hit: "tankhit"
    },

    "ww:model1912m": {
        projectile: "ww:nshotgun_projectile",
        mid: "model1912_shot_mid",
        far: "model1912_shot_far",
        hit: "ushit"
    },

    "ww:m3a1m": {
        projectile: "ww:nsmg_projectile",
        mid: "m3a1_shot_mid",
        far: "m3a1_shot_far",
        hit: "ushit"
    },

    "ww:garandm": {
        projectile: "ww:nsemi_projectile",
        mid: "garand_shot_mid",
        far: "garand_shot_far",
        hit: "ushit"
    },

    "ww:mg42m": {
        projectile: "ww:nlmg_projectile",
        mid: "mg42_shot_mid",
        far: "mg42_shot_far",
        hit: "grhit"
    },

    "ww:mg42tank": {
        projectile: "ww:792_projectile",
        mid: "mg42b_shot_mid",
        far: "mg42b_shot_far",
        hit: ""
    },

    "ww:mg42bm": {
        projectile: "ww:nmmg_projectile",
        mid: "mg42b_shot_mid",
        far: "mg42b_shot_far",
        hit: "grhit"
    },

    "ww:mp40m": {
        projectile: "ww:nsmg_projectile",
        mid: "mp40_shot_mid",
        far: "mp40_shot_far",
        hit: "grhit"
    },

    "ww:g43m": {
        projectile: "ww:nsemi_projectile",
        mid: "g43_shot_mid",
        far: "g43_shot_far",
        hit: "grhit"
    },

    "ww:m1919tank": {
        projectile: "ww:792_projectile",
        mid: "stinger_shot_mid",
        far: "stinger_shot_far",
        hit: ""
    },

    "ww:kar98m": {
        projectile: "ww:nrifle_projectile",
        mid: "kar98_shot_mid",
        far: "kar98_shot_mid",
        hit: "grhit"
    },

    "ww:dp28m": {
        projectile: "ww:nlmg_projectile",
        mid: "dp28_shot_mid",
        far: "dp28_shot_far",
        hit: "svhit"
    },

    "ww:dp28tank": {
        projectile: "ww:792_projectile",
        mid: "dp28_shot_mid",
        far: "dp28_shot_far",
        hit: ""
    },

    "ww:mosinm": {
        projectile: "ww:nrifle_projectile",
        mid: "mosin_shot_mid",
        far: "mosin_shot_far",
        hit: "svhit"
    },

    "ww:svt38m": {
        projectile: "ww:nsemi_projectile",
        mid: "svt38_shot_mid",
        far: "svt_shot_far",
        hit: "svhit"
    },

    "ww:ppsh41dm": {
        projectile: "ww:nsmg_projectile",
        mid: "ppsh41d_shot_mid",
        far: "ppsh41d_shot_far",
        hit: "svhit"
    }

};

// ============================================================
// NPC HIT
// ============================================================

world.afterEvents.entityHurt.subscribe((event) => {

    const npc = event.hurtEntity;

    if (!npc) return;

    const data = shooters[npc.typeId];

    if (!data) return;

    if (!data.hit) return;

    try {

        npc.runCommandAsync(
            `function ${data.hit}`
        ).catch((error) => {

            console.warn(
                `[NPC HIT] ${npc.typeId} -> function ${data.hit} FAILED: ${error}`
            );

        });

    } catch (error) {

        console.warn(
            `[NPC HIT] ${npc.typeId} ERROR: ${error}`
        );

    }

});

// ============================================================
// SHOOT + TANK SHAKE
// ============================================================

world.afterEvents.entitySpawn.subscribe((event) => {

    const projectile = event.entity;

    if (!projectile) return;

    // --------------------------------------------------------
    // Tìm loại NPC có thể sở hữu projectile này
    // --------------------------------------------------------

    let shooterType = null;

    for (const type in shooters) {

        const data = shooters[type];

        const canUseProjectile =
            data.projectile === projectile.typeId ||
            data.projectiles?.includes(projectile.typeId);

        if (canUseProjectile) {

            shooterType = type;

            break;
        }

    }

    if (!shooterType) return;

    // --------------------------------------------------------
    // Lấy owner của projectile
    // --------------------------------------------------------

    let comp;

    try {

        comp = projectile.getComponent(
            "minecraft:projectile"
        );

    } catch {

        return;

    }

    if (!comp?.owner) return;

    const shooter = comp.owner;

    // --------------------------------------------------------
    // Chỉ xử lý NPC hợp lệ
    // --------------------------------------------------------

    if (!validTypes.includes(shooter.typeId)) return;

    const data = shooters[shooter.typeId];

    if (!data) return;

    // --------------------------------------------------------
    // Lấy dữ liệu riêng theo loại projectile
    // --------------------------------------------------------

    const shotData =
        data.projectileData?.[projectile.typeId] ?? data;

    try {

        // ====================================================
        // ANIMATION
        // ====================================================

        const animationName =
            shotData.animation ??
            `animation.${shooter.typeId.split(":")[1]}.shoot`;

        // ----------------------------------------------------
        // SPECIAL ANIMATION
        //
        // Nếu animation nằm trong SPECIAL_ANIMATIONS:
        //     playanimation @s <animation> none 0 "0" tankac
        //
        // Nếu không:
        //     giữ nguyên lệnh gốc.
        // ----------------------------------------------------

        if (SPECIAL_ANIMATIONS.includes(animationName)) {

            shooter.runCommandAsync(
                `playanimation @s ${animationName} none 0 "0" tankac`
            ).catch(() => {});

        } else {

            shooter.runCommandAsync(
                `playanimation @s ${animationName}`
            ).catch(() => {});

        }

        // ====================================================
        // SOUND
        // Tank: 3 khoảng cách
        // NPC khác: 2 khoảng cách
        // ====================================================

        if (tankTypes.includes(shooter.typeId)) {

            // 0-20 block: sound gần

            shooter.runCommandAsync(
                `playsound ${shotData.mid} @a[rm=0,r=20]`
            ).catch(() => {});

            // 21-70 block: sound trung

            shooter.runCommandAsync(
                `playsound ${shotData.medium} @a[rm=21,r=70]`
            ).catch(() => {});

            // 71-200 block: sound xa

            shooter.runCommandAsync(
                `playsound ${shotData.far} @a[rm=71,r=200]`
            ).catch(() => {});

        } else {

            // NPC khác: sound gần

            shooter.runCommandAsync(
                `playsound ${shotData.mid} @a[rm=0,r=55]`
            ).catch(() => {});

            // NPC khác: sound xa

            shooter.runCommandAsync(
                `playsound ${shotData.far} @a[rm=56,r=200]`
            ).catch(() => {});

        }

        // ====================================================
        // TANK CAMERA SHAKE
        // ====================================================

        if (tankTypes.includes(shooter.typeId)) {

            for (const shake of tankShake) {

                shooter.runCommandAsync(
                    `camerashake add @a[rm=${shake.min},r=${shake.max}] ${shake.intensity} ${shake.duration} rotational`
                ).catch(() => {});

            }

        }

        // ====================================================
        // FLASH (scriptevent)
        // Không chạy cho tank
        // ====================================================

        if (!tankTypes.includes(shooter.typeId)) {

            shooter.runCommandAsync(
                "scriptevent ww:flash 1"
            ).catch(() => {});

        }

    } catch (error) {

        console.warn(
            `[SHOOT] ${shooter.typeId} ERROR: ${error}`
        );

    }

});