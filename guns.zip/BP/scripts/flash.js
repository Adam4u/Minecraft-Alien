import { world, system } from "@minecraft/server";

// ================= Cấu hình =================
const EVENT_ID = "ww:flash"; // gọi từ bất kỳ entity nào (người chơi, NPC...): /scriptevent ww:flash 1
const LIGHT_BLOCK = "minecraft:light_block_15"; // hạ xuống 10-12 nếu muốn nhẹ hơn
const HOLD_TICKS = 3; // đèn sáng thêm bao nhiêu tick sau phát bắn cuối (phải lớn hơn khoảng cách giữa hai phát mới dùng lại được đèn)
const FORWARD = 1.5; // đặt đèn cách mắt bao nhiêu block theo hướng nhìn (0 = ngay đầu)
const REUSE_DIST = 3; // trong lúc bắn liên tục, entity còn gần đèn cũ trong phạm vi này thì dùng lại
const STORE_KEY = "ww:flash_lights"; // nơi lưu vị trí đèn để dọn nếu server tắt đột ngột

// ================= Trạng thái =================
const flashes = new Map(); // entity.id -> { dim, x, y, z, expiry, timer }  (mỗi entity một đèn)
const stale = []; // đèn chưa xóa được (chunk chưa load), thử lại sau

const dist2 = (a, b) => (a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2;

// ================= Lưu / dọn đèn =================
function persist() {
  const list = [...flashes.values()]
    .map(({ dim, x, y, z }) => ({ dim, x, y, z }))
    .concat(stale);
  try {
    world.setDynamicProperty(
      STORE_KEY,
      list.length ? JSON.stringify(list) : undefined
    );
  } catch {}
}

// Nhiều NPC bắn cùng lúc thì mỗi phát bắn/hết hạn đều đòi lưu. Gom lại: chỉ lưu tối đa 1 lần mỗi tick.
let persistScheduled = false;
function persistSoon() {
  if (persistScheduled) return;
  persistScheduled = true;
  system.run(() => {
    persistScheduled = false;
    persist();
  });
}

// true = xong (đã xóa hoặc không còn đèn), false = chunk chưa load
function tryClear(pos) {
  try {
    const block = world.getDimension(pos.dim).getBlock(pos);
    if (!block) return false;
    if (block.typeId === LIGHT_BLOCK) block.setType("minecraft:air");
    return true;
  } catch {
    return false;
  }
}

function cleanStale() {
  for (let i = stale.length - 1; i >= 0; i--) {
    if (tryClear(stale[i])) stale.splice(i, 1);
  }
  persist();
}

// Chỉ dùng id, không cần entity còn sống: NPC chết hoặc despawn giữa chừng thì đèn vẫn được xóa.
function removeLight(id) {
  const f = flashes.get(id);
  if (!f) return;
  flashes.delete(id);
  system.clearRun(f.timer);
  if (!tryClear(f)) stale.push({ dim: f.dim, x: f.x, y: f.y, z: f.z });
  persistSoon();
}

// Hết hạn: nếu vừa có phát bắn mới kéo dài hạn thì hẹn lại, không thì xóa.
function expire(id) {
  const f = flashes.get(id);
  if (!f) return;
  const left = f.expiry - system.currentTick;
  if (left > 0) {
    f.timer = system.runTimeout(() => expire(id), left);
    return;
  }
  removeLight(id);
}

// ================= Đặt đèn =================
// Thử lần lượt: phía trước nòng -> ngay đầu -> trên đầu. Chỉ đặt vào block không khí.
function findSpot(entity, eye) {
  const dir = entity.getViewDirection();
  const tries = [];
  if (FORWARD > 0) {
    tries.push({
      x: eye.x + dir.x * FORWARD,
      y: eye.y + dir.y * FORWARD,
      z: eye.z + dir.z * FORWARD,
    });
  }
  tries.push(eye, { x: eye.x, y: eye.y + 1, z: eye.z });

  for (const t of tries) {
    const pos = { x: Math.floor(t.x), y: Math.floor(t.y), z: Math.floor(t.z) };
    const block = entity.dimension.getBlock(pos);
    if (block?.typeId === "minecraft:air") return block;
  }
  return undefined;
}

function flash(entity) {
  const id = entity.id;
  const now = system.currentTick;
  const eye = entity.getHeadLocation();
  const cur = flashes.get(id);

  // Bắn liên tục: đèn cũ còn gần thì chỉ kéo dài thời gian, không đặt lại.
  if (cur && cur.dim === entity.dimension.id && dist2(cur, eye) <= REUSE_DIST ** 2) {
    cur.expiry = now + HOLD_TICKS;
    return;
  }

  if (cur) removeLight(id); // đã đi xa: xóa đèn cũ trước

  const block = findSpot(entity, eye);
  if (!block) return;
  block.setType(LIGHT_BLOCK);

  const { x, y, z } = block.location;
  flashes.set(id, {
    dim: entity.dimension.id,
    x,
    y,
    z,
    expiry: now + HOLD_TICKS,
    timer: system.runTimeout(() => expire(id), HOLD_TICKS),
  });
  persistSoon();
}

// ================= Trigger =================
system.afterEvents.scriptEventReceive.subscribe((e) => {
  if (e.id !== EVENT_ID) return;
  const entity = e.sourceEntity;
  if (!entity) return; // gọi từ command block/console thì không có entity
  try {
    flash(entity);
  } catch {
    // entity vừa chết/despawn hoặc chunk chưa load
  }
});

// Dọn đèn sót lại từ lần chạy trước (server tắt đột ngột khi đèn còn tồn tại)
system.runTimeout(() => {
  try {
    const raw = world.getDynamicProperty(STORE_KEY);
    if (typeof raw === "string") stale.push(...JSON.parse(raw));
  } catch {}
  cleanStale();
}, 20);

// Thử lại các đèn chưa xóa được khi có người vào (lúc đó chunk quanh họ đã load)
world.afterEvents.playerSpawn.subscribe(() => {
  if (stale.length > 0) system.runTimeout(cleanStale, 40);
});