export const BulletList = {
    "ww:bazooka_projectile": {
        damage: 80,

        piercing: 1.5
    },
    "ww:152mm_projectile": {
        damage: 80,

        piercing: 1.5
    },
    "ww:nbazooka_projectile": {
        damage: 80,

        piercing: 1.5
    },
    "ww:flame_projectile": {
        damage: 9.0,

        piercing: 3
    },
    "ww:lmg_projectile": {
        damage: 6.0,

        piercing: 0.21
    },
    "ww:lmg_projectile": {
        damage: 6.0,

        piercing: 0.21
    },
    "ww:792_projectile": {
        damage: 6.0,

        piercing: 0.21
    },
    "ww:nlmg_projectile": {
        damage: 4.0,

        piercing: 0.21
    },
    "ww:lmgs_projectile": {
        damage: 7.5,

        piercing: 0.21
    },
    "ww:mmg_projectile": {
        damage: 5.0,

        piercing: 0.21
    },
    "ww:mmg_projectile": {
        damage: 5.0,

        piercing: 0.21
    },
    "ww:mmgs_projectile": {
        damage: 8.0,

        piercing: 0.21
    },
    "ww:smg_projectile": {
        damage: 6.0,

        piercing: 0.21
    },
    "ww:nsmg_projectile": {
        damage: 4.0,

        piercing: 0.21
    },
    "ww:smgs_projectile": {
        damage: 6.5,

        piercing: 0.21
    },
    "ww:smgsnip_projectile": {
        damage: 6.5,

        piercing: 0.21
    },
    "ww:pistol_projectile": {
        damage: 7.0,

        piercing: 0.21
    },
    "ww:pistols_projectile": {
        damage: 9.0,

        piercing: 0.21
    },
    "ww:revolver_projectile": {
        damage: 15.0,

        piercing: 2
    },
    "ww:revolvers_projectile": {
        damage: 17.0,

        piercing: 2
    },
    "ww:rifle_projectile": {
        damage: 19.0,

        piercing: 2
    },
    "ww:nrifle_projectile": {
        damage: 15.0,

        piercing: 2
    },
    "ww:rifles_projectile": {
        damage: 31.0,

        piercing: 3
    },
    "ww:riflesnip_projectile": {
        damage: 37.0,

        piercing: 5
    },
    "ww:shotgun_projectile": {
        damage: 6,

        piercing: 0.15
    },
    "ww:nshotgun_projectile": {
        damage: 18,

        piercing: 0.15
    },
    "ww:shotguns_projectile": {
        damage: 7.5,

        piercing: 0.15
    },
    "ww:asrifle_projectile": {
        damage: 7.2,

        piercing: 1
    },
    "ww:asrifles_projectile": {
        damage: 9.5,

        piercing: 1
    },
    "ww:semi_projectile": {
        damage: 10.0,

        piercing: 1.7
    },
    "ww:nsemi_projectile": {
        damage: 8.0,

        piercing: 1.7
    },
    "ww:semis_projectile": {
        damage: 14.0,

        piercing: 2.4
    },

   "ww:pzb39_projectile": {
        damage: 35,

        piercing: 10.0
    },
    "ww:pzb39s_projectile": {
        damage: 50,

        piercing: 10.0
    }
};
