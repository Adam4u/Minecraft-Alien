//code by uncxrafter
import { world, system, MolangVariableMap } from "@minecraft/server";
import { BulletList } from "./list.js"


// ============================================================
// PROJECTILE HIT BLOCK
// ============================================================

world.afterEvents.projectileHitBlock.subscribe((e) => {

    const {
        projectile,
        location,
        hitVector,
        source,
        dimension
    } = e;

    const {
        block,
        face,
        faceLocation
    } = e.getBlockHit();


    // --------------------------------------------------------
    // Chỉ xử lý projectile trong BulletList
    // --------------------------------------------------------

    if (!BulletList[projectile.typeId]) return;


    // --------------------------------------------------------
    // CRACK SOUND
    // --------------------------------------------------------
    // Chạy sau 1 tick để tránh trường hợp sound bị hụt
    // khi projectileHitBlock vừa được xử lý.
    //
    // Chỉ player trong bán kính 25 block nghe.
    // --------------------------------------------------------

    system.run(() => {
        playCrackSound(dimension, location);
    });


    // --------------------------------------------------------
    // BREAK BLOCK
    // --------------------------------------------------------

    const isBlockDestroyed = breakBlocks(block);

    if (isBlockDestroyed) return;


    // --------------------------------------------------------
    // BULLET HOLE
    // --------------------------------------------------------

    bulletHole(
        dimension,
        projectile,
        location,
        block,
        face
    );


    // --------------------------------------------------------
    // SMOKE
    // --------------------------------------------------------

    bulletSmoke(
        dimension,
        location
    );


    // --------------------------------------------------------
    // BLOCK HIT SOUND
    // --------------------------------------------------------

    playSound(
        dimension,
        location,
        block
    );

});


// ============================================================
// BREAKABLE BLOCKS
// ============================================================

const breakableBlocks = [
    "minecraft:glass",
    "minecraft:glass_pane",
					"white_stained_glass",
					"orange_stained_glass",
					"magenta_stained_glass",
					"light_blue_stained_glass",
					"yellow_stained_glass",
					"lime_stained_glass",
					"pink_stained_glass",
					"gray_stained_glass",
					"light_gray_stained_glass",
					"cyan_stained_glass",
					"purple_stained_glass",
					"blue_stained_glass",
					"brown_stained_glass",
					"green_stained_glass",
					"red_stained_glass",
					"black_stained_glass",
					"white_stained_glass_pane",
					"orange_stained_glass_pane",
					"magenta_stained_glass_pane",
					"light_blue_stained_glass_pane",
					"yellow_stained_glass_pane",
					"lime_stained_glass_pane",
					"pink_stained_glass_pane",
					"gray_stained_glass_pane",
					"light_gray_stained_glass_pane",
					"cyan_stained_glass_pane",
					"purple_stained_glass_pane",
					"blue_stained_glass_pane",
					"brown_stained_glass_pane",
					"green_stained_glass_pane",
					"red_stained_glass_pane",
					"black_stained_glass_pane"
];


// ============================================================
// METAL BLOCKS
// ============================================================
// Tất cả ID đã được chuẩn hóa thành minecraft:
// để khớp với block.typeId.
// ============================================================

const metalicBlocks = [

    "minecraft:chiseled_copper",
    "minecraft:weathered_chiseled_copper",
    "minecraft:oxidized_chiseled_copper",
    "minecraft:waxed_weathered_chiseled_copper",
    "minecraft:waxed_oxidized_chiseled_copper",
    "minecraft:waxed_chiseled_copper",
    "minecraft:exposed_chiseled_copper",
    "minecraft:waxed_exposed_chiseled_copper",

    "minecraft:copper_block",
    "minecraft:raw_copper_block",
    "minecraft:raw_gold_block",
    "minecraft:raw_iron_block",

    "minecraft:exposed_copper",
    "minecraft:cut_copper",
    "minecraft:exposed_cut_copper",
    "minecraft:exposed_cut_copper_slab",
    "minecraft:exposed_cut_copper_stairs",

    "minecraft:lightning_rod",

    "minecraft:oxidized_copper",
    "minecraft:oxidized_cut_copper",
    "minecraft:oxidized_cut_copper_slab",
    "minecraft:oxidized_cut_copper_stairs",

    "minecraft:polished_deepslate",
    "minecraft:polished_deepslate_slab",
    "minecraft:polished_deepslate_stairs",
    "minecraft:polished_deepslate_wall",

    "minecraft:waxed_copper_block",
    "minecraft:waxed_cut_copper",
    "minecraft:waxed_cut_copper_slab",
    "minecraft:waxed_cut_copper_stairs",

    "minecraft:waxed_exposed_copper",
    "minecraft:waxed_exposed_cut_copper",
    "minecraft:waxed_exposed_cut_copper_slab",
    "minecraft:waxed_exposed_cut_copper_stairs",

    "minecraft:waxed_oxidized_copper",
    "minecraft:waxed_oxidized_cut_copper",
    "minecraft:waxed_oxidized_cut_copper_slab",
    "minecraft:waxed_oxidized_cut_copper_stairs",

    "minecraft:waxed_weathered_copper",
    "minecraft:waxed_weathered_cut_copper",
    "minecraft:waxed_weathered_cut_copper_slab",
    "minecraft:waxed_weathered_cut_copper_stairs",

    "minecraft:weathered_copper",
    "minecraft:weathered_cut_copper",
    "minecraft:weathered_cut_copper_slab",
    "minecraft:weathered_cut_copper_stairs",

    "minecraft:activator_rail",
    "minecraft:anvil",
    "minecraft:chipped_anvil",
    "minecraft:damaged_anvil",
    "minecraft:blast_furnace",
    "minecraft:cauldron",
    "minecraft:diamond_block",
    "minecraft:grindstone",
    "minecraft:hopper",
    "minecraft:iron_bars",
    "minecraft:iron_block",
    "minecraft:mob_spawner",
    "minecraft:netherite_block",
    "minecraft:rail",

    "minecraft:iron_door",

    "minecraft:copper_door",
    "minecraft:exposed_copper_door",
    "minecraft:weathered_copper_door",
    "minecraft:oxidized_copper_door",

    "minecraft:waxed_copper_door",
    "minecraft:waxed_exposed_copper_door",
    "minecraft:waxed_weathered_copper_door",
    "minecraft:waxed_oxidized_copper_door",

    "minecraft:heavy_weighted_pressure_plate",
    "minecraft:light_weighted_pressure_plate",

    "minecraft:cut_copper_slab",
    "minecraft:cut_copper_stairs",

    "minecraft:trial_spawner",
    "minecraft:vault",
    "minecraft:heavy_core",

    "minecraft:copper_bulb",
    "minecraft:exposed_copper_bulb",
    "minecraft:weathered_copper_bulb",
    "minecraft:oxidized_copper_bulb",

    "minecraft:waxed_copper_bulb",
    "minecraft:waxed_exposed_copper_bulb",
    "minecraft:waxed_weathered_copper_bulb",
    "minecraft:waxed_oxidized_copper_bulb",

    "minecraft:copper_grate",
    "minecraft:exposed_copper_grate",
    "minecraft:weathered_copper_grate",
    "minecraft:oxidized_copper_grate",

    "minecraft:waxed_copper_grate",
    "minecraft:waxed_exposed_copper_grate",
    "minecraft:waxed_weathered_copper_grate",
    "minecraft:waxed_oxidized_copper_grate"

];


// ============================================================
// BREAK BLOCKS
// ============================================================

function breakBlocks(block) {

    if (
        block.isValid &&
        breakableBlocks.includes(block.typeId)
    ) {

        const {
            x,
            y,
            z
        } = block.location;


        block.dimension.runCommand(
            `fill ${x} ${y} ${z} ${x} ${y} ${z} air destroy`
        );


        return true;
    }


    return false;
}


// ============================================================
// BULLET HOLE
// ============================================================

function bulletHole(
    dimension,
    projectile,
    location,
    block,
    face
) {

    const enableBulletHoles = true;


    if (
        !enableBulletHoles ||
        !block.isValid ||
        block.typeId === "minecraft:air" ||
        breakableBlocks.includes(block.typeId)
    ) {
        return;
    }


    const particle =
        BulletHoleParticles[face];


    const blockFaceVector =
        BlockFaceVectors[face];


    if (!particle || !blockFaceVector) {
        return;
    }


    const particleLocation = {

        x:
            location.x +
            blockFaceVector.x,

        y:
            location.y +
            blockFaceVector.y,

        z:
            location.z +
            blockFaceVector.z

    };


    try {

        dimension.spawnParticle(
            particle,
            particleLocation
        );

    } catch (e) {}

}


// ============================================================
// BULLET HOLE DIRECTION
// ============================================================

const DIRECTION_SCALE = 0.025;


const BlockFaceVectors = {

    Up: {
        x: 0,
        y: DIRECTION_SCALE,
        z: 0
    },

    Down: {
        x: 0,
        y: -DIRECTION_SCALE,
        z: 0
    },

    North: {
        x: 0,
        y: 0,
        z: -DIRECTION_SCALE
    },

    South: {
        x: 0,
        y: 0,
        z: DIRECTION_SCALE
    },

    East: {
        x: DIRECTION_SCALE,
        y: 0,
        z: 0
    },

    West: {
        x: -DIRECTION_SCALE,
        y: 0,
        z: 0
    }

};


// ============================================================
// BULLET HOLE PARTICLES
// ============================================================

const BulletHoleParticles = {

    Up:
        "vxg:bullet_hole_y",

    Down:
        "vxg:bullet_hole_y",

    North:
        "vxg:bullet_hole_z",

    South:
        "vxg:bullet_hole_z",

    East:
        "vxg:bullet_hole_x",

    West:
        "vxg:bullet_hole_x"

};


// ============================================================
// BULLET SMOKE
// ============================================================

function bulletSmoke(
    dimension,
    location
) {

    const particle =
        "vxg:bullet_hit_smoke";


    try {

        dimension.spawnParticle(
            particle,
            location
        );

    } catch (e) {}

}


// ============================================================
// HIT BLOCK SOUND LIST
// ============================================================

const bulletHitBlockSounds = new Map([

    [
        "ww.bullet.hit.dirt",
        [

            "minecraft:dirt",
            "minecraft:coarse_dirt",
            "minecraft:podzol",
            "minecraft:rooted_dirt",
            "minecraft:mud",
            "minecraft:muddy_mangrove_roots",
            "minecraft:grass_block",
            "minecraft:mycelium",
            "minecraft:crimson_nylium",
            "minecraft:warped_nylium"

        ]
    ],


    [
        "ww.bullet.hit.water",
        [

            "minecraft:water",
            "minecraft:flowing_water",
            "minecraft:bubble_column",
            "minecraft:kelp",
            "minecraft:seagrass",
            "minecraft:tall_seagrass"

        ]
    ],


    [
        "ww.bullet.hit.metal",
        metalicBlocks
    ],


    [
        "ww.bullet.hit.wood",
        [

            "minecraft:oak_planks",
            "minecraft:birch_planks",
            "minecraft:spruce_planks",
            "minecraft:jungle_planks",
            "minecraft:acacia_planks",
            "minecraft:dark_oak_planks",
            "minecraft:mangrove_planks",
            "minecraft:cherry_planks",
            "minecraft:bamboo_planks",
            "minecraft:crimson_planks",
            "minecraft:warped_planks",


            "minecraft:oak_log",
            "minecraft:birch_log",
            "minecraft:spruce_log",
            "minecraft:jungle_log",
            "minecraft:acacia_log",
            "minecraft:dark_oak_log",
            "minecraft:mangrove_log",
            "minecraft:cherry_log",


            "minecraft:stripped_oak_log",
            "minecraft:stripped_birch_log",
            "minecraft:stripped_spruce_log",
            "minecraft:stripped_jungle_log",
            "minecraft:stripped_acacia_log",
            "minecraft:stripped_dark_oak_log",
            "minecraft:stripped_mangrove_log",
            "minecraft:stripped_cherry_log",


            "minecraft:oak_wood",
            "minecraft:birch_wood",
            "minecraft:spruce_wood",
            "minecraft:jungle_wood",
            "minecraft:acacia_wood",
            "minecraft:dark_oak_wood",
            "minecraft:mangrove_wood",
            "minecraft:cherry_wood",


            "minecraft:stripped_oak_wood",
            "minecraft:stripped_birch_wood",
            "minecraft:stripped_spruce_wood",
            "minecraft:stripped_jungle_wood",
            "minecraft:stripped_acacia_wood",
            "minecraft:stripped_dark_oak_wood",
            "minecraft:stripped_mangrove_wood",
            "minecraft:stripped_cherry_wood",


            "minecraft:bookshelf",
            "minecraft:chest",
            "minecraft:trapped_chest",
            "minecraft:barrel",
            "minecraft:lectern",
            "minecraft:cartography_table",
            "minecraft:fletching_table",
            "minecraft:smithing_table",
            "minecraft:loom",
            "minecraft:composter",
            "minecraft:beehive",
            "minecraft:bee_nest",
            "minecraft:daylight_detector",
            "minecraft:note_block",
            "minecraft:jukebox",
            "minecraft:crafting_table",
            "minecraft:ladder",
            "minecraft:scaffolding",
            "minecraft:campfire",
            "minecraft:soul_campfire",
            "minecraft:wooden_button",
            "minecraft:wooden_pressure_plate",
            "minecraft:wooden_door",
            "minecraft:wooden_trapdoor",
            "minecraft:wooden_fence",
            "minecraft:wooden_fence_gate",
            "minecraft:wooden_slab",
            "minecraft:wooden_stairs"

        ]
    ]

]);


// ============================================================
// CRACK SOUND
// ============================================================
//
// Mỗi player trong bán kính 25 block sẽ tự phát sound.
// Không dùng @a[r=25] để tránh lỗi selector/command.
// Vì playSound được gọi trực tiếp trên từng player nên ổn định hơn.
//
// ============================================================

function playCrackSound(
    dimension,
    location
) {

    try {

        const players =
            dimension.getPlayers({
                location: location,
                maxDistance: 25
            });


        for (const player of players) {

            try {

                player.playSound(
                    "crack",
                    {
                        volume: 3,
                        pitch: 1
                    }
                );

            } catch (e) {}

        }

    } catch (e) {}

}


// ============================================================
// BLOCK HIT SOUND
// ============================================================

function playSound(
    dimension,
    location,
    block
) {

    if (!block.isValid) return;


    let sound = null;


    // --------------------------------------------------------
    // Tìm sound dựa theo block
    // --------------------------------------------------------

    for (
        const [soundId, blocks]
        of bulletHitBlockSounds
    ) {

        if (
            blocks.includes(block.typeId)
        ) {

            sound = soundId;

            break;
        }

    }


    // --------------------------------------------------------
    // Sound mặc định
    // --------------------------------------------------------

    if (!sound) {

        sound =
            "ww.bullet.hit.normal";

    }


    // --------------------------------------------------------
    // Phát sound tại vị trí block
    // --------------------------------------------------------

    try {

        dimension.playSound(
            sound,
            location,
            {
                volume: 17
            }
        );

    } catch (e) {

        console.warn(
            `[BULLET HIT SOUND] Failed to play ${sound}: ${e}`
        );

    }

}


// ============================================================
// WATER CHECK
// ============================================================

/*
const WATER_CHECK_INTERVAL = 1;

const BulletQuery = {
    families: ["projectile"]
};

system.runInterval(() => {

    const bullets =
        OVERWORLD.getEntities(
            BulletQuery
        );

    for (const bullet of bullets) {

        if (
            bullet.getDynamicProperty(
                "hitWater"
            )
        ) continue;


        const block =
            bullet.dimension.getBlock(
                bullet.location
            );


        if (
            block &&
            (
                block.typeId ===
                "minecraft:water" ||

                block.typeId ===
                "minecraft:flowing_water"
            )
        ) {

            console.warn(
                "hit water"
            );


            bullet.setDynamicProperty(
                "hitWater",
                true
            );


            const location =
                bullet.location;


            const sound =
                "ww.bullet.hit.water";


            OVERWORLD.playSound(
                sound,
                location,
                {
                    volume: 17
                }
            );


            bullet.dimension.spawnParticle(
                "adn:test",
                location,
                {
                    volume: 10
                }
            );

        }

    }

}, WATER_CHECK_INTERVAL);
*/


// ============================================================
// CODE BY UNCXRAFTER FOR TWW
// ============================================================