//code by uncxrafter
import {
    world,
    system,
    EntityDamageCause,
    EntityComponentTypes
} from '@minecraft/server';

import {
    setArmorPoints,
    getArmorPoints
} from "./setArmorPoints.js";

import { BulletList } from "./list.js";

// ============================================================
// GUN KILL TRACKER
// ============================================================
//
// Lưu người bắn cuối cùng đã gây damage bằng đạn ww:
// target.id -> player đã bắn
// ============================================================

const gunKillMap = new Map();

// ============================================================
// LẤY NGƯỜI BẮN ĐÃ GÂY DAMAGE
// ============================================================

export function getGunKill(targetId) {
    const shooter = gunKillMap.get(targetId);

    if (!shooter) {
        return undefined;
    }

    // Xóa sau khi đọc
    gunKillMap.delete(targetId);

    if (!shooter.isValid) {
        return undefined;
    }

    if (shooter.typeId !== "minecraft:player") {
        return undefined;
    }

    return shooter;
}

// ============================================================
// PROJECTILE HIT ENTITY
// ============================================================

world.afterEvents.projectileHitEntity.subscribe((event) => {
    const {
        dimension,
        hitVector,
        location,
        projectile,
        source
    } = event;

    const hitEntity = event.getEntityHit().entity;

    // console.warn(hitEntity.typeId)

    if (isTank(hitEntity) && !isAntiTankWeapon(projectile)) return;
    if (BulletList.hasOwnProperty(hitEntity)) return;

    // ========================================================
    // PHẦN THÊM:
    // Lưu người bắn nếu đạn có ID ww:
    // ========================================================

    if (
        source &&
        source.typeId === "minecraft:player" &&
        projectile &&
        projectile.typeId &&
        projectile.typeId.startsWith("ww:") &&
        hitEntity &&
        hitEntity.typeId === "minecraft:player"
    ) {
        gunKillMap.set(hitEntity.id, source);

        // Nếu player không chết sau 1 giây,
        // xóa dữ liệu để tránh lưu quá lâu.
        system.runTimeout(() => {
            const savedShooter = gunKillMap.get(hitEntity.id);

            if (savedShooter === source) {
                gunKillMap.delete(hitEntity.id);
            }
        }, 20);
    }

    // ========================================================
    // CODE CŨ
    // ========================================================

    setGunDamage(source, projectile, hitEntity);

    // printStat(hitEntity, source)
});

// ============================================================
// TANK
// ============================================================

function isTank(entity) {
    const invalidFamilyTypes = [
        "tww-tank",
        "tww-tank-destroyed",
        "tww-tankTurret"
    ];

    let familyType = entity.getComponent(
        EntityComponentTypes.TypeFamily
    );

    for (let type of invalidFamilyTypes) {
        if (familyType.hasTypeFamily(type)) {
            return true;
        }
    }

    return false;
}

// ============================================================
// ANTI TANK WEAPON
// ============================================================

function isAntiTankWeapon(entity) {
    const validTypes = [
        "ww:pzb39_projectile",
        "ww:bazooka_projectile",
        "ww:pz4hmtb"
    ];

    console.warn(
        validTypes.includes(entity.typeId) +
        " checking anti tank weapon " +
        entity.typeId
    );

    return validTypes.includes(entity.typeId);
}

// ============================================================
// DEBUG
// ============================================================

function printStat(hitEntity, source) {
    let playerComp = source.getComponent("equippable");
    let entityComp = hitEntity.getComponent("equippable");

    source.sendMessage(
        "player: " +
        JSON.stringify(playerComp) +
        "\n" +
        "hitEntity: " +
        JSON.stringify(entityComp)
    );
}

function printComponents(entity, player) {
    let components = entity.getComponents();

    player.sendMessage(
        JSON.stringify(components, null, 2)
    );
}

// ============================================================
// GUN DAMAGE
// ============================================================

function setGunDamage(player, projectile, target) {
    if (!target.isValid) return;

    const removeHitAmunity = true;
    const isFriendlyFireEnabled = false;

    // console.warn("hello"+JSON.stringify(isFriendlyFireEnabled))

    if (!isFriendlyFireEnabled) {
        if (isAlly(player, target)) {
            // console.warn("friendly fire prevented")
            return;
        }
    }

    // GunSettings.values.removeHitImmunity.value
    // console.warn(removeHitAmunity)

    if (
        !BulletList.hasOwnProperty(projectile.typeId) ||
        !removeHitAmunity
    ) {
        return;
    }

    const BaseDamage = BulletList[projectile.typeId].damage;
    const armorPiercing = BulletList[projectile.typeId].piercing;

    setArmorPoints(target);

    let armorPoints = getArmorPoints(target);

    // console.warn("armorPoints "+armorPoints)

    if (armorPoints != undefined) {
        let actualDamage = calculateDamageReduction(
            BaseDamage,
            armorPoints,
            armorPiercing
        );

        actualDamage = calculateResistanceDamage(
            player,
            actualDamage
        );

        damage1(
            target,
            actualDamage,
            player,
            projectile
        );
    } else {
        system.runTimeout(() => {
            let armorPoints = getArmorPoints(target);

            let actualDamage = calculateDamageReduction(
                BaseDamage,
                armorPoints,
                armorPiercing
            );

            actualDamage = calculateResistanceDamage(
                player,
                actualDamage
            );

            damage1(
                target,
                actualDamage,
                player,
                projectile
            );
        }, 1);
    }
}

// ============================================================
// DAMAGE 2
// ============================================================

function damage2(entity, damage, damager, projectile) {
    const healthComp = entity.getComponent("health");

    // healthComp.setCurrentValue(healthComp.currentValue - damage)

    entity.applyDamage(
        Math.min(
            damage,
            healthComp.currentValue
        ),
        {
            cause: EntityDamageCause.override,
            damagingEntity: damager
        }
    );

    console.warn(
        "applying damage1 " +
        Math.min(
            damage,
            healthComp.currentValue
        )
    );

    const direction = damager.getViewDirection();

    const vertical = 0.1;
    const horizontal = 0.6;

    direction.x *= horizontal;
    direction.z *= horizontal;

    entity.applyKnockback(
        direction.x,
        direction.z,
        horizontal,
        vertical
    );
}

// ============================================================
// DAMAGE 1
// ============================================================

function damage1(entity, damage, damager, projectile) {
    // console.warn("damager "+JSON.stringify(damager))

    const healthComp = entity.getComponent("health");
    const currentHealth = healthComp.currentValue;

    if (false && damage > currentHealth) {
        damage2(
            entity,
            damage,
            damager,
            projectile
        );

        return;
    }

    entity.applyDamage(damage, {
        cause: EntityDamageCause.override
    });

    applyKnockback(
        entity,
        damager,
        projectile
    );
}

// ============================================================
// KNOCKBACK
// ============================================================

function applyKnockback(entity, damager, projectile) {
    if (!damager || !damager.isValid) return;

    const direction = damager.getViewDirection();

    const vertical =
        BulletList[projectile.typeId].knockback?.vertical || 0.1;

    const horizontal =
        BulletList[projectile.typeId].knockback?.horizontal || 0.1;

    direction.x *= horizontal;
    direction.z *= horizontal;

    entity.applyKnockback(
        direction.x,
        direction.z,
        horizontal,
        vertical
    );
}

// ============================================================
// DAMAGE REDUCTION
// ============================================================

function calculateDamageReduction(
    damage,
    armorPoints,
    armorPiercingValue
) {
    armorPiercingValue = Math.max(
        1 - armorPiercingValue,
        0
    );

    let damageReductionPercent = armorPoints * 4;

    damageReductionPercent *= armorPiercingValue;

    const damageDiminishingFactor = 12;

    const diminishingFactor = Math.min(
        1,
        damage / damageDiminishingFactor
    );

    damageReductionPercent *= (
        1 - 0.1 * diminishingFactor
    );

    const damageReduction =
        (damage * damageReductionPercent) / 100;

    return damage - damageReduction;
}

// ============================================================
// RESISTANCE
// ============================================================

function calculateResistanceDamage(player, damage) {
    let resistanceEffect =
        player.getEffect("resistance");

    if (!resistanceEffect) return damage;

    let resistanceLevel = Math.min(
        resistanceEffect.amplifier + 1,
        5
    );

    const resistanceReduction =
        0.20 * resistanceLevel;

    const finalDamage =
        damage * (1 - resistanceReduction);

    // console.warn (
    //     "damage: "+finalDamage+
    //     " amplifier "+resistanceLevel
    // )

    return finalDamage;
}

// ============================================================
// ALLY
// ============================================================

function isAlly(damager, target) {
    if (
        !damager.hasTag("allies") &&
        !damager.hasTag("axis")
    ) {
        return false;
    }

    let targetTags = target.getTags();

    let damagerTag =
        damager.hasTag("allies")
            ? "allies"
            : "axis";

    // console.warn(
    //     "targetTags "+
    //     JSON.stringify(targetTags)+
    //     " damagerTag "+
    //     damagerTag
    // )

    return targetTags.includes(damagerTag);
}