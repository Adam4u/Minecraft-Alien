import { system, world } from '@minecraft/server';
import { decrementStack, getOppositeDirection, DirectionType, cardinalSides, randomFunction } from './utils/helper';
import { directionToVector3 } from './utils/math';

world.beforeEvents.worldInitialize.subscribe(initEvent => { 

initEvent.itemComponentRegistry.registerCustomComponent('ww_allies:trigger', {
  onUse: e => { e.source.runCommand("function allies"); },
});

initEvent.itemComponentRegistry.registerCustomComponent('ww_axis:trigger', {
  onUse: e => { e.source.runCommand("function axis"); },
});

 });