import { world, system } from "@minecraft/server";
import { ActionFormData, FormCancelationReason } from "@minecraft/server-ui";
import { GUNS, SETTINGS } from "./gunsmith_data.js";

// Ngay sau khi bấm block, client vẫn "bận" nên form bị hủy.
// Thử lại tới khi mở được, tối đa khoảng 5 giây.
async function showForm(player, form, timeoutTicks = 100) {
    const start = system.currentTick;

    while (system.currentTick - start < timeoutTicks) {
        const res = await form.show(player);

        if (!res) {
            return undefined;
        }

        // Người chơi đã chọn nút
        if (!res.canceled) {
            return res;
        }

        // Chỉ thử lại nếu GUI bị UserBusy
        if (res.cancelationReason !== FormCancelationReason.UserBusy) {
            return res;
        }

        // Chờ sang tick tiếp theo rồi thử lại
        await new Promise(resolve => {
            system.run(resolve);
        });
    }

    return undefined;
}

// Slot chỉ hiện nếu có ít nhất 1 option
function usableSlots(gun) {
    return (gun.slots ?? []).filter(
        (slot) => (slot.options ?? []).length > 0
    );
}

// ---------------- CHẠY LỆNH ----------------
function fill(text, ctx) {
    return text
        .replace(/\{player\}/g, ctx.player)
        .replace(/\{gun\}/g, ctx.gun ?? "")
        .replace(/\{slot\}/g, ctx.slot ?? "")
        .replace(/\{option\}/g, ctx.option ?? "");
}

function runCommands(player, commands, ctx) {
    for (const raw of commands ?? []) {
        const cmd = fill(raw, ctx).replace(/^\//, "");

        try {
            player.runCommand(cmd);
        } catch (err) {
            player.sendMessage(`§cCommand failed: §7${cmd}`);
            console.warn(
                `[gunsmith] command failed "${cmd}": ${err}`
            );
        }
    }
}

// ---------------- MENU 1: DANH SÁCH SÚNG ----------------
async function menuGuns(player) {
    // Súng không có slot nào dùng được thì không hiện
    const guns = GUNS.filter(
        (gun) => usableSlots(gun).length > 0
    );

    if (guns.length === 0) {
        player.sendMessage("§cNo guns available.");
        return;
    }

    const form = new ActionFormData()
        .title(SETTINGS.title ?? "Gunsmith")
        .body(SETTINGS.body ?? "");

    for (const gun of guns) {
        form.button(gun.name, gun.icon);
    }

    const res = await showForm(player, form);

    if (!res || res.canceled) {
        return;
    }

    return menuSlots(player, guns[res.selection]);
}

// ---------------- MENU 2: BỘ PHẬN CỦA SÚNG ----------------
async function menuSlots(player, gun) {
    const slots = usableSlots(gun);

    if (slots.length === 0) {
        return menuGuns(player);
    }

    const form = new ActionFormData()
        .title(gun.name)
        .body("Choose an attachment slot:");

    for (const slot of slots) {
        form.button(slot.name, slot.icon);
    }

    form.button(
        "§8« Back",
        SETTINGS.backIcon
    );

    const res = await showForm(player, form);

    if (!res || res.canceled) {
        return;
    }

    // Back
    if (res.selection === slots.length) {
        return menuGuns(player);
    }

    return menuOptions(
        player,
        gun,
        slots[res.selection]
    );
}

// ---------------- MENU 3: LỰA CHỌN -> CHẠY LỆNH ----------------
async function menuOptions(player, gun, slot) {
    const options = slot.options;

    const form = new ActionFormData()
        .title(`${gun.name} §r- ${slot.name}`)
        .body("Choose an attachment:");

    for (const opt of options) {
        form.button(opt.name, opt.icon);
    }

    form.button(
        "§8« Back",
        SETTINGS.backIcon
    );

    const res = await showForm(player, form);

    if (!res || res.canceled) {
        return;
    }

    // Back
    if (res.selection === options.length) {
        return menuSlots(player, gun);
    }

    const opt = options[res.selection];

    runCommands(
        player,
        opt.commands,
        {
            player: player.name,
            gun: gun.id,
            slot: slot.id,
            option: opt.id
        }
    );

    // Mở lại menu option sau khi chọn
    if (SETTINGS.reopenAfterPick) {
        return menuOptions(player, gun, slot);
    }
}

// ---------------- MỞ MENU (CÓ CHỐNG MỞ CHỒNG) ----------------
// Bấm/giữ block nhiều lần sẽ gọi onPlayerInteract nhiều lần.
// Nếu không chặn, form thứ 2 sẽ tự bật lên sau khi đóng form thứ 1.
const opening = new Set();

async function openMenu(player) {
    if (opening.has(player.id)) {
        return;
    }

    opening.add(player.id);

    try {
        await menuGuns(player);
    } catch (err) {
        // Nếu GUI không hiện, xem lỗi ở Content Log
        console.warn(`[gunsmith] menu error: ${err}`);
        player.sendMessage("§cGunsmith menu error. Check the content log.");
    } finally {
        opening.delete(player.id);
    }
}

// ---------------- GẮN VÀO BLOCK CHỈ ĐỊNH ----------------
// Block nào mở GUI: khai trong gunsmith_data.js -> SETTINGS.blockIds
// Ví dụ: blockIds: ["minecraft:smithing_table", "tww:gun_bench"]
// Dùng được cho cả block vanilla lẫn block custom, không cần sửa JSON của block.
const MENU_BLOCKS = new Set(SETTINGS.blockIds ?? []);

if (MENU_BLOCKS.size === 0) {
    console.warn(
        "[gunsmith] SETTINGS.blockIds is empty - no block will open the menu."
    );
}

// API này dùng cho @minecraft/server 1.12.0
world.beforeEvents.playerInteractWithBlock.subscribe((ev) => {
    if (!MENU_BLOCKS.has(ev.block.typeId)) {
        return;
    }

    // Chặn hành vi mặc định của block (mở UI vanilla, đặt block lên trên...)
    ev.cancel = true;

    // Giữ tay trên màn hình sẽ bắn event liên tục -> chỉ nhận lần đầu
    if (ev.isFirstEvent === false) {
        return;
    }

    const player = ev.player;

    // beforeEvents chạy ở chế độ read-only,
    // phải đợi sang tick sau mới mở được GUI
    system.run(() => {
        openMenu(player);
    });
});

// Giữ lại đăng ký cũ để block nào đang gắn component "gunsmith:open_menu"
// trong JSON vẫn không bị lỗi. Cả 2 cách cùng gọi openMenu (đã chống mở chồng).
world.beforeEvents.worldInitialize.subscribe((event) => {
    event.blockComponentRegistry.registerCustomComponent(
        "gunsmith:open_menu",
        {
            onPlayerInteract(ev) {
                const player = ev.player;

                if (!player) {
                    return;
                }

                system.run(() => {
                    openMenu(player);
                });
            }
        }
    );
});