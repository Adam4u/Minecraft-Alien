import {
    world,
    EquipmentSlot
} from "@minecraft/server";


/* ===== CONFIG ===== */

const PROJECTILES = {

    "ww:bazooka_projectile": {
        explosion: { radius: 2, breaksBlocks: true },
        damage: { radius: 6, amount: 20 },

        particle: [
            "tww:explode_smoke_small"
        ],

        sounds: [
            { min: 0, max: 25, id: "ww:bazooka_explosion_near" },
            { min: 25, max: 45, id: "ww:bazooka_explosion_mid" },
            { min: 45, max: 200, id: "ww:bazooka_explosion_far" }
        ],

        shake: [
            { min: 0, max: 5, intensity: 1.2, duration: 0.5 },
            { min: 5, max: 10, intensity: 0.6, duration: 0.3 },
            { min: 10, max: 15, intensity: 0.2, duration: 0.2 }
        ],

        ring: { id: "ww:shellshock", range: 8 }
    },

    "ww:lungemine_projectile": {
        explosion: { radius: 2, breaksBlocks: true },
        damage: { radius: 10, amount: 20 },

        particle: [
            "tww:explode_smoke"
        ],

        sounds: [
            { min: 0, max: 25, id: "ww:bazooka_explosion_near" },
            { min: 25, max: 45, id: "ww:bazooka_explosion_mid" },
            { min: 45, max: 200, id: "ww:bazooka_explosion_far" }
        ],

        shake: [
            { min: 0, max: 5, intensity: 1.2, duration: 0.5 },
            { min: 5, max: 10, intensity: 0.6, duration: 0.3 },
            { min: 10, max: 15, intensity: 0.2, duration: 0.2 }
        ],

        ring: { id: "ww:shellshock", range: 8 }
    },

    "ww:114mm_projectile": {
        explosion: { radius: 2, breaksBlocks: false },
        damage: { radius: 4, amount: 30 },

        particle: [
            "tww:explode_smoke_small"
        ],

        sounds: [
            { min: 0, max: 25, id: "ww:bazooka_explosion_near" },
            { min: 25, max: 45, id: "ww:bazooka_explosion_mid" },
            { min: 45, max: 200, id: "ww:bazooka_explosion_far" }
        ],

        shake: [
            { min: 0, max: 5, intensity: 1.2, duration: 0.5 },
            { min: 5, max: 10, intensity: 0.6, duration: 0.3 },
            { min: 10, max: 15, intensity: 0.2, duration: 0.2 }
        ],

        ring: { id: "ww:shellshock", range: 8 }
    },    

    "ww:nbazooka_projectile": {
        explosion: { radius: 2, breaksBlocks: true },
        damage: { radius: 6, amount: 20 },

        particle: [
            "tww:explode_smoke_small"
        ],

        sounds: [
            { min: 0, max: 25, id: "ww:bazooka_explosion_near" },
            { min: 25, max: 45, id: "ww:bazooka_explosion_mid" },
            { min: 45, max: 200, id: "ww:bazooka_explosion_far" }
        ],

        shake: [
            { min: 0, max: 5, intensity: 1.2, duration: 0.5 },
            { min: 5, max: 10, intensity: 0.6, duration: 0.3 },
            { min: 10, max: 15, intensity: 0.2, duration: 0.2 }
        ],

        ring: { id: "ww:shellshock", range: 8 }
    },


    "ww:75mm_projectile": {
        explosion: { radius: 2, breaksBlocks: true },
        damage: { radius: 6, amount: 85 },

        particle: [
            "tww:explode_smoke_small"
        ],

        sounds: [
            { min: 0, max: 25, id: "ww:artillery_explosion_near" },
            { min: 25, max: 45, id: "ww:artillery_explosion_mid" },
            { min: 45, max: 200, id: "ww:artillery_explosion_far" }
        ],

        shake: [
            { min: 0, max: 15, intensity: 1, duration: 0.1 },
            { min: 15, max: 28, intensity: 0.4, duration: 0.05 },
            { min: 28, max: 45, intensity: 0.1, duration: 0.02 }
        ],

        ring: { id: "ww:shellshock", range: 10 }
    },

    "ww:50mm_projectile": {
        explosion: { radius: 1, breaksBlocks: true },
        damage: { radius: 4, amount: 62 },

        particle: [
            "tww:explode_smoke_small"
        ],

        sounds: [
            { min: 0, max: 25, id: "ww:bazooka_explosion_near" },
            { min: 25, max: 45, id: "ww:bazooka_explosion_mid" },
            { min: 45, max: 200, id: "ww:bazooka_explosion_far" }
        ],

        shake: [
            { min: 0, max: 15, intensity: 0.8, duration: 0.1 },
            { min: 15, max: 28, intensity: 0.2, duration: 0.05 },
            { min: 28, max: 45, intensity: 0.07, duration: 0.02 }
        ],

        ring: { id: "ww:shellshock", range: 10 }
    },

    "ww:88mm_projectile": {
        explosion: { radius: 2, breaksBlocks: true },
        damage: { radius: 8, amount: 100 },

        particle: [
            "tww:explode_smoke_small",
            "tww:explode_smoke_small"
        ],

        sounds: [
            { min: 0, max: 25, id: "ww:artillery_explosion_near" },
            { min: 25, max: 45, id: "ww:artillery_explosion_mid" },
            { min: 45, max: 200, id: "ww:artillery_explosion_far" }
        ],

        shake: [
            { min: 0, max: 15, intensity: 1.2, duration: 0.1 },
            { min: 15, max: 28, intensity: 0.5, duration: 0.05 },
            { min: 28, max: 45, intensity: 0.2, duration: 0.02 }
        ],

        ring: { id: "ww:shellshock", range: 13 }
    },

    "ww:pzb39_projectile": {
        explosion: { radius: 0.2, breaksBlocks: true },
        damage: { radius: 0.9, amount: 25 },

        particle: [
            "ww:spark_small"
        ],

        sounds: [],
        shake: [],

        ring: {
            id: "ww:shellshock",
            range: 3
        }
    },


    "ww:pzb39s_projectile": {
        explosion: { radius: 0.2, breaksBlocks: true },
        damage: { radius: 0.9, amount: 25 },

        particle: [
            "ww:spark_small"
        ],

        sounds: [],
        shake: [],

        ring: {
            id: "ww:shellshock",
            range: 3
        }
    },


    "ww:artillery_projectile": {
        explosion: { radius: 3, breaksBlocks: true },
        damage: { radius: 8, amount: 50 },

        particle: [
            "tww:explode_smoke"
        ],

        sounds: [
            { min: 0, max: 60, id: "ww:artillery_explosion_near" },
            { min: 60, max: 80, id: "ww:artillery_explosion_mid" },
            { min: 80, max: 200, id: "ww:artillery_explosion_far" }
        ],

        shake: [
            { min: 0, max: 7, intensity: 1.5, duration: 0.5 },
            { min: 7, max: 13, intensity: 0.8, duration: 0.3 },
            { min: 13, max: 35, intensity: 0.2, duration: 0.2 }
        ],

        ring: {
            id: "ww:shellshock",
            range: 14
        }
    },

   "ww:152mm_projectile": {
        explosion: { radius: 3, breaksBlocks: true },
        damage: { radius: 15, amount: 160 },

        particle: [
            "tww:explode_smoke_big",
            "tww:tankshootshock"
        ],

        sounds: [
            { min: 0, max: 60, id: "ww:artillery_explosion_near" },
            { min: 60, max: 80, id: "ww:artillery_explosion_mid" },
            { min: 80, max: 200, id: "ww:artillery_explosion_far" }
        ],

        shake: [
            { min: 0, max: 15, intensity: 1.8, duration: 0.5 },
            { min: 15, max: 28, intensity: 1.2, duration: 0.3 },
            { min: 28, max: 45, intensity: 0.4, duration: 0.2 }
        ],

        ring: {
            id: "ww:shellshock",
            range: 20
        }
    },

    "ww:tankexplode": {
        explosion: { radius: 4, breaksBlocks: false },
        damage: { radius: 15, amount: 50 },

        particle: [
            "id:sparks",
            "tww:explode_smoke",
            "tww:explode_smoke",
            "tww:explode_smoke",
            "tww:tankshootshock"
        ],

        sounds: [
            { min: 0, max: 14, id: "ww:tank_explode_near" },
            { min: 15, max: 80, id: "ww:tank_explode_mid" },
            { min: 81, max: 200, id: "ww:tank_explode_far" }
        ],

        shake: [
            { min: 0, max: 15, intensity: 1.8, duration: 0.5 },
            { min: 15, max: 28, intensity: 1.2, duration: 0.3 },
            { min: 28, max: 45, intensity: 0.4, duration: 0.2 }
        ],

        ring: {
            id: "ww:shellshock",
            range: 20
        }
    },    

    "ww:stukabomb": {
        explosion: { radius: 4, breaksBlocks: true },
        damage: { radius: 15, amount: 120 },

        particle: [
            "tww:explode_smoke_big"
        ],

        sounds: [
            { min: 0, max: 60, id: "ww:artillery_explosion_near" },
            { min: 60, max: 80, id: "ww:artillery_explosion_mid" },
            { min: 80, max: 200, id: "ww:artillery_explosion_far" }
        ],

        shake: [
            { min: 0, max: 15, intensity: 1.8, duration: 0.5 },
            { min: 15, max: 28, intensity: 1.2, duration: 0.3 },
            { min: 28, max: 45, intensity: 0.4, duration: 0.2 }
        ],

        ring: {
            id: "ww:shellshock",
            range: 20
        }
    }
};



/* =========================================================
   HIT BLOCK
   ========================================================= */

world.afterEvents.projectileHitBlock.subscribe((e) => {

    const projectile = e.projectile;
    const location = e.location;
    const dimension = e.dimension;

    const config =
        PROJECTILES[projectile.typeId];

    if (!config) return;

    explode(
        location,
        dimension,
        config
    );
});



/* =========================================================
   HIT ENTITY
   ========================================================= */

world.afterEvents.projectileHitEntity.subscribe((e) => {

    const projectile = e.projectile;
    const location = e.location;
    const dimension = e.dimension;

    const config =
        PROJECTILES[projectile.typeId];

    if (!config) return;


    /* =====================================================
       M2 FLAME - XÁC ĐỊNH HIT SAU LƯNG
       ===================================================== */

    const player = e.hitEntity;

    if (
        player &&
        player.typeId === "minecraft:player"
    ) {

        try {

            /* =============================================
               CHỈ KHI ĐANG CẦM ww:m2flame
               ============================================= */

            const equippable =
                player.getComponent(
                    "minecraft:equippable"
                );

            if (equippable) {

                const mainhand =
                    equippable.getEquipment(
                        EquipmentSlot.Mainhand
                    );

                if (
                    mainhand &&
                    mainhand.typeId === "ww:m2flame"
                ) {

                    const projectileId =
                        projectile.typeId;


                    /* =====================================
                       CHỈ TÍNH ww:*_projectile
                       ===================================== */

                    if (
                        projectileId.indexOf("ww:") === 0 &&
                        projectileId.indexOf("_projectile") !== -1
                    ) {


                        /* =================================
                           ĐIỂM HIT
                           ================================= */

                        const hit =
                            e.location;


                        /*
                         * Vị trí gốc của player.
                         *
                         * e.location là điểm projectile
                         * thực sự chạm entity.
                         */

                        const playerPos =
                            player.location;


                        /* =================================
                           CHỈ TÍNH BODY
                           ================================= */

                        const hitHeight =
                            hit.y -
                            playerPos.y;


                        /*
                         * Minecraft player cao khoảng 1.8 block.
                         *
                         * 0.75 -> 1.65:
                         *     vùng thân/body
                         *
                         * Không tính:
                         *     đầu
                         *     chân
                         */

                        const hitBody =
                            hitHeight >= 0.75 &&
                            hitHeight <= 1.65;


                        if (hitBody) {


                            /* =============================
                               HƯỚNG PLAYER NGAY LÚC HIT
                               ============================= */

                            const rotation =
                                player.getRotation();


                            const yaw =
                                rotation.y *
                                Math.PI /
                                180;


                            const forwardX =
                                -Math.sin(yaw);

                            const forwardZ =
                                Math.cos(yaw);


                            /* =============================
                               VECTOR PLAYER -> ĐIỂM HIT
                               ============================= */

                            const dx =
                                hit.x -
                                playerPos.x;

                            const dz =
                                hit.z -
                                playerPos.z;


                            /* =============================
                               DOT PRODUCT
                               ============================= */

                            const dot =
                                dx *
                                forwardX +
                                dz *
                                forwardZ;


                            /*
                             * dot > 0:
                             *     điểm hit ở phía trước
                             *
                             * dot < 0:
                             *     điểm hit ở phía sau
                             *
                             * Chỉ cần < 0 để test.
                             */

                            const hitFromBehind =
                                dot < 0;


                            if (hitFromBehind) {


                                /* =========================
                                   TEST = 100%
                                   ========================= */

                                const shouldSpawn =
                                    true;


                                if (shouldSpawn) {

                                    dimension.spawnEntity(
                                        "ww:artillery_projectile",
                                        {
                                            x:
                                                playerPos.x,

                                            y:
                                                playerPos.y,

                                            z:
                                                playerPos.z
                                        }
                                    );
                                }
                            }
                        }
                    }
                }
            }

        } catch {}
    }


    /* =====================================================
       EXPLOSION CŨ - GIỮ NGUYÊN
       ===================================================== */

    explode(
        location,
        dimension,
        config
    );
});



/* =========================================================
   CHECK XUYÊN BLOCK
   ========================================================= */

function canPass(block) {

    if (!block) return true;

    const id =
        block.typeId;

    if (
        !id.startsWith("minecraft:")
    ) {
        return false;
    }

    return (
        block.isAir ||
        id.includes("glass") ||
        id.includes("pane") ||
        id.includes("door") ||
        id.includes("fence") ||
        id.includes("slab") ||
        id.includes("grass") ||
        id.includes("flower") ||
        id.includes("sapling") ||
        id.includes("leaves") ||
        id.includes("vine") ||
        id.includes("bamboo") ||
        id.includes("snow") ||
        id.includes("moss") ||
        id.includes("water")
    );
}



/* =========================================================
   EXPLODE
   ========================================================= */

function explode(
    loc,
    dim,
    config
) {

    /* ===== PARTICLE ===== */

    for (
        const p of config.particle
    ) {

        try {

            dim.spawnParticle(
                p,
                loc
            );

        } catch {}
    }


    /* ===== EXPLOSION ===== */

    try {

        dim.createExplosion(
            loc,
            config.explosion.radius,
            {
                breaksBlocks:
                    config.explosion.breaksBlocks
            }
        );

    } catch {}


    /* ===== DAMAGE ===== */

    const entities =
        dim.getEntities({
            location: loc,
            maxDistance:
                config.damage.radius
        });


    for (
        const e of entities
    ) {

        try {

            const t =
                e.location;

            const dx =
                t.x - loc.x;

            const dy =
                t.y - loc.y;

            const dz =
                t.z - loc.z;


            const distVal =
                Math.sqrt(
                    dx * dx +
                    dy * dy +
                    dz * dz
                );


            if (
                distVal >
                config.damage.radius
            ) {
                continue;
            }


            const mid = {

                x:
                    (loc.x + t.x) / 2,

                y:
                    (loc.y + t.y) / 2,

                z:
                    (loc.z + t.z) / 2
            };


            const block =
                dim.getBlock({

                    x:
                        Math.floor(mid.x),

                    y:
                        Math.floor(mid.y),

                    z:
                        Math.floor(mid.z)
                });


            if (
                !canPass(block)
            ) {
                continue;
            }


            if (
                block &&
                (
                    block.typeId.includes("glass") ||
                    block.typeId.includes("pane")
                )
            ) {

                try {

                    dim.runCommand(
                        `setblock ${
                            Math.floor(mid.x)
                        } ${
                            Math.floor(mid.y)
                        } ${
                            Math.floor(mid.z)
                        } air destroy`
                    );

                } catch {}
            }


            const scale =
                1 -
                (
                    distVal /
                    config.damage.radius
                );


            const finalDamage =
                config.damage.amount *
                scale;


            if (
                finalDamage > 0.5
            ) {

                e.applyDamage(
                    finalDamage
                );


                /* =================================================
                   BLOOD
                   Chỉ spawn blood nếu entity KHÔNG có family
                   "tww-tank"
                   ================================================= */

                let isTank = false;

                try {

                    const families =
                        e.getComponent(
                            "minecraft:type_family"
                        );

                    if (families) {

                        isTank =
                            families.hasTypeFamily(
                                "tww-tank"
                            );
                    }

                } catch {}


                if (!isTank) {

                    /* ===== BLOOD PARTICLES ===== */

                    const pLoc = {

                        x:
                            e.location.x,

                        y:
                            e.location.y + 1,

                        z:
                            e.location.z
                    };


                    for (
                        const p of [
                            "ww:blood1",
                            "ww:bloodmist1",
                            "ww:guts",
                            "ww:guts1",
                            "ww:guts2",
                            "ww:guts3"
                        ]
                    ) {

                        try {

                            dim.spawnParticle(
                                p,
                                pLoc
                            );

                        } catch {}
                    }


                    /* ===== BLOOD SOUND ===== */

                    for (
                        const player of
                        dim.getPlayers()
                    ) {

                        try {

                            player.runCommand(
                                `playsound ww:bloody_near @s`
                            );

                        } catch {}
                    }
                }
            }

        } catch {}
    }


    /* =====================================================
       PLAYER EFFECT
       ===================================================== */

    for (
        const p of world.getPlayers()
    ) {

        const d =
            dist(
                p.location,
                loc
            );


        /* ===== SOUNDS ===== */

        for (
            const s of config.sounds
        ) {

            if (
                d >= s.min &&
                d <= s.max
            ) {

                try {

                    p.runCommand(
                        `playsound ${s.id} @s`
                    );

                } catch {}

                break;
            }
        }


        /* ===== RING ===== */

        if (
            d <=
            config.ring.range
        ) {

            try {

                p.runCommand(
                    `playsound ${config.ring.id} @s`
                );

            } catch {}
        }


        /* ===== CAMERA SHAKE ===== */

        for (
            const r of config.shake
        ) {

            if (
                d >= r.min &&
                d <= r.max
            ) {

                try {

                    p.runCommand(
                        `camerashake add @s ${r.intensity} ${r.duration} positional`
                    );

                } catch {}
            }
        }
    }
}



/* =========================================================
   DISTANCE
   ========================================================= */

function dist(
    a,
    b
) {

    const dx =
        a.x - b.x;

    const dy =
        a.y - b.y;

    const dz =
        a.z - b.z;


    return Math.sqrt(
        dx * dx +
        dy * dy +
        dz * dz
    );
}