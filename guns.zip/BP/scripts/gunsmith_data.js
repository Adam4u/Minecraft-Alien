// =====================================================================
//  gunsmith_data.js  —  FILE DUY NHẤT BẠN CẦN SỬA
// =====================================================================
//  GUNS -> slots -> options -> commands
//
//  Placeholder trong commands:
//    {player} {gun} {slot} {option}      (nhớ bọc "{player}" trong ngoặc kép)
//
//  Súng nào không có bộ phận nào thì đừng khai slot đó -> nút không hiện.
//  Slot có options rỗng cũng tự biến mất. Súng không có slot nào cũng không hiện.
// =====================================================================

export const SETTINGS = {
    title: "§l§eGUN BENCH",
    body: "Select a gun to customize:",
    backIcon: "textures/ui/arrow_left",

    // true = chạy lệnh xong quay lại menu lựa chọn, false = đóng GUI
    reopenAfterPick: true,
    blockIds: ["gunsmith:gun_bench"]
};

export const GUNS = [
    {
        id: "m3a1",
        name: "§eM3A1",
        icon: "textures/items/iron_ingot",
        slots: [
            {
                id: "muzzle",
                name: "§aMuzzle",
                icon: "textures/items/stick",
                options: [
                    {
                        id: "muzzle_none",
                        name: "Remove muzzle",
                        commands: [
                            "scoreboard players set @s m3a1muzzle 0",
                            "event entity @s muzzle0",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aMuzzle removed\"}]}"
                        ]
                    },
                    {
                        id: "suppressor",
                        name: "Suppressor",
                        commands: [
                            "scoreboard players set @s m3a1muzzle 1",
                            "event entity @s muzzle1",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aSuppressor attached\"}]}"
                        ]
                    }
                ]
            }
            // M3A1 không có báng rời -> không khai slot "stock" thì nút đó không hiện
        ]
    },

    {
        id: "mp40",
        name: "§eMp40",
        icon: "textures/items/iron_ingot",
        slots: [
            {
                id: "muzzle",
                name: "§aMuzzle",
                icon: "textures/items/stick",
                options: [
                    {
                        id: "muzzle_none",
                        name: "Remove muzzle",
                        commands: [
                            "scoreboard players set @s mp40muzzle 0",
                            "event entity @s muzzle0",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aMuzzle removed\"}]}"
                        ]
                    },
                    {
                        id: "suppressor",
                        name: "Suppressor",
                        commands: [
                            "scoreboard players set @s mp40muzzle 1",
                            "event entity @s muzzle1",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aSuppressor attached\"}]}"
                        ]
                    }
                ]
            },
            {
                id: "stock",
                name: "§aStock",
                icon: "textures/items/gunpowder",
                options: [
                    {
                        id: "stock",
                        name: "Close Stock",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aStock Closed\"}]}",
                            "scoreboard players set @s mp40stock 0",
                        "event entity @s stock0"]
                    },
                    {
                        id: "stock1",
                        name: "Open Stock",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aStock Opened\"}]}",
                            "scoreboard players set @s mp40stock 1",
                            "event entity @s stock1"]
                    }
                ]
            }
            // M3A1 không có báng rời -> không khai slot "stock" thì nút đó không hiện
        ]
    },    

    {
        id: "mp28",
        name: "§eMp28",
        icon: "textures/items/iron_ingot",
        slots: [
            {
                id: "mag",
                name: "§aMagazine",
                icon: "textures/items/gunpowder",
                options: [
                    {
                        id: "mag_20",
                        name: "20-round",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aExtended Magazine Removed\"}]}",
                            "scoreboard players set @s mp28 0",
                            "scoreboard players set @s mp28mag 0",
                        "event entity @s mag0"]
                    },
                    {
                        id: "mag_32",
                        name: "32-round",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aExtended Magazine Attached\"}]}",
                            "scoreboard players set @s mp28 0",
                            "scoreboard players set @s mp28mag 1",
                            "event entity @s mag1"]
                    }
                ]
            }
            // M3A1 không có báng rời -> không khai slot "stock" thì nút đó không hiện
        ]
    },

    {
        id: "c96sch",
        name: "§eM712 C96",
        icon: "textures/items/iron_ingot",
        slots: [
            {
                id: "muzzle",
                name: "§aMuzzle",
                icon: "textures/items/stick",
                options: [
                    {
                        id: "muzzle_none",
                        name: "Normal Barrel",
                        commands: [
                            "scoreboard players set @s c96schmuzzle 0",
                            "event entity @s muzzle0",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aNormal Barrel Attached\"}]}"
                        ]
                    },
                    {
                        id: "long",
                        name: "Long Barrel",
                        commands: [
                            "scoreboard players set @s c96schmuzzle 1",
                            "event entity @s muzzle1",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aLong Barrel Attached\"}]}"
                        ]
                    }
                ]
            },
            {
                id: "mag",
                name: "§aMagazine",
                icon: "textures/items/gunpowder",
                options: [
                    {
                        id: "mag_20",
                        name: "20-round",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aExtended Magazine Removed\"}]}",
                            "scoreboard players set @s c96sch 0",
                            "scoreboard players set @s c96schmag 0",
                        "event entity @s mag0"]
                    },
                    {
                        id: "mag_40",
                        name: "40-round",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aExtended Magazine Attached\"}]}",
                            "scoreboard players set @s c96sch 0",
                            "scoreboard players set @s c96schmag 1",
                            "event entity @s mag1"]
                    }
                ]
            },
            {
                id: "stock",
                name: "§aStock",
                icon: "textures/items/gunpowder",
                options: [
                    {
                        id: "stock",
                        name: "No Stock",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aStock Removed\"}]}",
                            "scoreboard players set @s c96schstock 0",
                        "event entity @s stock0"]
                    },
                    {
                        id: "stock1",
                        name: "Stock",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aStock Attached\"}]}",
                            "scoreboard players set @s c96schstock 1",
                            "event entity @s stock1"]
                    }
                ]
            },
            {
                id: "sight",
                name: "§aSight",
                icon: "textures/items/gunpowder",
                options: [
                    {
                        id: "1x",
                        name: "Iron Sight",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aScope Removed\"}]}",
                            "scoreboard players set @s c96schscope 0",
                        "event entity @s scope0"]
                    },
                    {
                        id: "2x",
                        name: "2x Scope",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aScope Attached\"}]}",
                            "scoreboard players set @s c96schscope 2",
                            "event entity @s scope2"]
                    }
                ]
            }
            // M3A1 không có báng rời -> không khai slot "stock" thì nút đó không hiện
        ]
    },

    {
        id: "m1903",
        name: "§eSpringfield M1903",
        icon: "textures/items/iron_ingot",
        slots: [
            {
                id: "muzzle",
                name: "§aMuzzle",
                icon: "textures/items/stick",
                options: [
                    {
                        id: "muzzle_none",
                        name: "None",
                        commands: [
                            "scoreboard players set @s m1903muzzle 0",
                            "event entity @s muzzle0",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aBayonet Removed\"}]}"
                        ]
                    },
                    {
                        id: "bayonet",
                        name: "Bayonet",
                        commands: [
                            "scoreboard players set @s m1903muzzle 1",
                            "event entity @s muzzle1",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aBayonet Attached\"}]}"
                        ]
                    }
                ]
            },
            {
                id: "sight",
                name: "§aSight",
                icon: "textures/items/gunpowder",
                options: [
                    {
                        id: "1x",
                        name: "Iron Sight",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aScope Removed\"}]}",
                            "scoreboard players set @s m1903scope 0",
                        "event entity @s scope0"]
                    },
                    {
                        id: "4x",
                        name: "4x Scope",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§a4x Scope Attached\"}]}",
                            "scoreboard players set @s m1903scope 4",
                            "event entity @s scope4"]
                    }
                ]
            }
            // M3A1 không có báng rời -> không khai slot "stock" thì nút đó không hiện
        ]
    },

    {
        id: "mosin",
        name: "§eMosin",
        icon: "textures/items/iron_ingot",
        slots: [
            {
                id: "muzzle",
                name: "§aMuzzle",
                icon: "textures/items/stick",
                options: [
                    {
                        id: "muzzle_none",
                        name: "None",
                        commands: [
                            "scoreboard players set @s mosinmuzzle 0",
                            "event entity @s muzzle0",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aBayonet Removed\"}]}"
                        ]
                    },
                    {
                        id: "bayonet",
                        name: "Bayonet",
                        commands: [
                            "scoreboard players set @s mosinmuzzle 1",
                            "event entity @s muzzle1",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aBayonet Attached\"}]}"
                        ]
                    }
                ]
            },
            {
                id: "sight",
                name: "§aSight",
                icon: "textures/items/gunpowder",
                options: [
                    {
                        id: "1x",
                        name: "Iron Sight",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aScope Removed\"}]}",
                            "scoreboard players set @s mosinscope 0",
                        "event entity @s scope0"]
                    },
                    {
                        id: "4x",
                        name: "4x Scope",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§a4x Scope Attached\"}]}",
                            "scoreboard players set @s mosinscope 4",
                            "event entity @s scope4"]
                    }
                ]
            }
            // M3A1 không có báng rời -> không khai slot "stock" thì nút đó không hiện
        ]
    },

    {
        id: "type99",
        name: "§eType99 Rifle",
        icon: "textures/items/iron_ingot",
        slots: [
            {
                id: "muzzle",
                name: "§aMuzzle",
                icon: "textures/items/stick",
                options: [
                    {
                        id: "muzzle_none",
                        name: "None",
                        commands: [
                            "scoreboard players set @s type99muzzle 0",
                            "event entity @s muzzle0",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aBayonet Removed\"}]}"
                        ]
                    },
                    {
                        id: "bayonet",
                        name: "Bayonet",
                        commands: [
                            "scoreboard players set @s type99muzzle 1",
                            "event entity @s muzzle1",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aBayonet Attached\"}]}"
                        ]
                    }
                ]
            },
            {
                id: "bipod",
                name: "§aBipod",
                icon: "textures/items/gunpowder",
                options: [
                    {
                        id: "none",
                        name: "None",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aAttachment Removed\"}]}",
                            "scoreboard players set @s type99bipod 0",
                        "event entity @s bipod0"]
                    },
                    {
                        id: "bipod",
                        name: "Bipod",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aBipod Attached\"}]}",
                            "scoreboard players set @s type99bipod 1",
                        "event entity @s bipod1"]
                    },
                    {
                        id: "flag",
                        name: "Flag",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aFlag Attached\"}]}",
                            "scoreboard players set @s type99bipod 2",
                            "event entity @s bipod2"]
                    }
                ]
            },
            {
                id: "sight",
                name: "§aSight",
                icon: "textures/items/gunpowder",
                options: [
                    {
                        id: "1x",
                        name: "Iron Sight",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aScope Removed\"}]}",
                            "scoreboard players set @s type99scope 0",
                        "event entity @s scope0"]
                    },
                    {
                        id: "2x",
                        name: "2x Scope",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§a2x Scope Attached\"}]}",
                            "scoreboard players set @s type99scope 2",
                            "event entity @s scope2"]
                    },
                    {
                        id: "3x",
                        name: "3x Scope",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§a3x Scope Attached\"}]}",
                            "scoreboard players set @s type99scope 3",
                            "event entity @s scope3"]
                    },
                    {
                        id: "4x",
                        name: "4x Scope",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§a4x Scope Attached\"}]}",
                            "scoreboard players set @s type99scope 4",
                            "event entity @s scope4"]
                    }
                ]
            }
            // M3A1 không có báng rời -> không khai slot "stock" thì nút đó không hiện
        ]
    },

    {
        id: "kar98",
        name: "§eKar-98",
        icon: "textures/items/iron_ingot",
        slots: [
            {
                id: "muzzle",
                name: "§aMuzzle",
                icon: "textures/items/stick",
                options: [
                    {
                        id: "muzzle_none",
                        name: "None",
                        commands: [
                            "scoreboard players set @s kar98muzzle 0",
                            "event entity @s muzzle0",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aBayonet Removed\"}]}"
                        ]
                    },
                    {
                        id: "bayonet",
                        name: "Bayonet",
                        commands: [
                            "scoreboard players set @s kar98muzzle 1",
                            "event entity @s muzzle1",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aBayonet Attached\"}]}"
                        ]
                    },
                    {
                        id: "silencer",
                        name: "Silencer",
                        commands: [
                            "scoreboard players set @s kar98muzzle 2",
                            "event entity @s muzzle2",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aSilencer Attached\"}]}"
                        ]
                    }
                ]
            },
            {
                id: "sight",
                name: "§aSight",
                icon: "textures/items/gunpowder",
                options: [
                    {
                        id: "1x",
                        name: "Iron Sight",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aScope Removed\"}]}",
                            "scoreboard players set @s kar98scope 0",
                        "event entity @s scope0"]
                    },
                    {
                        id: "3x",
                        name: "3x Scope",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§a3x Scope Attached\"}]}",
                            "scoreboard players set @s kar98scope 3",
                            "event entity @s scope3"]
                    },
                    {
                        id: "4x",
                        name: "4x Scope",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§a4x Scope Attached\"}]}",
                            "scoreboard players set @s kar98scope 4",
                            "event entity @s scope4"]
                    }
                ]
            }
            // M3A1 không có báng rời -> không khai slot "stock" thì nút đó không hiện
        ]
    },


    {
        id: "type96",
        name: "§eType96 Lmg",
        icon: "textures/items/iron_ingot",
        slots: [
            {
                id: "muzzle",
                name: "§aMuzzle",
                icon: "textures/items/stick",
                options: [
                    {
                        id: "muzzle_none",
                        name: "None",
                        commands: [
                            "scoreboard players set @s type96muzzle 0",
                            "event entity @s muzzle0",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aBayonet Removed\"}]}"
                        ]
                    },
                    {
                        id: "bayonet",
                        name: "Bayonet",
                        commands: [
                            "scoreboard players set @s type96muzzle 1",
                            "event entity @s muzzle1",
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aBayonet Attached\"}]}"
                        ]
                    }
                ]
            },
            {
                id: "bipod",
                name: "§aBipod",
                icon: "textures/items/gunpowder",
                options: [
                    {
                        id: "none",
                        name: "None",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aAttachment Removed\"}]}",
                            "scoreboard players set @s type96bipod 0",
                        "event entity @s bipod0"]
                    },
                    {
                        id: "bipod",
                        name: "Bipod",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aBipod Attached\"}]}",
                            "scoreboard players set @s type96bipod 1",
                        "event entity @s bipod1"]
                    }
                ]
            },
            {
                id: "sight",
                name: "§aSight",
                icon: "textures/items/gunpowder",
                options: [
                    {
                        id: "1x",
                        name: "Iron Sight",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§aScope Removed\"}]}",
                            "scoreboard players set @s type96scope 0",
                        "event entity @s scope0"]
                    },
                    {
                        id: "3x",
                        name: "3x Scope",
                        commands: [
                            "tellraw \"{player}\" {\"rawtext\":[{\"text\":\"§a3x Scope Attached\"}]}",
                            "scoreboard players set @s type96scope 3",
                            "event entity @s scope3"]
                    }
                ]
            }
            // M3A1 không có báng rời -> không khai slot "stock" thì nút đó không hiện
        ]
    },
];