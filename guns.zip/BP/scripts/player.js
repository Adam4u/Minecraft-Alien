import { world } from "@minecraft/server";
import { getGunKill } from "./projectile/onHit.js";

// ============================================================
// SOUND
// ============================================================

const respawnSound = "player.respawn";
const playerKilledSound = "player.killer";

// ============================================================
// 1. PLAYER RESPAWN
// ============================================================
//
// Khi một player respawn:
// - Người vừa respawn KHÔNG nghe.
// - Những player khác trong bán kính 20 block nghe.
// - Không gửi thông báo chat.
// ============================================================

world.afterEvents.playerSpawn.subscribe((event) => {
    const player = event.player;

    if (!player || player.typeId !== "minecraft:player") {
        return;
    }

    try {
        player.runCommand(
            `playsound ${respawnSound} @a[r=20,name=!${player.name}]`
        );
    } catch {}
});

// ============================================================
// 2. PLAYER KILLS PLAYER
// ============================================================
//
// Khi một player giết một player khác:
// - Người giết nghe player.killer.
// - Không kích hoạt khi giết mob.
//
// Thêm:
// - Nếu player bị giết bởi đạn ww:
//   người bắn đạn sẽ nghe player.killer.
// ============================================================

world.afterEvents.entityDie.subscribe((event) => {
    const deadEntity = event.deadEntity;
    const damagingEntity = event.damageSource?.damagingEntity;

    if (!deadEntity || deadEntity.typeId !== "minecraft:player") {
        return;
    }

    // ========================================================
    // KILL BẰNG ĐẠN ww:
    // ========================================================

    const gunKiller = getGunKill(deadEntity.id);

    if (gunKiller) {
        try {
            if (
                gunKiller.isValid &&
                gunKiller.typeId === "minecraft:player"
            ) {
                gunKiller.runCommand(
                    `playsound ${playerKilledSound} @s`
                );
            }
        } catch {}

        return;
    }

    // ========================================================
    // PLAYER GIẾT PLAYER TRỰC TIẾP
    // ========================================================

    if (
        !damagingEntity ||
        damagingEntity.typeId !== "minecraft:player"
    ) {
        return;
    }

    try {
        damagingEntity.runCommand(
            `playsound ${playerKilledSound} @s`
        );
    } catch {}
});