import {
    world,
    system,
    EquipmentSlot
} from "@minecraft/server";

const DEAD_BODY_ID = "ww:player_d";

console.warn("[DeadBody][DEBUG] playerd.js đã được load bởi engine.");

world.afterEvents.entityDie.subscribe((event) => {
    const player = event.deadEntity;

    console.warn(
        `[DeadBody][DEBUG] entityDie fired cho: ${player?.typeId}`
    );

    if (!player || player.typeId !== "minecraft:player") {
        return;
    }

    // ========================================================
    // TÀNG HÌNH PLAYER SAU KHI CHẾT
    // ========================================================

    try {
        player.addEffect("invisibility", 10, {
            amplifier: 0,
            showParticles: false
        });
    } catch (error) {
        console.warn(
            `[DeadBody][DEBUG] Invisibility error: ${error}`
        );
    }

    // ========================================================
    // ĐỌC GIÁP NGAY KHI PLAYER CHẾT
    // ========================================================

    const equipment = player.getComponent("minecraft:equippable");

    if (!equipment) {
        console.warn(
            "[DeadBody][DEBUG] Không lấy được equipment của player."
        );
        return;
    }

    let head;
    let chest;
    let legs;
    let feet;

    try {
        head = equipment.getEquipment(EquipmentSlot.Head);
    } catch {}

    try {
        chest = equipment.getEquipment(EquipmentSlot.Chest);
    } catch {}

    try {
        legs = equipment.getEquipment(EquipmentSlot.Legs);
    } catch {}

    try {
        feet = equipment.getEquipment(EquipmentSlot.Feet);
    } catch {}

    const headId = head?.typeId;
    const chestId = chest?.typeId;
    const legsId = legs?.typeId;
    const feetId = feet?.typeId;

    console.warn(
        `[DeadBody][DEBUG] Giáp lúc chết -> ` +
        `head:${headId ?? "none"} ` +
        `chest:${chestId ?? "none"} ` +
        `legs:${legsId ?? "none"} ` +
        `feet:${feetId ?? "none"}`
    );

    // ========================================================
    // VỊ TRÍ + ROTATION
    // ========================================================

    const location = {
        x: player.location.x,
        y: player.location.y,
        z: player.location.z
    };

    const rotation = player.getRotation();

    // ========================================================
    // SPAWN XÁC
    // ========================================================

    let body;

    try {
        body = player.dimension.spawnEntity(
            DEAD_BODY_ID,
            location
        );
    } catch (error) {
        console.warn(
            `[DeadBody][DEBUG] Spawn error: ${error}`
        );
        return;
    }

    console.warn(
        `[DeadBody][DEBUG] Đã spawn ${body.typeId} tại ` +
        `${location.x.toFixed(1)}, ` +
        `${location.y.toFixed(1)}, ` +
        `${location.z.toFixed(1)}`
    );

    // ========================================================
    // COPY ROTATION
    // ========================================================

    try {
        body.setRotation({
            x: 0,
            y: rotation.y
        });
    } catch (error) {
        console.warn(
            `[DeadBody][DEBUG] Rotation error: ${error}`
        );
    }

    // ========================================================
    // CHỜ 1 TICK RỒI DÙNG COMMAND MẶC GIÁP
    // ========================================================

    system.run(() => {

        if (!body || !body.isValid) {
            return;
        }

        // ----------------------------------------------------
        // HEAD
        // ----------------------------------------------------

        if (headId) {
            try {
                body.runCommand(
                    `replaceitem entity @s slot.armor.head 0 ${headId} 1`
                );

                console.warn(
                    `[DeadBody][DEBUG] HEAD -> ${headId}`
                );
            } catch (error) {
                console.warn(
                    `[DeadBody][DEBUG] HEAD ERROR: ${error}`
                );
            }
        }

        // ----------------------------------------------------
        // CHEST
        // ----------------------------------------------------

        if (chestId) {
            try {
                body.runCommand(
                    `replaceitem entity @s slot.armor.chest 0 ${chestId} 1`
                );

                console.warn(
                    `[DeadBody][DEBUG] CHEST -> ${chestId}`
                );
            } catch (error) {
                console.warn(
                    `[DeadBody][DEBUG] CHEST ERROR: ${error}`
                );
            }
        }

        // ----------------------------------------------------
        // LEGS
        // ----------------------------------------------------

        if (legsId) {
            try {
                body.runCommand(
                    `replaceitem entity @s slot.armor.legs 0 ${legsId} 1`
                );

                console.warn(
                    `[DeadBody][DEBUG] LEGS -> ${legsId}`
                );
            } catch (error) {
                console.warn(
                    `[DeadBody][DEBUG] LEGS ERROR: ${error}`
                );
            }
        }

        // ----------------------------------------------------
        // FEET
        // ----------------------------------------------------

        if (feetId) {
            try {
                body.runCommand(
                    `replaceitem entity @s slot.armor.feet 0 ${feetId} 1`
                );

                console.warn(
                    `[DeadBody][DEBUG] FEET -> ${feetId}`
                );
            } catch (error) {
                console.warn(
                    `[DeadBody][DEBUG] FEET ERROR: ${error}`
                );
            }
        }

        console.warn(
            "[DeadBody][DEBUG] Đã hoàn tất command mặc giáp."
        );
    });
});