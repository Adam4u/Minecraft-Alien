import { world, system } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";


// ============================================================
// STATE
// ============================================================

const cooldowns = new Map();
const activeStrikes = [];


// ============================================================
// ALERT LOOP STATE
// ============================================================

let alertLoopTimer = null;


// ============================================================
// CONFIG
// ============================================================

const MAX_DIST = 150;
const COOLDOWN = 500;


// ============================================================
// DELAY PHÁO THEO Y
// ============================================================

const BASE_STRIKE_DELAY = 250;

const HIGH_Y_THRESHOLD = 100;

const EXTRA_DELAY_PER_BLOCK = 2;

const MAX_STRIKE_DELAY = 650;


// ============================================================
// CALCULATE STRIKE DELAY
// ============================================================

function calculateStrikeDelay(y) {

    let delay = BASE_STRIKE_DELAY;

    if (y > HIGH_Y_THRESHOLD) {

        delay +=
            (y - HIGH_Y_THRESHOLD) *
            EXTRA_DELAY_PER_BLOCK;
    }

    return Math.min(
        delay,
        MAX_STRIKE_DELAY
    );
}


// ============================================================
// RADIO / ALERT
// ============================================================

const REPLY_DELAY = 100;
const ALERT_DELAY = 220;
const STRIKE_DURATION = 450;
const ALERT_RADIUS = 50;


// ============================================================
// ARTILLERY
// ============================================================

const ROCKET_COUNT = 20;

const ROCKET_INTERVAL = 15;

const PROJECTILE_ID =
    "ww:artillery_projectile";


// ============================================================
// START ALERT LOOP
// ============================================================

function startAlertLoop() {

    if (
        alertLoopTimer !== null
    ) {
        return;
    }


    alertLoopTimer =
        system.runInterval(() => {

            // Không có artillery nào thì dừng loop hoàn toàn.
            if (
                activeStrikes.length === 0
            ) {

                system.clearRun(
                    alertLoopTimer
                );

                alertLoopTimer =
                    null;

                return;
            }


            const now =
                system.currentTick;


            // ========================================================
            // DUYỆT CÁC LOẠT PHÁO ĐANG ACTIVE
            // ========================================================

            for (
                let i =
                    activeStrikes.length - 1;

                i >= 0;

                i--
            ) {

                const strike =
                    activeStrikes[i];


                const age =
                    now -
                    strike.start;


                // ====================================================
                // STRIKE HẾT HẠN
                // ====================================================

                if (
                    age >=
                    STRIKE_DURATION
                ) {

                    activeStrikes.splice(
                        i,
                        1
                    );

                    continue;
                }


                // ====================================================
                // CHƯA ĐẾN ALERT
                // ====================================================

                if (
                    age <
                    ALERT_DELAY
                ) {

                    continue;
                }


                const radiusSq =
                    ALERT_RADIUS *
                    ALERT_RADIUS;


                // ====================================================
                // CHECK PLAYER
                // ====================================================

                for (
                    const p of
                    world.getPlayers()
                ) {

                    if (
                        strike
                            .alertedPlayers
                            .has(
                                p.id
                            )
                    ) {

                        continue;
                    }


                    const dx =
                        p.location.x -
                        strike.x;


                    const dz =
                        p.location.z -
                        strike.z;


                    const distanceSq =
                        dx * dx +
                        dz * dz;


                    if (
                        distanceSq <=
                        radiusSq
                    ) {

                        try {

                            p.runCommandAsync(
                                "function artilleryalert"
                            );

                        } catch {}


                        strike
                            .alertedPlayers
                            .add(
                                p.id
                            );
                    }
                }
            }


            // Nếu strike vừa bị xóa hết thì dừng interval.
            if (
                activeStrikes.length === 0
            ) {

                system.clearRun(
                    alertLoopTimer
                );

                alertLoopTimer =
                    null;
            }

        }, 5);
}


// ============================================================
// USE ARTILLERY RADIO
// ============================================================

world.afterEvents.itemUse.subscribe((ev) => {

    const player =
        ev.source;


    if (
        ev.itemStack.typeId !==
        "ww:art_radio"
    ) {
        return;
    }


    // ========================================================
    // COOLDOWN
    // ========================================================

    if (
        (
            cooldowns.get(
                player.id
            ) ?? 0
        ) >
        system.currentTick
    ) {

        player.sendMessage(
            "§cnot available!"
        );

        return;
    }


    system.run(() => {

        const form =
            new ModalFormData()
                .title(
                    "Artillery Strike"
                )
                .textField(
                    "front (block)",
                    "20"
                )
                .textField(
                    "right (block)",
                    "10"
                );


        form.show(player).then(res => {

            if (res.canceled) {
                return;
            }


            const forward =
                Number(
                    res.formValues[0]
                );

            const right =
                Number(
                    res.formValues[1]
                );


            if (
                !Number.isFinite(
                    forward
                ) ||
                !Number.isFinite(
                    right
                )
            ) {

                player.sendMessage(
                    "§cEnter a valid number!"
                );

                return;
            }


            if (
                Math.abs(forward) >
                MAX_DIST ||

                Math.abs(right) >
                MAX_DIST
            ) {

                player.sendMessage(
                    "§cExceeded 150 blocks!"
                );

                return;
            }


            // =================================================
            // VIEW DIRECTION
            // =================================================

            const dir =
                player.getViewDirection();


            const f = {
                x: dir.x,
                z: dir.z
            };


            const len =
                Math.hypot(
                    f.x,
                    f.z
                );


            if (len < 0.001) {
                return;
            }


            f.x /= len;
            f.z /= len;


            const r = {
                x: -f.z,
                z: f.x
            };


            // =================================================
            // TARGET
            // =================================================

            const target = {

                x:
                    player.location.x +
                    f.x * forward +
                    r.x * right,

                y:
                    player.location.y,

                z:
                    player.location.z +
                    f.z * forward +
                    r.z * right
            };


            const dim =
                player.dimension;


            // =================================================
            // DELAY THEO Y
            // =================================================

            const strikeDelay =
                calculateStrikeDelay(
                    player.location.y
                );


            // =================================================
            // COOLDOWN
            // =================================================

            cooldowns.set(
                player.id,
                system.currentTick +
                COOLDOWN
            );


            player.sendMessage(
                "§aArtillery called!"
            );


            // =================================================
            // REQUEST
            // =================================================

            try {

                player.runCommandAsync(
                    "function artilleryrequest"
                );

            } catch {}


            // =================================================
            // REPLY
            // =================================================

            system.runTimeout(() => {

                try {

                    player.runCommandAsync(
                        "function artilleryreply"
                    );

                } catch {}


                // =================================================
                // ART START SOUND
                // =================================================

                system.runTimeout(() => {

                    let soundIndex = 0;

                    function playNextArtStart() {

                        if (
                            soundIndex >=
                            ROCKET_COUNT
                        ) {
                            return;
                        }

                        try {

                            dim.runCommandAsync(
                                `playsound ww:art_start @a`
                            );

                        } catch {}


                        soundIndex++;


                        if (
                            soundIndex <
                            ROCKET_COUNT
                        ) {

                            const nextDelay =
                                Math.floor(
                                    Math.random() * 11
                                ) + 5;

                            system.runTimeout(
                                playNextArtStart,
                                nextDelay
                            );
                        }
                    }


                    playNextArtStart();

                }, 120);

            }, REPLY_DELAY);


            // =================================================
            // ACTIVE STRIKE
            // =================================================

            const strike = {

                x:
                    target.x,

                z:
                    target.z,

                start:
                    system.currentTick,

                alertedPlayers:
                    new Set()
            };


            activeStrikes.push(
                strike
            );


            // Chỉ bắt đầu ALERT LOOP khi có artillery.
            startAlertLoop();


            // ============================================================
            // INCOMING WHISTLE
            // ============================================================

            system.runTimeout(() => {

                let incomingIndex = 0;

                const incomingTimer =
                    system.runInterval(() => {

                        if (
                            incomingIndex >= ROCKET_COUNT
                        ) {

                            system.clearRun(
                                incomingTimer
                            );

                            return;
                        }

                        try {

                            const soundX =
                                target.x;

                            const soundY =
                                target.y + 270;

                            const soundZ =
                                target.z;


                            for (
                                const soundPlayer of
                                dim.getPlayers()
                            ) {

                                const dx =
                                    soundPlayer.location.x -
                                    soundX;

                                const dz =
                                    soundPlayer.location.z -
                                    soundZ;


                                if (
                                    dx * dx +
                                    dz * dz <=
                                    70 * 70
                                ) {

                                    soundPlayer.runCommandAsync(
                                        `playsound ww:artillery_incoming @s ${soundX} ${soundY} ${soundZ} 1 1 1`
                                    );
                                }
                            }

                        } catch {}

                        incomingIndex++;

                    }, 15);

            }, strikeDelay + 345);


            // ============================================================
            // INCOMING WHISTLE
            // ============================================================

            system.runTimeout(() => {

                let incomingIndex = 0;


                const incomingTimer =
                    system.runInterval(() => {

                        if (
                            incomingIndex >=
                            ROCKET_COUNT
                        ) {

                            system.clearRun(
                                incomingTimer
                            );

                            return;
                        }


                        try {

                            const soundX =
                                target.x;

                            const soundY =
                                target.y + 270;

                            const soundZ =
                                target.z;


                            for (
                                const soundPlayer of
                                dim.getPlayers()
                            ) {

                                const dx =
                                    soundPlayer.location.x -
                                    soundX;

                                const dz =
                                    soundPlayer.location.z -
                                    soundZ;


                                if (
                                    dx * dx +
                                    dz * dz <=
                                    70 * 70
                                ) {

                                    soundPlayer.runCommandAsync(
                                        `playsound ww:artillery_incoming @s ${soundX} ${soundY} ${soundZ} 0.98 1`
                                    );
                                }
                            }

                        } catch {}


                        incomingIndex++;

                    }, ROCKET_INTERVAL);

            }, strikeDelay + 360);


            // =================================================
            // ARTILLERY PROJECTILE START
            // =================================================

            system.runTimeout(() => {

                let rocketIndex = 0;


                const rocketTimer =
                    system.runInterval(() => {

                        if (
                            rocketIndex >=
                            ROCKET_COUNT
                        ) {

                            system.clearRun(
                                rocketTimer
                            );

                            return;
                        }


                        const spawnLocation = {

                            x:
                                target.x +
                                (
                                    Math.random() *
                                    45 -
                                    25
                                ),

                            y:
                                target.y +
                                270,

                            z:
                                target.z +
                                (
                                    Math.random() *
                                    45 -
                                    25
                                )
                        };


                        let entity =
                            null;


                        try {

                            entity =
                                dim.spawnEntity(
                                    PROJECTILE_ID,
                                    spawnLocation
                                );

                        } catch {}


                        if (!entity) {

                            try {

                                dim.runCommandAsync(
                                    `summon ${PROJECTILE_ID} ${spawnLocation.x} ${spawnLocation.y} ${spawnLocation.z}`
                                );

                            } catch {}
                        }


                        rocketIndex++;

                    }, ROCKET_INTERVAL);


            }, strikeDelay + 400);

        });

    });

});


// ============================================================
// CLEANUP COOLDOWNS
// ============================================================

system.runInterval(() => {

    const now =
        system.currentTick;


    for (
        const [
            id,
            expiry
        ]
        of cooldowns
    ) {

        if (
            expiry <= now
        ) {

            cooldowns.delete(
                id
            );
        }
    }


    const onlineIds =
        new Set(
            world.getPlayers().map(
                p => p.id
            )
        );


    for (
        const id of
        cooldowns.keys()
    ) {

        if (
            !onlineIds.has(id)
        ) {

            cooldowns.delete(
                id
            );
        }
    }

}, 100);