import { world, system, EquipmentSlot } from "@minecraft/server";

// ================= Cấu hình =================
const BASE_FOV = 70; // FOV làm mốc để tính độ zoom (zoom Nx = thu hẹp góc nhìn N lần)

// tww:scope -> độ zoom. s0 = không gắn scope nên zoom nhẹ 1.5x.
// CHỈ S0, S1, S2 dùng FOV
const SCOPE_MULT = { s0: 1.25, s1: 4, s2: 3 };

// Thời gian và kiểu làm mượt, giống cảm giác kính viễn vọng (spyglass):
// vào nhanh rồi chậm dần (out_quad). Chỉnh số giây nếu thấy chưa giống.
const ZOOM_IN = "0.2 out_quad";
const ZOOM_OUT = "0.15 out_quad";

const SCAN_INTERVAL = 2; // quét mỗi 2 tick (0.1s)
const REZOOM_DELAY = 6; // sau khi đổi súng: chưa zoom vào lại trong 6 tick (0.3s)
const POST_SWITCH_SCAN = 14; // sau khi đổi súng: quét thêm ít nhất 14 tick (0.7s)

// tww:scope -> mức slowness (amplifier). 0 = Slowness I, 1 = Slowness II...
// scope không có trong danh sách này (s0, s1, s2) thì không bị chậm.
const SLOWNESS_LEVELS = { s3: 8, s4: 20, s5: 30 };

// Bedrock không có duration "vô hạn" thật, giới hạn cứng của /effect là 1.000.000 giây
// (~11,5 ngày) rồi tự bị coi là hết hạn -> dùng luôn mức này cho gần như vô hạn.
// Nếu bản game bạn chắc chắn từ 1.21.40 trở lên, đổi thành "infinite" (đúng cú pháp mới).
const SLOWNESS_SECONDS = 1000000;

// Chỉ những súng trong danh sách này mới chạy phần zoom (ID đầy đủ là "ww:" + tên).
const GUN_NAMES = [
  "m1919", "m1911", "bren", "fm24", "mab38", "pzb39", "panzershreck", "bazooka", "m1903s",
  "sten", "m1903", "enfieldmk1s", "mp40", "bar", "m2flame", "c96sch",
  "mp28", "ppd40", "fg42", "p08", "hipower", "ppsh41d", "ppsh41b", "dp28",
  "lewis", "enfieldmk1", "pps43", "model1912", "nagant", "p38", "tt33", "mas35",
  "stg44", "mk6", "mosin", "type99", "kar98", "kar98s", "mas36", "mod30",
  "mg42", "mg34b", "mg42b", "g43", "svt38",
  "garand", "type11", "type2a", "type100", "stinger", "m3a1",
  "thompson", "m1928a1", "type96",
];

const GUNS = new Set(GUN_NAMES.map((name) => `ww:${name}`));

// Chỉ bolt và overheated làm tắt zoom
const BLOCK_PROPS = [
  "state:bolt",
  "state:overheated",
  "state:overheated2",
  "state:overheated3",
  "state:overheated4",
  "state:overheated5",
  "state:overheated6",
  "state:overheated7",
  "state:overheated8",
];

// ================= Tính FOV =================
function fovFor(mult) {
  const rad = (BASE_FOV / 2) * (Math.PI / 180);
  const fov = 2 * Math.atan(Math.tan(rad) / mult) * (180 / Math.PI);
  return Number(fov.toFixed(1));
}

const SCOPE_FOV = Object.fromEntries(
  Object.entries(SCOPE_MULT).map(([key, mult]) => [key, fovFor(mult)])
);

// ================= Trạng thái =================
const zoomed = new Map(); // player.id -> FOV đang áp dụng
const slowed = new Map(); // player.id -> mức slowness đang áp dụng (amplifier)
const active = new Map(); // player.id -> tick tối thiểu phải quét tới (0 = quét khi còn sneak/zoom)
const seen = new Map(); // player.id -> item ở lần quét trước (để phát hiện đổi súng)
const holdUntil = new Map(); // player.id -> tick, chưa được zoom vào trước mốc này
let loop; // id của vòng quét, chỉ tồn tại khi có người cần quét

// ================= Logic =================
function heldId(p) {
  return (
    p
      .getComponent("minecraft:equippable")
      ?.getEquipment(EquipmentSlot.Mainhand)?.typeId ?? null
  );
}

// Trả về FOV cần đặt, hoặc undefined nếu không được zoom.
// Kiểm tra từ rẻ đến đắt để thoát sớm.
function targetFov(p, item) {
  if (!p.isSneaking) return undefined;
  if (!GUNS.has(item)) return undefined;

  const scope = p.getProperty("tww:scope");

  // S3 -> S5 không dùng FOV
  if (scope === "s3" || scope === "s4" || scope === "s5") {
    return undefined;
  }

  const fov = SCOPE_FOV[scope];
  if (fov === undefined) return undefined;
  if (BLOCK_PROPS.some((k) => p.getProperty(k) === true)) return undefined;
  return fov;
}

function clearZoom(p) {
  p.runCommand(`camera @s fov_clear ${ZOOM_OUT}`);
  zoomed.delete(p.id);
  clearSlow(p); // không zoom hoặc ra khỏi scope thì clear slowness giống clear zoom
}

function applySlow(p, level) {
  if (slowed.get(p.id) === level) return; // đã đúng mức rồi, không gửi lệnh thừa

  // Bedrock: hiệu ứng mức thấp hơn không tự đè được hiệu ứng mức cao hơn đang có,
  // nên phải clear trước khi đổi sang mức khác (kể cả tăng lẫn giảm) cho chắc.
  if (slowed.has(p.id)) p.runCommand(`effect @s clear slowness`);

  p.runCommand(`effect @s slowness infinite ${level} true`);
  slowed.set(p.id, level);
}

function clearSlow(p) {
  if (!slowed.has(p.id)) return;
  p.runCommand(`effect @s clear slowness`);
  slowed.delete(p.id);
}

// Đăng ký người chơi vào danh sách quét (và bật vòng quét nếu chưa chạy).
function keepScanning(p, until = 0) {
  if (!active.has(p.id)) seen.set(p.id, heldId(p));
  active.set(p.id, Math.max(active.get(p.id) ?? 0, until));
  if (loop === undefined) loop = system.runInterval(scan, SCAN_INTERVAL);
}

function refresh(p) {
  try {
    const id = p.id;
    if (!p.isSneaking && !zoomed.has(id) && !active.has(id)) return; // không liên quan

    const now = system.currentTick;
    keepScanning(p);

    // Đổi súng: zoom out, chờ property tww:scope cập nhật rồi mới xét lại.
    // Vòng quét vẫn chạy nên khi scope đổi giá trị thì độ zoom đổi theo.
    const item = heldId(p);
    if (seen.get(id) !== item) {
      seen.set(id, item);
      holdUntil.set(id, now + REZOOM_DELAY);
      keepScanning(p, now + POST_SWITCH_SCAN);
      if (zoomed.has(id)) clearZoom(p);
    }

    const scope = p.getProperty("tww:scope");

    // =========================================================
    // S3 -> S5:
    // KHÔNG dùng FOV.
    // Chỉ dùng Slowness như cấu hình cũ.
    // =========================================================
    if (scope === "s3" || scope === "s4" || scope === "s5") {
      // Nếu trước đó đang FOV zoom (ví dụ chuyển từ S2 -> S3)
      // thì xóa FOV trước.
      if (zoomed.has(id)) {
        p.runCommand(`camera @s fov_clear ${ZOOM_OUT}`);
        zoomed.delete(id);
      }

      const slowLevel = SLOWNESS_LEVELS[scope];

      if (
        p.isSneaking &&
        GUNS.has(item) &&
        !BLOCK_PROPS.some((k) => p.getProperty(k) === true)
      ) {
        if (slowLevel !== undefined) {
          applySlow(p, slowLevel);
        }
      } else {
        clearSlow(p);
      }

      return;
    }

    // =========================================================
    // S0 -> S2:
    // Giữ nguyên zoom bằng FOV cũ.
    // =========================================================

    const cur = zoomed.get(id);
    const want = targetFov(p, item);

    if (want === cur) return;

    if (want === undefined) {
      clearZoom(p);
      return;
    }

    if (now < (holdUntil.get(id) ?? 0)) return; // đang chờ sau khi đổi súng

    p.runCommand(`camera @s fov_set ${want} ${ZOOM_IN}`);
    zoomed.set(id, want);

    // scope có trong SLOWNESS_LEVELS thì kèm slowness đúng mức của scope đó;
    // scope không có trong danh sách (vẫn đang zoom) thì clear
    const slowLevel = SLOWNESS_LEVELS[p.getProperty("tww:scope")];

    if (slowLevel !== undefined) applySlow(p, slowLevel);
    else clearSlow(p);

  } catch {
    // người chơi vừa thoát hoặc chưa load xong
  }
}

function drop(id) {
  active.delete(id);
  seen.delete(id);
  holdUntil.delete(id);
}

function forget(id) {
  drop(id);
  zoomed.delete(id);
  slowed.delete(id); // người chơi đã thoát, không cần gửi lệnh clear nữa
}

// Vòng quét: chạy khi có người đang sneak, đang zoom, hoặc vừa đổi súng chưa quá 0.7s.
function scan() {
  const now = system.currentTick;
  const present = new Set();

  for (const p of world.getAllPlayers()) {
    const id = p.id;
    if (!active.has(id)) continue;

    present.add(id);
    refresh(p);

    if (!p.isSneaking && !zoomed.has(id) && now >= (active.get(id) ?? 0)) {
      drop(id); // hết việc
    }
  }

  for (const id of [...active.keys()]) {
    if (!present.has(id)) forget(id); // người chơi đã thoát
  }

  if (active.size === 0 && loop !== undefined) {
    system.clearRun(loop);
    loop = undefined;
  }
}

// ================= Trigger =================
const range = (n, fn) => Array.from({ length: n }, (_, i) => fn(i));

// Các event trong player.json: phản ứng ngay, không phải đợi vòng quét
const EVENTS = [
  "tww:sneak_start", // environment_sensor báo bắt đầu sneak
  "tww:sneak_end", // environment_sensor báo thả sneak
  "bolt",
  "nobolt",
  ...range(6, (i) => `scope${i}`), // scope0..scope5 (đổi scope)
  "get_overheated",
  "cool_down",
  ...range(7, (i) => `get_overheated${i + 2}`), // 2..8
  ...range(7, (i) => `cool_down${i + 2}`),
];

world.afterEvents.dataDrivenEntityTrigger.subscribe(
  ({ entity }) => system.run(() => refresh(entity)),
  { entityTypes: ["minecraft:player"], eventTypes: EVENTS }
);

world.afterEvents.playerLeave.subscribe((e) => forget(e.playerId));

world.afterEvents.playerSpawn.subscribe(({ player }) => {
  forget(player.id);

  try {
    player.runCommand("camera @s fov_clear");
    player.runCommand("effect @s clear slowness"); // dọn slowness sót lại từ phiên trước
  } catch {}
});