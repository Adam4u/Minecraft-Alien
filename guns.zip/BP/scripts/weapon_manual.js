import { world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

/*
========================================================
WW2 WEAPON MANUAL
Minecraft Bedrock Script API
========================================================

5 CUSTOM BOOKS:

ww:smg_manual
ww:heavy_manual
ww:rifle_manual
ww:pistol_manual
ww:lmg_manual

Each page = one weapon.

IMPORTANT:
- No weapon image
- No material images
- No ammo image
- Only text recipes
- Previous / Next buttons are at the TOP
- Each weapon has a description field
========================================================
*/


// ======================================================
// VANILLA ITEM NAMES
// ======================================================

const N = {

    "minecraft:oak_planks": "Oak Planks",
    "minecraft:oak_wood": "Oak Wood",
    "minecraft:birch_planks": "Birch Planks",
    "minecraft:birch_wood": "Birch Wood",
    "minecraft:spruce_wood": "Spruce Wood",
    "minecraft:jungle_planks": "Jungle Planks",
    "minecraft:dark_oak_planks": "Dark Oak Planks",
    "minecraft:dark_oak_wood": "Dark Oak Wood",
    "minecraft:acacia_planks": "Acacia Planks",

    "minecraft:iron_block": "Iron Block",
    "minecraft:copper_block": "Copper Block",
    "minecraft:gold_block": "Gold Block",
    "minecraft:diamond_block": "Diamond Block",
    "minecraft:redstone_block": "Redstone Block",

    "minecraft:iron_ingot": "Iron Ingot",
    "minecraft:iron_nugget": "Iron Nugget",
    "minecraft:copper_ingot": "Copper Ingot",
    "minecraft:copper_nugget": "Copper Nugget",
    "minecraft:gold_ingot": "Gold Ingot",

    "minecraft:stick": "Stick",
    "minecraft:gunpowder": "Gunpowder",
    "minecraft:redstone": "Redstone",
    "minecraft:blaze_rod": "Blaze Rod",
    "minecraft:blaze_powder": "Blaze Powder",
    "minecraft:tnt": "TNT",
    "minecraft:lever": "Lever",
    "minecraft:hopper": "Hopper",
    "minecraft:target": "Target",
    "minecraft:spyglass": "Spyglass"
};


// ======================================================
// RECIPE HELPER
// ======================================================

function R(...items) {

    return items.map(([id, count]) => ({
        id,
        count
    }));

}


// ======================================================
// AMMO RECIPES
// ======================================================

const AMMO = {

    "ww:smgpouch": {

        name: "SMG Pouch",

        ingredients: R(
            ["minecraft:gunpowder", 2],
            ["minecraft:iron_nugget", 1],
            ["minecraft:iron_block", 1],
            ["minecraft:copper_nugget", 1]
        )
    },


    "ww:asriflepouch": {

        name: "Assault Rifle Pouch",

        ingredients: R(
            ["minecraft:gunpowder", 5],
            ["minecraft:iron_nugget", 1],
            ["minecraft:iron_block", 1],
            ["minecraft:copper_nugget", 1]
        )
    },


    "ww:mgpouch": {

        name: "MG Pouch",

        ingredients: R(
            ["minecraft:gunpowder", 4],
            ["minecraft:iron_nugget", 1],
            ["minecraft:copper_block", 1],
            ["minecraft:copper_nugget", 1]
        )
    },


    "ww:bazookarocket": {

        name: "Bazooka Rocket",

        ingredients: R(
            ["minecraft:copper_ingot", 4],
            ["minecraft:gunpowder", 4],
            ["minecraft:tnt", 1]
        )
    },

    "ww:fueltank": {

        name: "FlameThrower FuelTank",

        ingredients: R(
            ["minecraft:copper_block", 4],
            ["minecraft:copper_block", 4],
            ["minecraft:gunpowder", 2],
            ["minecraft:gunpowder", 2],
            ["minecraft:coal_block", 1],
            ["minecraft:coal_block", 1]
        )
    },

    "ww:riflepouch": {

        name: "Rifle Pouch",

        ingredients: R(
            ["minecraft:gunpowder", 6],
            ["minecraft:copper_nugget", 1],
            ["minecraft:copper_block", 1],
            ["minecraft:iron_ingot", 1]
        )
    },


    "ww:pistolpouch": {

        name: "Pistol Pouch",

        ingredients: R(
            ["minecraft:gunpowder", 1],
            ["minecraft:copper_block", 1],
            ["minecraft:iron_ingot", 1]
        )
    },


    // Added from ww_shotgunpouch.json
    "ww:shotgunpouch": {

        name: "Shotgun Pouch",

        ingredients: R(
            ["minecraft:gunpowder", 2],
            ["minecraft:iron_block", 2]
        )
    },

    "ww:revolverpouch": {

        name: "Revolver Pouch",

        ingredients: R(
            ["minecraft:gunpowder", 2],
            ["minecraft:copper_block", 2]
        )
    }

};


// ======================================================
// WEAPON DATA
// ======================================================

const WEAPONS = {

    // ==================================================
    // SMG
    // ==================================================

    smg: [

        {
            id: "ww:mp40",
            name: "MP40",

            description: `Ammunition: 32 rounds/magazine
Rate of Fire: ~500–550 rounds/min
Origin: Germany

The MP40 was a German submachine gun widely used during World War II. It was known for its compact and lightweight design, making it effective in close-range combat. The MP40 used 9×19mm Parabellum ammunition and had a relatively low rate of fire, allowing for better control and accuracy.
            `,

            ammo: "ww:smgpouch",

            ingredients: R(
                ["minecraft:oak_planks", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:copper_block", 1],
                ["minecraft:target", 1],
                ["minecraft:lever", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:mp28",
            name: "MP28",

            description: `Ammunition: 20 rounds/magazine
Rate of Fire: ~500–550 rounds/min
Origin: Germany

The MP28 was a German submachine gun developed from the MP18. It was used by German forces and police units before and during World War II. The weapon was relatively simple and reliable, using 9×19mm ammunition and detachable box magazines.
            `,

            ammo: "ww:smgpouch",

            ingredients: R(
                ["minecraft:oak_planks", 2],
                ["minecraft:iron_block", 2],
                ["minecraft:target", 1],
                ["minecraft:lever", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:ppd40",
            name: "PPD-40",

            description: `Ammunition: 71 rounds/magazine
Rate of Fire: ~800 rounds/min
Origin: Soviet Union

The PPD-40 was a Soviet submachine gun developed before World War II. It was heavily influenced by earlier designs but was adapted for Soviet production. The PPD-40 used 7.62×25mm Tokarev ammunition and was mainly used during the early years of the war.
            `,

            ammo: "ww:smgpouch",

            ingredients: R(
                ["minecraft:birch_wood", 1],
                ["minecraft:iron_block", 3],
                ["minecraft:target", 1],
                ["minecraft:lever", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:pps43",
            name: "PPS-43",

            description: `Ammunition: 35 rounds/magazine
Rate of Fire: ~600 rounds/min
Origin: Soviet Union

The PPS-43 was a Soviet submachine gun designed during World War II. It was developed to be compact, lightweight, and easy to manufacture. Chambered in 7.62×25mm Tokarev, it became popular for its reliability and simple construction.
            `,

            ammo: "ww:smgpouch",

            ingredients: R(
                ["minecraft:iron_block", 3],
                ["minecraft:copper_block", 1],
                ["minecraft:target", 1],
                ["minecraft:lever", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:ppsh41b",
            name: "PPSh-41 Box Mag",

            description: `Ammunition: 35 rounds/magazine
Rate of Fire: ~900–1,000 rounds/min
Origin: Soviet Union

The PPSh-41 was one of the most famous Soviet submachine guns of World War II. It was designed for mass production and close-range combat. The weapon used 7.62×25mm Tokarev ammunition and was known for its high rate of fire and distinctive appearance.
            `,

            ammo: "ww:smgpouch",

            ingredients: R(
                ["minecraft:birch_wood", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:redstone_block", 1],
                ["minecraft:target", 1],
                ["minecraft:lever", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:ppsh41d",
            name: "PPSh-41 Drum",

            description: `Ammunition: 71 rounds/drum
Rate of Fire: ~900–1,000 rounds/min
Origin: Soviet Union

The PPSh-41 was a Soviet submachine gun famous for its high rate of fire and large-capacity drum magazine. It was extensively used during World War II and became one of the most recognizable Soviet infantry weapons.
            `,

            ammo: "ww:smgpouch",

            ingredients: R(
                ["minecraft:birch_wood", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:copper_block", 1],
                ["minecraft:target", 1],
                ["minecraft:lever", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:m3a1",
            name: "M3A1",

            description: `Ammunition: 30 rounds/magazine
Rate of Fire: ~450 rounds/min
Origin: United States

The M3A1 was an American submachine gun derived from the M3 "Grease Gun". It was designed to be inexpensive and simple to manufacture. Chambered in .45 ACP, it was widely used by American forces during World War II and after.
            `,

            ammo: "ww:smgpouch",

            ingredients: R(
                ["minecraft:iron_block", 2],
                ["minecraft:lever", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:target", 1],
                ["minecraft:hopper", 1]
            )
        },


        {
            id: "ww:mab38",
            name: "MAB 38",

            description: `Ammunition: 10 or 40 rounds/magazine
Rate of Fire: ~600 rounds/min
Origin: Italy

The Beretta MAB 38 was an Italian submachine gun known for its high-quality construction and accuracy. It was widely used by Italian forces during World War II and remained in service for many years.
            `,

            ammo: "ww:smgpouch",

            ingredients: R(
                ["minecraft:iron_block", 3],
                ["minecraft:gold_block", 1],
                ["minecraft:target", 1],
                ["minecraft:lever", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:stg44",
            name: "STG44",

            description: `Ammunition: 30 rounds/magazine
Rate of Fire: ~500–600 rounds/min
Origin: Germany

The StG 44 was the world's first widely deployed assault rifle. Developed by Germany during World War II, it combined the capabilities of a rifle and submachine gun. It fired the intermediate 7.92×33mm Kurz cartridge and influenced many later assault rifle designs.
            `,

            ammo: "ww:asriflepouch",

            ingredients: R(
                ["minecraft:oak_wood", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:target", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:m1928a1",
            name: "M1928A1",

            description: `Ammunition: 20 rounds/magazine or 50 rounds/drum
Rate of Fire: ~600–700 rounds/min
Origin: United States

The M1928A1 Thompson was an American submachine gun widely used during World War II. It was known for its high firepower and distinctive drum or box magazines. Chambered in .45 ACP, it was especially effective at close range.
            `,

            ammo: "ww:smgpouch",

            ingredients: R(
                ["minecraft:spruce_wood", 1],
                ["minecraft:gold_block", 2],
                ["minecraft:copper_block", 1],
                ["minecraft:target", 1],
                ["minecraft:lever", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:thompson",
            name: "Thompson",

            description: `Ammunition: 30 rounds/magazine
Rate of Fire: ~700–800 rounds/min
Origin: United States

The Thompson submachine gun was one of the most iconic American weapons of World War II. It was prized for its powerful .45 ACP cartridge and high close-range firepower. The weapon was widely used by soldiers, paratroopers, and special units.
            `,

            ammo: "ww:smgpouch",

            ingredients: R(
                ["minecraft:spruce_wood", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:gold_block", 1],
                ["minecraft:target", 1],
                ["minecraft:lever", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:type100",
            name: "Type 100",

            description: `Ammunition: 30 rounds/magazine
Rate of Fire: ~450 rounds/min
Origin: Japan

The Type 100 was the only mass-produced Japanese submachine gun of World War II. It was chambered in 8mm Nambu and featured a relatively low rate of fire compared with many Allied submachine guns. It was mainly issued to special and airborne units.
            `,

            ammo: "ww:smgpouch",

            ingredients: R(
                ["minecraft:spruce_wood", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:copper_block", 1],
                ["minecraft:target", 1],
                ["minecraft:lever", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:type2a",
            name: "Type 2A",

            description: `Ammunition: 30 rounds/magazine
Rate of Fire: ~500 rounds/min
Origin: Japan

The Type 2A was a Japanese experimental automatic weapon design. It was intended to provide infantry with compact automatic fire. The weapon remained relatively uncommon compared with standard Japanese small arms.
            `,

            ammo: "ww:smgpouch",

            ingredients: R(
                ["minecraft:spruce_wood", 1],
                ["minecraft:iron_block", 1],
                ["minecraft:lever", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:target", 2],
                ["minecraft:blaze_rod", 1],
                ["minecraft:blaze_powder", 1]
            )
        }

    ],


    // ==================================================
    // MMG / HEAVY
    // ==================================================

    heavy: [

        {
            id: "ww:mg34b",
            name: "MG34B",

            description: `Ammunition: 50-round drum or belt
Rate of Fire: ~800–900 rounds/min
Origin: Germany

The MG34 was a German general-purpose machine gun used extensively during World War II. It was known for its high rate of fire and versatility. It could be fed from drums or ammunition belts and was chambered in 7.92×57mm Mauser.
            `,

            ammo: "ww:mgpouch",

            ingredients: R(
                ["minecraft:oak_planks", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:blaze_rod", 1],
                ["minecraft:blaze_powder", 1],
                ["minecraft:gold_block", 1],
                ["minecraft:hopper", 1]
            )
        },


        {
            id: "ww:mg42",
            name: "MG42",

            description: `Ammunition: 50-round belt
Rate of Fire: ~1,200 rounds/min
Origin: Germany

The MG42 was a German general-purpose machine gun famous for its extremely high rate of fire. It earned the nickname "Hitler's Buzzsaw" because of its distinctive sound. The MG42 was chambered in 7.92×57mm Mauser and was widely used throughout World War II.
            `,

            ammo: "ww:mgpouch",

            ingredients: R(
                ["minecraft:oak_planks", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:blaze_rod", 1],
                ["minecraft:blaze_powder", 1],
                ["minecraft:diamond_block", 1],
                ["minecraft:hopper", 1]
            )
        },


        {
            id: "ww:mg42b",
            name: "MG42B",

            description: `Ammunition: 50-round belt
Rate of Fire: ~1,200 rounds/min
Origin: Germany

The MG42B represents the belt-fed configuration of the MG42. It provided sustained automatic fire and was typically operated by a machine-gun team. Its high rate of fire made it particularly effective for suppressing enemy positions.
            `,

            ammo: "ww:mgpouch",

            ingredients: R(
                ["minecraft:oak_planks", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:blaze_rod", 1],
                ["minecraft:blaze_powder", 1],
                ["minecraft:diamond_block", 1],
                ["minecraft:hopper", 1]
            )
        },


        {
            id: "ww:bazooka",
            name: "Bazooka",

            description: `Ammunition: 1 rocket
Rate of Fire: ~6 rounds/min
Origin: United States

The Bazooka was an American portable anti-tank rocket launcher introduced during World War II. It fired rockets containing shaped-charge warheads designed to penetrate armored vehicles. It became one of the most recognizable infantry anti-tank weapons of the war.
            `,

            ammo: "ww:bazookarocket",

            ingredients: R(
                ["minecraft:iron_block", 3],
                ["minecraft:copper_block", 1],
                ["minecraft:lever", 1],
                ["minecraft:blaze_rod", 2],
                ["minecraft:blaze_powder", 1],
                ["minecraft:redstone", 1]
            )
        },

        {
            id: "ww:m2flame",
            name: "M2 Flamethrower",

            description: `Fuel Capacity: ~2.8 gallons (10.6 L)
Effective Range: ~20–40 meters
Origin: United States

The M2 Flamethrower was an American portable flamethrower used during World War II, particularly in the Pacific. It was designed to clear fortified positions, bunkers, and trenches. The weapon carried a pressurized fuel mixture and produced a sustained stream of burning fuel.
            `,

            ammo: "ww:fueltank",

            ingredients: R(
                ["minecraft:copper_block", 3],
                ["minecraft:copper_block", 1],
                ["minecraft:lever", 1],
                ["minecraft:blaze_rod", 2],
                ["minecraft:blaze_powder", 1],
                ["minecraft:redstone", 1]
            )
        },

        {
            id: "ww:stinger",
            name: "Stinger",

            description: `Ammunition: 1 missile
Rate of Fire: Single-shot
Origin: United States

The FIM-92 Stinger is a man-portable surface-to-air missile system. It was developed after World War II and entered service decades later. It is included in this weapon manual as a portable anti-aircraft weapon.
            `,

            ammo: "ww:mgpouch",

            ingredients: R(
                ["minecraft:oak_wood", 1],
                ["minecraft:iron_block", 3],
                ["minecraft:copper_block", 1],
                ["minecraft:lever", 1],
                ["minecraft:redstone_block", 1],
                ["minecraft:blaze_rod", 1],
                ["minecraft:blaze_powder", 1]
            )
        },


        {
            id: "ww:lungemine",
            name: "Lungemine",

            description: `Ammunition: 1 charge
Rate of Fire: Single-use
Origin: Japan

The Lunge Mine was a Japanese World War II anti-tank weapon designed for close-range attacks against armored vehicles. It consisted of a shaped-charge warhead mounted on a long pole. The weapon was extremely dangerous to its operator and was intended for single use.
            `,

            ingredients: R(
                ["minecraft:stick", 2],
                ["minecraft:tnt", 1]
            )
        },


        {
            id: "ww:pzb39",
            name: "PzB39",

            description: `Ammunition: 1 round/chamber
Rate of Fire: ~10–12 rounds/min
Origin: Germany

The PzB 39 was a German anti-tank rifle used during the early years of World War II. It was designed to penetrate the relatively thin armor of early tanks and armored vehicles. The weapon was manually operated and did not use a detachable magazine.
            `,

            ammo: "ww:riflepouch",

            ingredients: R(
                ["minecraft:oak_wood", 2],
                ["minecraft:iron_block", 2],
                ["minecraft:redstone", 1],
                ["minecraft:lever", 1]
            )
        }

    ],


    // ==================================================
    // RIFLE
    // ==================================================

    rifle: [

        {
            id: "ww:kar98",
            name: "Kar98",

            description: `Ammunition: 5 rounds/magazine
Rate of Fire: ~10–15 rounds/min
Origin: Germany

The Karabiner 98k was the standard German bolt-action rifle during World War II. It was known for its accuracy, ruggedness, and reliability. Chambered in 7.92×57mm Mauser, it remained one of the most widely used German infantry rifles.
            `,

            ammo: "ww:riflepouch",

            ingredients: R(
                ["minecraft:oak_wood", 1],
                ["minecraft:iron_block", 1],
                ["minecraft:stick", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:redstone", 1],
                ["minecraft:lever", 1]
            )
        },


        {
            id: "ww:g43",
            name: "G43",

            description: `Ammunition: 10 rounds/magazine
Rate of Fire: ~30–40 rounds/min
Origin: Germany

The Gewehr 43 was a German semi-automatic rifle introduced during World War II. It gave German infantrymen the ability to fire follow-up shots much faster than bolt-action rifles. Chambered in 7.92×57mm Mauser, it was valued for its increased firepower.
            `,

            ammo: "ww:riflepouch",

            ingredients: R(
                ["minecraft:dark_oak_wood", 1],
                ["minecraft:iron_block", 1],
                ["minecraft:target", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:redstone", 1]
            )
        },


        {
            id: "ww:garand",
            name: "Garand",

            description: `Ammunition: 8 rounds/clip
Rate of Fire: ~40–50 rounds/min
Origin: United States

The M1 Garand was the standard American semi-automatic rifle during World War II. It gave infantrymen a significant advantage through its ability to fire rapidly without manually cycling the action. It used .30-06 Springfield ammunition.
            `,

            ammo: "ww:riflepouch",

            ingredients: R(
                ["minecraft:oak_wood", 1],
                ["minecraft:iron_block", 1],
                ["minecraft:target", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:redstone", 1]
            )
        },


        {
            id: "ww:m1903",
            name: "M1903",

            description: `Ammunition: 5 rounds/magazine
Rate of Fire: ~10–15 rounds/min
Origin: United States

The M1903 Springfield was an American bolt-action rifle known for its accuracy and reliability. It was used extensively by American forces during World War II, particularly by snipers and specialized troops. It fired .30-06 Springfield ammunition.
            `,

            ammo: "ww:riflepouch",

            ingredients: R(
                ["minecraft:dark_oak_wood", 1],
                ["minecraft:iron_block", 1],
                ["minecraft:stick", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:redstone", 1],
                ["minecraft:lever", 1]
            )
        },


        {
            id: "ww:mosin",
            name: "Mosin",

            description: `Ammunition: 5 rounds/magazine
Rate of Fire: ~10–15 rounds/min
Origin: Soviet Union

The Mosin-Nagant was a famous Soviet bolt-action rifle used extensively during World War II. It was known for its rugged design and reliability in harsh conditions. The rifle fired 7.62×54mmR ammunition and remained a standard Soviet infantry weapon.
            `,

            ammo: "ww:riflepouch",

            ingredients: R(
                ["minecraft:birch_wood", 1],
                ["minecraft:iron_block", 1],
                ["minecraft:stick", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:redstone", 1],
                ["minecraft:lever", 1]
            )
        },


        {
            id: "ww:svt38",
            name: "SVT-38",

            description: `Ammunition: 10 rounds/magazine
Rate of Fire: ~20–30 rounds/min
Origin: Soviet Union

The SVT-38 was a Soviet semi-automatic rifle introduced shortly before World War II. It offered faster follow-up shots than traditional bolt-action rifles. Chambered in 7.62×54mmR, it was eventually replaced by the improved SVT-40.
            `,

            ammo: "ww:riflepouch",

            ingredients: R(
                ["minecraft:birch_wood", 1],
                ["minecraft:iron_block", 1],
                ["minecraft:target", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:redstone", 1]
            )
        },


        {
            id: "ww:model1912",
            name: "Model 1912",

            description: `Ammunition: 5 rounds/tubular magazine
Rate of Fire: ~20 rounds/min
Origin: United States

The Winchester Model 1912 was an American pump-action shotgun widely used in military and civilian roles. It was valued for its reliability and smooth pump action. Military versions were used in both World War I and World War II.
            `,

            ammo: "ww:shotgunpouch",

            ingredients: R(
                ["minecraft:oak_planks", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:blaze_powder", 1],
                ["minecraft:gold_block", 1],
                ["minecraft:blaze_rod", 1]
            )
        },


        {
            id: "ww:type99",
            name: "Type 99",

            description: `Ammunition: 5 rounds/magazine
Rate of Fire: ~10–15 rounds/min
Origin: Japan

The Type 99 was a Japanese bolt-action rifle introduced before World War II. It was designed as a replacement for the earlier Type 38 and used 7.7×58mm Arisaka ammunition. The rifle was widely issued to Japanese infantry during the war.
            `,

            ammo: "ww:riflepouch",

            ingredients: R(
                ["minecraft:spruce_wood", 1],
                ["minecraft:iron_block", 1],
                ["minecraft:stick", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:redstone", 1],
                ["minecraft:lever", 1]
            )
        },


        // PzB39 is intentionally here.
        // It was moved from Heavy to Rifle.

        {
            id: "ww:pzb39",
            name: "PzB39",

            description: `Ammunition: 1 round/chamber
Rate of Fire: ~10–12 rounds/min
Origin: Germany

The PzB 39 was a German anti-tank rifle used during the early years of World War II. It was designed to penetrate the relatively thin armor of early tanks and armored vehicles. The weapon was manually operated and did not use a detachable magazine.
            `,

            ammo: "ww:riflepouch",

            ingredients: R(
                ["minecraft:oak_wood", 2],
                ["minecraft:iron_block", 2],
                ["minecraft:redstone", 1],
                ["minecraft:lever", 1]
            )
        }

    ],


    // ==================================================
    // PISTOL
    // ==================================================

    pistol: [

        {
            id: "ww:c96sch",
            name: "C96SCH",

            description: `Ammunition: 20 rounds/magazine
Rate of Fire: ~900 rounds/min
Origin: Germany

The C96 Automatic was a select-fire version of the famous Mauser C96 pistol. It could fire continuously and was known for its distinctive design and wooden shoulder stock. Chambered in 7.63×25mm Mauser, it was an unusual but powerful early automatic pistol.
            `,

            ammo: "ww:pistolpouch",

            ingredients: R(
                ["minecraft:dark_oak_planks", 1],
                ["minecraft:iron_block", 1],
                ["minecraft:target", 2],
                ["minecraft:gold_ingot", 1],
                ["minecraft:blaze_rod", 1]
            )
        },


        {
            id: "ww:m1911",
            name: "M1911",

            description: `Ammunition: 7 rounds/magazine
Rate of Fire: ~40 rounds/min
Origin: United States

The M1911 was an American semi-automatic pistol that served as the standard U.S. military sidearm for much of the 20th century. Chambered in .45 ACP, it was known for its reliability, durability, and stopping power.
            `,

            ammo: "ww:pistolpouch",

            ingredients: R(
                ["minecraft:oak_planks", 1],
                ["minecraft:gold_ingot", 1],
                ["minecraft:target", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:p08",
            name: "P08",

            description: `Ammunition: 8 rounds/magazine
Rate of Fire: ~40 rounds/min
Origin: Germany

The Luger P08 was a famous German semi-automatic pistol recognized by its distinctive toggle-lock action. It was widely used by German military forces during both World Wars. The standard version was chambered in 9×19mm Parabellum.
            `,

            ammo: "ww:pistolpouch",

            ingredients: R(
                ["minecraft:oak_planks", 1],
                ["minecraft:gold_ingot", 1],
                ["minecraft:target", 1],
                ["minecraft:stick", 1]
            )
        },

        {
            id: "ww:nagant",
            name: "Nagant M1895",

            description: `Ammo: 7.62×38mmR Nagant
Capacity: 7 rounds
Rate of Fire: ~20–30 RPM
Origin: Russian Empire / Soviet Union

The Nagant M1895 is a Russian-designed revolver adopted in 1895 and widely used by Soviet forces during World War II. It was known for its rugged construction and unique gas-seal system, which reduced the gap between the cylinder and barrel when firing. It was reliable but slow to reload compared with modern pistols.`,

            ammo: "ww:revolverpouch",

            ingredients: R(
                ["minecraft:oak_planks", 1],
                ["minecraft:gold_ingot", 1],
                ["minecraft:target", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:p38",
            name: "P38",

            description: `Ammunition: 8 rounds/magazine
Rate of Fire: ~40 rounds/min
Origin: Germany

The Walther P38 was a German semi-automatic pistol introduced before World War II. It became the standard German service pistol alongside the Luger. Chambered in 9×19mm Parabellum, it featured a modern double-action design.
            `,

            ammo: "ww:pistolpouch",

            ingredients: R(
                ["minecraft:dark_oak_planks", 1],
                ["minecraft:iron_ingot", 1],
                ["minecraft:target", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:tt33",
            name: "TT33",

            description: `Ammunition: 8 rounds/magazine
Rate of Fire: ~40 rounds/min
Origin: Soviet Union

The TT-33 was a Soviet semi-automatic pistol widely used during World War II. It was known for its simple and robust design. Chambered in 7.62×25mm Tokarev, it offered good penetration and a relatively high-velocity pistol cartridge.
            `,

            ammo: "ww:pistolpouch",

            ingredients: R(
                ["minecraft:iron_block", 1],
                ["minecraft:iron_ingot", 1],
                ["minecraft:target", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:mas35",
            name: "MAS35",

            description: `Ammunition: 8 rounds/magazine
Rate of Fire: ~30–40 rounds/min
Origin: France

The Mle 1935S was a French semi-automatic service pistol developed in the 1930s. It was compact, reliable, and chambered in 7.65mm Longue. The pistol was used by French military and police forces before and during World War II.
            `,

            ammo: "ww:pistolpouch",

            ingredients: R(
                ["minecraft:acacia_planks", 1],
                ["minecraft:iron_ingot", 1],
                ["minecraft:target", 1],
                ["minecraft:stick", 1]
            )
        }

    ],


    // ==================================================
    // LMG
    // ==================================================

    lmg: [

        {
            id: "ww:bar",
            name: "BAR",

            description: `Ammunition: 20 rounds/magazine
Rate of Fire: ~500–650 rounds/min
Origin: United States

The BAR was an American automatic rifle widely used during World War II. It provided infantry with mobile automatic fire and could be fired from the shoulder or supported position. Chambered in .30-06 Springfield, it was powerful and reliable.
            `,

            ammo: "ww:mgpouch",

            ingredients: R(
                ["minecraft:oak_planks", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:target", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:dp28",
            name: "DP28",

            description: `Ammunition: 47 rounds/drum
Rate of Fire: ~500–600 rounds/min
Origin: Soviet Union

The DP-28 was a Soviet light machine gun famous for its distinctive pan-shaped magazine. It was valued for its simple design and reliability in difficult conditions. Chambered in 7.62×54mmR, it provided effective automatic fire for infantry units.
            `,

            ammo: "ww:mgpouch",

            ingredients: R(
                ["minecraft:birch_planks", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:target", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:stick", 1]
            )
        },


        {
            id: "ww:lewis",
            name: "Lewis",

            description: `Ammunition: 47 rounds/drum
Rate of Fire: ~500–600 rounds/min
Origin: United States / United Kingdom

The Lewis Gun was a light machine gun widely used by British and Commonwealth forces. It featured a distinctive top-mounted drum magazine and an air-cooling system. Chambered in .303 British, it was used extensively during both World Wars.
            `,

            ammo: "ww:mgpouch",

            ingredients: R(
                ["minecraft:oak_planks", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:redstone_block", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:stick", 1],
                ["minecraft:hopper", 1]
            )
        },


        {
            id: "ww:type11",
            name: "Type 11",

            description: `Ammunition: 30 rounds/magazine
Rate of Fire: ~500 rounds/min
Origin: Japan

The Type 11 was a Japanese light machine gun introduced in the 1920s. It used a unique hopper-style feeding system rather than a conventional detachable magazine. Chambered in 6.5×50mm Arisaka, it was widely used by Japanese infantry before being replaced by newer designs.
            `,

            ammo: "ww:mgpouch",

            ingredients: R(
                ["minecraft:jungle_planks", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:target", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:stick", 2]
            )
        },


        {
            id: "ww:type96",
            name: "Type 96",

            description: `Ammunition: 30 rounds/magazine
Rate of Fire: ~550 rounds/min
Origin: Japan

The Type 96 was a Japanese light machine gun introduced in 1936. It improved upon the Type 11 with a detachable box magazine and better overall design. Chambered in 6.5×50mm Arisaka, it was widely used during World War II.
            `,

            ammo: "ww:mgpouch",

            ingredients: R(
                ["minecraft:jungle_planks", 1],
                ["minecraft:iron_block", 2],
                ["minecraft:redstone_block", 1],
                ["minecraft:copper_block", 1],
                ["minecraft:blaze_rod", 1],
                ["minecraft:spyglass", 1]
            )
        },


        {
            id: "ww:fg42",
            name: "FG42",

            description: `Ammunition: 20 rounds/magazine
Rate of Fire: ~750 rounds/min
Origin: Germany

The FG 42 was a German automatic rifle designed specifically for airborne troops. It combined features of a rifle and light machine gun in a compact package. Chambered in 7.92×57mm Mauser, it was powerful, versatile, and produced in limited numbers.
            `,

            ammo: "ww:mgpouch",

            ingredients: R(
                ["minecraft:oak_planks", 1],
                ["minecraft:iron_block", 3],
                ["minecraft:target", 1],
                ["minecraft:stick", 1]
            )
        }

    ]

};


// ======================================================
// BOOK -> GROUP
// ======================================================

const BOOK_GROUP = {

    "ww:smg_manual": {
        title: "SMG MANUAL",
        group: "smg"
    },

    "ww:heavy_manual": {
        title: "MMG / HEAVY MANUAL",
        group: "heavy"
    },

    "ww:rifle_manual": {
        title: "RIFLE MANUAL",
        group: "rifle"
    },

    "ww:pistol_manual": {
        title: "PISTOL MANUAL",
        group: "pistol"
    },

    "ww:lmg_manual": {
        title: "LMG MANUAL",
        group: "lmg"
    }

};


// ======================================================
// FORMAT INGREDIENTS
// ======================================================

function formatIngredients(ingredients) {

    if (!ingredients || ingredients.length === 0) {

        return (
            "§cNo recipe available.§r\n" +
            "§7You can add the recipe later.§r"
        );

    }


    return ingredients
        .map((ingredient) => {

            const name =
                N[ingredient.id] ??
                ingredient.id;

            return `§f• ${name} ×${ingredient.count}§r`;

        })
        .join("\n");
}


// ======================================================
// SHOW WEAPON PAGE
// ======================================================

async function showWeaponPage(
    player,
    bookId,
    index
) {

    const book = BOOK_GROUP[bookId];

    if (!book) return;


    const list = WEAPONS[book.group];

    if (!list || list.length === 0) return;


    // Loop pages

    if (index < 0) {
        index = list.length - 1;
    }

    if (index >= list.length) {
        index = 0;
    }


    const weapon = list[index];

    const ammo = AMMO[weapon.ammo];


    // ==================================================
    // FORM
    // ==================================================

    const form = new ActionFormData();


    // ==================================================
    // TITLE
    // ==================================================

    form.title(
        `${book.title}  |  ${index + 1}/${list.length}`
    );


    // ==================================================
    // NAVIGATION
    //
    // FIRST TWO BUTTONS
    // ==================================================

    form.button(
        "§e◀ PREVIOUS PAGE"
    );

    form.button(
        "§aNEXT PAGE ▶"
    );


    // ==================================================
    // DESCRIPTION
    // ==================================================

    let body =

        `§l§6${weapon.name}§r\n\n` +

        `§l§eDESCRIPTION§r\n` +

        `${weapon.description.trim() || "§7(Write weapon description here.)§r"}\n\n`;


    // ==================================================
    // WEAPON RECIPE
    // ==================================================

    body +=
        `§l§eWEAPON RECIPE§r\n`;

    body +=
        `${formatIngredients(
            weapon.ingredients
        )}\n`;


    // ==================================================
    // AMMUNITION
    // ==================================================

    if (ammo) {

        body +=
            `\n§l§aAMMUNITION§r\n` +

            `§f${ammo.name}§r\n\n` +

            `§l§aAMMO RECIPE§r\n` +

            `${formatIngredients(
                ammo.ingredients
            )}\n`;

    }


    // ==================================================
    // PAGE NUMBER
    // ==================================================

    body +=
        `\n§7Page ${index + 1} / ${list.length}§r`;


    form.body(body);


    // ==================================================
    // SHOW
    // ==================================================

    const result =
        await form.show(player);


    if (result.canceled) {
        return;
    }


    // ==================================================
    // PREVIOUS PAGE
    // ==================================================

    if (result.selection === 0) {

        return showWeaponPage(
            player,
            bookId,
            index - 1
        );

    }


    // ==================================================
    // NEXT PAGE
    // ==================================================

    if (result.selection === 1) {

        return showWeaponPage(
            player,
            bookId,
            index + 1
        );

    }

}


// ======================================================
// OPEN BOOK
// ======================================================

world.afterEvents.itemUse.subscribe(
    (event) => {

        const player =
            event.source;

        const item =
            event.itemStack;


        if (!item) {
            return;
        }


        const book =
            BOOK_GROUP[item.typeId];


        if (!book) {
            return;
        }


        showWeaponPage(
            player,
            item.typeId,
            0
        ).catch((error) => {

            console.warn(
                `[Weapon Manual] ${error}`
            );

        });

    }
);